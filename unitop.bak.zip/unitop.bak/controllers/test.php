<?php
/**
 * @brief 公共模块
 * @class Block
 */
class Test extends IController
{
	public $layout='';

	public function gg()
	{
		echo "登陆界面<br>";
		$config = new Config("site_config");
		$fb=new face($config_info['fb']['id'],$config_info['fb']['sec']);
		$fb->loginback();				
	}
	public function index(){
		$config = new Config("site_config");
		$config_info = $config->getInfo();
		$fb=new face($config_info['fb']['id'],$config_info['fb']['sec']);
		$fb->login();
	}

}