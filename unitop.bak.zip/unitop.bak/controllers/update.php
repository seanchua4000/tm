<?php
/**
 * @brief 升级更新控制器
 */
class Update extends IController
{
	/**
	 * @brief iwebshop15061500 版本升级更新
	 */
	public function iwebshop15061500()
	{
		die('Upgrade success！');
	}
}