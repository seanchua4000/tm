<?php
/**
 * @brief 商家模块
 * @class Seller
 * @author chendeshan
 * @datetime 2014/7/19 15:18:56
 */
class Seller extends IController
{
	public $layout = 'seller';
	public $excel_not='';

	/**
	 * @brief 初始化检查
	 */
	public function init()
	{
		IInterceptor::reg('CheckRights@onCreateAction');
	}
	public function excel_updata(){
		
		if($_GET['file']){
			echo '<a href="/seller/excel_two/type/1/file/'.$_GET['file'].'" target="_blank">click to download Existing commodity</a><br>';
			echo '<a href="/seller/excel_two/type/2/file/'.$_GET['file'].'" target="_blank">click to download Not Existing commodity</a><br>';
		}	

	}
	public function order_complete_select(){
		$this->layout='';
		$this->redirect("order_complete_select",false);
		
	}
	//更新商品推荐标签
	public function update_commend()
	{
		
		$data = $_REQUEST['data'];//IFilter::act(IReq::get('data')); //key => 商品ID或货品ID ; value => commend值 1~4
		/*
		if(!$data)
		{
			die(JSON::encode(array('result' => 'fail','data' => 'Commodity data does not exist')));
		}
		*/
		$goodsCommendDB = new IModel('commend_goods');

		//清理旧的commend数据
		/**
		$goodsIdArray = array_keys($data);
		$goodsCommendDB->del("goods_id in (".join(',',$goodsIdArray).")");
		*/
		$goodsIdArray = implode(',', $_POST['id']);
		$goodsCommendDB->del("goods_id in (".$goodsIdArray.")");		
		if($data){
			//插入新的commend数据
			foreach($data as $id => $commend)
			{
				foreach($commend as $k => $value)
				{
					$goodsCommendDB->setData(array('commend_id' => $value,'goods_id' => $id));
					$goodsCommendDB->add();
				}
			}			
		}


		$this->redirect("goods_list",false);
	}
	public function goodsCommend()
	{
		//$this->layout='';
		//商品字符串的逗号间隔
		$id = IFilter::act(IReq::get('id'));
		$sid = $this->seller['seller_id'];
		if($id)
		{
			$idArray = explode(",",$id);
			$idArray = IFilter::act($idArray,'int');
			$id = join(',',$idArray);
		}

		$goodsDB = new IModel('goods');


		$goodsData = $goodsDB->query("id in (".$id.") and seller_id=".$sid,"id,name");

		$goodsCommendDB = new IModel('commend_goods');
		foreach($goodsData as $key => $val)
		{
			$goodsCommendData = $goodsCommendDB->query("goods_id = ".$val['id']);
			foreach($goodsCommendData as $k => $v)
			{
				$goodsData[$key]['commend'][$v['commend_id']] = 1;
			}
		}
		$data['goodsData']=$goodsData;
		$this->setRenderData($data);
		$this->redirect("goodsCommend",false);		
	}		
	public function excel_two(){
		$type=$_GET['type'];

		if($_GET['file']){
	      	define('EXCEL_PATH', substr(dirname(__FILE__),0,-11));	
			$report = new report();
			

			$path=EXCEL_PATH . 'upload/product_excel/'.trim($_GET['file']);
			//product.xlsx';

			$goods_data=$report->excel_read($path);			
		}
		//print_r($goods_data);exit;
	
		$goods_not_exist=array();	
		if(!empty($goods_data)){
			$id_array=array_keys($goods_data);

			$id_orignal_array=$id_array;
			
			for($g=0;$g<count($id_array);$g++){
				$id_array[$g]="'".$id_array[$g]."'";
			}
			$id_plat_exist=array();
			$where = " go.seller_id=0 and go.is_del != 1";
			$where .=' and go.goods_no IN ('.implode(',', $id_array).')';
			$table='goods as go';
			$goodsHandle = new IQuery($table);
			$goodsHandle->order    = "go.sort asc,go.id desc";
			$goodsHandle->distinct = "go.id";
			$goodsHandle->fields   = "go.id, go.name,go.barcode,go.goods_no,go.sell_price,go.store_nums,go.sale,go.is_del,go.create_time";
			$goodsHandle->join     = $join;
			$goodsHandle->where    = $where;
			$goodsHandle->limit    = 'all';
			$goodsList = $goodsHandle->find();
			
			if(!empty($goodsList)){
				//构建 Excel table;
				$strTable ='<table width="500" border="1">';
				$strTable .= '<tr>';


				$strTable .= '<td style="text-align:center;font-size:12px;" width="*">Commodity name</td>';
				$strTable .= '<td style="text-align:center;font-size:12px;" width="60">barcode</td>';
				$strTable .= '<td style="text-align:center;font-size:12px;" width="60">goods_no</td>';
				$strTable .= '<td style="text-align:center;font-size:12px;" width="160">classification</td>';
				$strTable .= '<td style="text-align:center;font-size:12px;" width="60">price</td>';
				$strTable .= '<td style="text-align:center;font-size:12px;" width="60">stock</td>';
				$strTable .= '<td style="text-align:center;font-size:12px;" width="60">sales volume</td>';
				$strTable .= '<td style="text-align:center;font-size:12px;" width="60">Release time</td>';
				$strTable .= '<td style="text-align:center;font-size:12px;" width="60">state</td>';
				$strTable .= '<td style="text-align:center;font-size:12px;" width="60">Subordinate merchant</td>';
				$strTable .= '</tr>';
				
				foreach($goodsList as $k=>$val){
					$id_plat_exist[]=$val['goods_no'];
					$strTable .= '<tr>';
					$strTable .= '<td style="text-align:center;font-size:12px;">&nbsp;'.$val['name'].'</td>';
					$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['barcode'].' </td>';
					$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['goods_no'].' </td>';

					$strTable .= '<td style="text-align:left;font-size:12px;">'.goods_class::getGoodsCategory($val['id']).' </td>';
					$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['sell_price'].' </td>';
					$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['store_nums'].' </td>';
					$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['sale'].' </td>';
					$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['create_time'].' </td>';
					$strTable .= '<td style="text-align:left;font-size:12px;">'.goods_class::statusText($val['is_del']).' </td>';
					$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['true_name'].'&nbsp;</td>';			
					$strTable .= '</tr>';
				}
				$strTable .='</table>';
				unset($goodsList);
				if($type=='1'){//echo $strTable;exit;
					$report->setFileName('Existing commodity');
					$report->toDownload($strTable);
				}			
			}
			
			if(!empty($id_plat_exist)){
				for($j=0;$j<count($id_orignal_array);$j++){
					if(!in_array($id_orignal_array[$j],$id_plat_exist)){
						$goods_not_exist[]=$id_orignal_array[$j];
					}

				}
			}else{
				$goods_not_exist=$id_array;
			}
			if(!empty($goods_not_exist)){
				$strTable='';
				$strTable .='<table width="200" border="1">';
				$strTable .= '<tr>';
				$strTable .= '<td style="text-align:center;font-size:12px;" width="100">Commodity name</td>';
				$strTable .= '<td style="text-align:center;font-size:12px;" width="100">goods_no</td>';
				$strTable .= '</tr>';
				for($k=0;$k<count($goods_not_exist);$k++){
					$n_key=$goods_not_exist[$k];
					$strTable .= '<tr>';
					$strTable .= '<td style="text-align:center;font-size:12px;">&nbsp;'.$goods_data[$n_key]['name'].'</td>';
					$strTable .= '<td style="text-align:left;font-size:12px;">'.$n_key.' </td>';		
					$strTable .= '</tr>';
				}
				$strTable .='</table>';//echo $strTable;exit;
				if($type=='2'){
					$report->setFileName('Not Existing Commodity');
					$report->toDownload($strTable);						
				}

							
			}else{
				echo '<br>All Existing';
			}
						
		}else{
			die('no data');
		}
	}
	public function upload_deal(){
		
		$path=substr(dirname(__FILE__),0,-11).'upload/product_excel/';
		if (substr($_FILES["upload"]["name"],-4) == "xlsx"){
			if ($_FILES["upload"]["error"] > 0){
				echo "Return Code: " . $_FILES["upload"]["error"] . "<br />";
			}else{
				$new_name=time().$_FILES["upload"]["name"];
			    $name=$path.$new_name;
			    if (file_exists($name)){
			      	echo $_FILES["upload"]["name"] . " already exists. ";
			     }else{
			      move_uploaded_file($_FILES["upload"]["tmp_name"],
			      $name);
			      $url=$_SERVER['SERVER_NAME']."/seller/excel_updata/file/".$new_name;
			      header("Location: http://".$url); 
		      	}
		    }
		}else{
			echo "Invalid file";
		}			
	}
	public function upload_excel(){
		$this->layout='';
		$this->redirect('upload_excel',false);
	}
	
	public function group_category_edit(){
		$this->layout='';
		//获取商品分类列表
		$goods_class = new goods_class();
		$tb_category = new IModel('category');
		$this->category = $goods_class->sortdata($tb_category->query(false,'*','name','asc'),0,'--');//sort		
		$this->redirect('group_category_edit',false);
	}
	public function remark_edit(){
		$this->layout='';
		$this->redirect('remark_edit',false);
	}
	public function remark_update(){
		$cid = IFilter::act(IReq::get('cid'),'int');
		$text = IFilter::act(IReq::get('mark'),'text');
		$categoryDB = new IModel('order');
		$categoryDB->setData(array('remark' => $text));
		if($categoryDB->update('id='.$cid)){
			echo 'success';
		}

	}
	public function group_category_update(){
		$cid=$_GET['cid'];
		//$cid='_goods_category=558&_goods_category=581&_goods_category=583';
		$cate_arr=array();
		if(!empty($cid)){
			$cidStr=explode('&', $cid);
			if(!empty($cidStr)){
				foreach ($cidStr  as $value) {
					$cidArr=explode('=',$value);
					if(!ctype_digit($cidArr[1])){
						die('update error');
					}
					$cate_arr[]=$cidArr[1];
				}
			}
		}
		if(empty($cate_arr)){
			die('update error');
		}
		$gid=$_POST['id'];
		$gid_arr=explode(',', $gid);
		$categoryDB = new IModel('category_extend');
		for($i=0;$i<count($gid_arr);$i++){
			if(!ctype_digit($gid_arr[$i])){
				die("update error");
			}
			//处理商品分类	
			$categoryDB->del('goods_id = '.$gid_arr[$i]);
			for($j=0;$j<count($cate_arr);$j++){									
				$categoryDB->setData(array('goods_id' => $gid_arr[$i],'category_id' => $cate_arr[$j]));
				$categoryDB->add();	
			}		
		}
		echo 'success';
	}	
	/**
	 * @brief 商品添加中图片上传的方法
	 */
	public function goods_img_upload()
	{
		//获得配置文件中的数据
		$config = new Config("site_config");

	 	//调用文件上传类
		$photoObj = new PhotoUpload();
		$photo    = current($photoObj->run());

		//判断上传是否成功，如果float=1则成功
		if($photo['flag'] == 1)
		{
			$result = array(
				'flag'=> 1,
				'img' => $photo['img']
			);
		}
		else
		{
			$result = array('flag'=> $photo['flag']);
		}
		echo JSON::encode($result);
	}
	/**
	 * @brief 商品添加和修改视图
	 */
	public function goods_edit()
	{
		$goods_id = IFilter::act(IReq::get('id'),'int');

		//初始化数据
		$goods_class = new goods_class($this->seller['seller_id']);

		//获取商品分类列表
		$tb_category = new IModel('category');
		$this->category = $goods_class->sortdata($tb_category->query(false,'*','sort','asc'),0,'--');

		//获取所有商品扩展相关数据
		$data = $goods_class->edit($goods_id);

		if($goods_id && !$data)
		{
			die("Did not find the relevant goods！");
		}

		$this->setRenderData($data);
		$combinamtion_json = $data['form']['combination'];
		$this->combination = json_decode($combinamtion_json,true);
		$this->redirect('goods_edit');
	}
	//商品更新动作
	public function goods_update()
	{
		$id       = IFilter::act(IReq::get('id'),'int');
		$callback = IFilter::act(IReq::get('callback'),'url');
		$callback = strpos($callback,'seller/goods_list') === false ? '' : $callback;
		
		$zuhe1 = IReq::get('zuhe1');
		$zuhe2 = IReq::get('zuhe2');
		$zuhe3 = IReq::get('zuhe3');
		
		if($zuhe1 != ''){
			$zuheArr[] = array('goods_id'=>$zuhe1);
		}
		if($zuhe2 != ''){
			$zuheArr[] = array('goods_id'=>$zuhe2);
		}
		if($zuhe3 != ''){
			$zuheArr[] = array('goods_id'=>$zuhe3);
		}

		$combination = json_encode($zuheArr);
		
		$_POST['combination'] = $combination;
		
		unset($_POST[zuhe1]); 
		unset($_POST[zuhe2]); 
		unset($_POST[zuhe3]); 
		
		//检查表单提交状态
		if(!$_POST)
		{
			die('Please confirm that the form is submitted to the correct');
		}

		//初始化商品数据
		unset($_POST['id']);
		unset($_POST['callback']);

		//print_r($_POST);

		$update_Data=array();
		$update_Data['combination']=$_POST['combination'];
		$update_Data['_store_nums']=$_POST['_store_nums'];
		$update_Data['_market_price']=$_POST['_market_price'];
		$update_Data['_sell_price']=$_POST['_sell_price'];
		$update_Data['_cost_price']=$_POST['_cost_price'];
		$update_Data['is_del']=$_POST['is_del'];
		$update_Data['_goods_no']=$_POST['_goods_no'];
		//print_r($update_Data);exit;

		$goodsObject = new goods_class($this->seller['seller_id']);
		
		$goodsObject->updateByseller($id,$update_Data);
		$this->redirect("goods_list");
		//$callback ? $this->redirect($callback) : $this->redirect("goods_list");
	}
	/*============fill+===================================================*/
	public function share_list(){
		/**
		$sellergoods = new IModel('goods as go,goods as bo');
		$where = 'go.name=bo.name and go.seller_id=8 and bo.seller_id=0';
		$cols=array('go.id,bo.id as bid');
		$sellerArray=$sellergoods->query($where,$cols,'','','all');echo count($sellerArray);
		$copydb = new IModel('user_goods_copyrecord');
		foreach($sellerArray as $k=>$v){
			$copydb->setData(array(
				'goods_id' => $v['id'],
				'copyfrom_id'     => $v['bid'],//$this->admin['admin_name'],
				'seller_id'   => $this->seller['seller_id']
			));
			$copydb->add();
		}
		exit;
		*/
		$sellergoods = new IModel('user_goods_copyrecord');
		$cols=array('copyfrom_id');
		$where="seller_id=".$this->seller['seller_id']." and copyfrom_id!=0";
		$sellerArray=$sellergoods->query($where,$cols,'','','all');
		$idArray=array();
		if(!empty($sellerArray)){
			foreach ($sellerArray as $key => $value) {
				$idArray[]=$value['copyfrom_id'];
			}
		}
		$tmp_data=array();
		$tmp_data['idArray']=$idArray;
		$this->setRenderData($tmp_data);
		$this->redirect("share_list",false);
	}
	//商品导出 Excel=>根据上架来
	public function fill_goods_shelves_report()
	{
		if($this->seller['seller_id']){
			$table='goods as go';

			$where = "go.seller_id=".$this->seller['seller_id']." and go.is_del =0";
			//拼接sql
			$goodsHandle = new IQuery($table);
			$goodsHandle->order    = "go.sort asc,go.id desc";
			$goodsHandle->distinct = "go.id";
			$goodsHandle->fields   = "go.id, go.name,go.goods_no,go.barcode,go.sell_price,go.store_nums,go.sale,go.is_del,go.create_time";
			//$goodsHandle->join     = $join;
			$goodsHandle->where    = $where;
			$goodsHandle->limit    = 'all';
			$goodsList = $goodsHandle->find();
			if(empty($goodsList)){
				exit("NO goods");
			}

			//构建 Excel table;
			$strTable ='<table width="500" border="1">';
			$strTable .= '<tr>';


			$strTable .= '<td style="text-align:center;font-size:12px;" width="*">Commodity name</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="60">barcode</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="60">goods_no</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="160">classification</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="60">price</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="60">stock</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="60">sales volume</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="60">Release time</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="60">state</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="60">Subordinate merchant</td>';
			$strTable .= $new_fields ? '<td style="text-align:center;font-size:12px;" width="160">category</td>' : '';
			$strTable .= '</tr>';

			foreach($goodsList as $k=>$val){
				$strTable .= '<tr>';
				$strTable .= '<td style="text-align:center;font-size:12px;">&nbsp;'.$val['name'].'</td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['barcode'].' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['goods_no'].' </td>';

				$strTable .= '<td style="text-align:left;font-size:12px;">'.goods_class::getGoodsCategory($val['id']).' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['sell_price'].' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['store_nums'].' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['sale'].' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['create_time'].' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.goods_class::statusText($val['is_del']).' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['true_name'].'&nbsp;</td>';
			    $strTable .= $new_fields ? '<td style="text-align:left;font-size:12px;">'.$val['cate'].'&nbsp;</td>': '';			
				$strTable .= '</tr>';
			}
			$strTable .='</table>';
			unset($goodsList);
			$reportObj = new report();
			$reportObj->setFileName('goods_shelves');
			$reportObj->toDownload($strTable);			
		}

		exit();
	}	
	/*============fill+===================================================*/
	//商品批量设置
	public function group_edit(){
		$idArray=explode(',',trim($_GET['id']));
		if(empty($idArray)){
			exit('please choose a product');
		}
		$data=array();	
		for($i=0;$i<count($idArray);$i++){
			$goods_id=$idArray[$i];
			if(!ctype_digit((string)$goods_id)){
				exit('data error');
			}
			$sql=$_GET['gg'] ? '' : $this->seller['seller_id'];
			//初始化数据
			$goods_class = new goods_class($sql);

			//获取所有商品扩展相关数据
			$single_data = $goods_class->edit($goods_id);

			if(empty($single_data)){
				die("Did not find the  goods！");
			}
			$data['product'][]=$single_data;
		}
		$data['seller_goods']=$_GET['gg'] ? 1 : '';

		//print_r($data);exit;
		$this->setRenderData($data);
		
		$this->redirect("group_edit",false);

	}	
	//商品更新动作
	public function goods_update_group()
	{
		//print_r($_POST);exit;
		//$id       = IFilter::act(IReq::get('id'),'int');
		//检查表单提交状态
		if(!$_POST)
		{
			die('Please confirm that the form is submitted to the correct');
		}
		$goodsObject = new goods_class($this->seller['seller_id']);
		foreach($_POST['stocks'] as $k=>$v){
			$barcode=$id=$stocks=$advice=$sales=$is_del=0;
			$id=$k;
			$stocks=$v;
			$advice=$_POST['advice'][$k];
			$sales=$_POST['sales'][$k];
			$is_del=$_POST['is_del'][$k];
			$barcode=$_POST['barcode'][$k];
			if(is_array($v)){
				foreach($v as $kv=>$vv){
					if(!is_numeric($vv[$i])){
						die('data error');
					}
				}
			}else{
				if(!is_numeric($stocks)||!is_numeric($advice)||!is_numeric($sales)||!is_numeric($is_del)){
					die('data error');
				}				
			}

			$goodsUpdateData['barcode']=$barcode;

			$goodsUpdateData['sell_price']=$sales;

			$goodsUpdateData['market_price']=$advice;

			$goodsUpdateData['store_nums']=$stocks;

			$goodsUpdateData['is_del']=$is_del;

			if($_POST['goods_commend'][$k])

				$goodsUpdateData['commend_price']=$_POST['goods_commend'][$k];

			if(!$_POST['plat']){
				$goodsObject->updateByGroup($id,$goodsUpdateData);
	
			}else{
				$goodsObject->updateByGroupPlat($id,$goodsUpdateData);
	
			}						
		}
		if(!$_POST['plat']){
			$this->redirect("goods_list");	
		}else{
			$this->redirect("share_list");	
		}			
		/**

		$stocks=$advice=$sales=$is_del=0;

		if(!empty($_POST['stocks'])&&is_numeric($_POST['stocks'])){
			$stocks=trim($_POST['stocks']);
		}
		if(!empty($_POST['advice'])&&is_numeric($_POST['advice'])){
			$advice=trim($_POST['advice']);
		}
		if(!empty($_POST['sales'])&&is_numeric($_POST['sales'])){
			$sales=trim($_POST['sales']);
		}
		if(!empty($_POST['is_del'])&&is_numeric($_POST['is_del'])){
			$is_del=trim($_POST['is_del']);
		}							
		$goodsObject = new goods_class($this->seller['seller_id']);

		$goodsUpdateData['sell_price']=$sales;

		$goodsUpdateData['market_price']=$advice;

		$goodsUpdateData['store_nums']=$stocks;

		$goodsUpdateData['is_del']=$is_del;	

		$goodsObject->updateByGroup($_POST['id'],$goodsUpdateData);
		$this->redirect("goods_list");
		*/

	}	
	//商品列表
	public function goods_list()
	{
		//获取商品分类列表
		$goods_class = new goods_class();
		$tb_category = new IModel('category');
		$this->category = $goods_class->sortdata($tb_category->query(false,'*','name','asc'),0,'--');


		$this->redirect('goods_list');
	}

	//商品列表
	public function goods_report()
	{
		$seller_id = $this->seller['seller_id'];
		$condition = Util::search(IFilter::act(IReq::get('search'),'strict'));

		$where  = 'go.seller_id='.$seller_id;
		$where .= $condition ? " and ".$condition : "";

		$goodHandle = new IQuery('goods as go');
		$goodHandle->order  = "go.id desc";
		$goodHandle->fields = "go.*";
		$goodHandle->where  = $where;
		$goodList = $goodHandle->find();

		//构建 Excel table;
		$strTable ='<table width="500" border="1">';
		$strTable .= '<tr>';
		$strTable .= '<td style="text-align:center;font-size:12px;">Commodity name</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="160">classification</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">price</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">stock</td>';
		$strTable .= '</tr>';

		foreach($goodList as $k=>$val){
			$strTable .= '<tr>';
			$strTable .= '<td style="text-align:center;font-size:12px;">&nbsp;'.$val['name'].'</td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.goods_class::getGoodsCategory($val['id']).' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['sell_price'].' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['store_nums'].' </td>';
			$strTable .= '</tr>';
		}
		$strTable .='</table>';
		unset($goodList);
		$reportObj = new report();
		$reportObj->setFileName('goods');
		$reportObj->toDownload($strTable);
		exit();
	}
	//商品分页下载
	public function excel_goods_list_page(){
		$page = IReq::get('page') ? IFilter::act(IReq::get('page'),'int') : 1;
		$page_start=($page-1)*20;
		$goodHandle = new IQuery('goods as go');
		$goodHandle->order  = "go.id desc";
		$goodHandle->fields = "go.*";
		$goodHandle->limit = $page_start.",20";
		if(IReq::get('plat')){
			$where = " go.is_share = 1 and go.seller_id = 0 and go.is_del = 0";
			$table_name='Platform  goods_by_page_'.$page;
		}else{
			$table_name=$this->seller['seller_name'].'\' goods_by_page_'.$page;
			$is_del=IReq::get('del') ? 'go.is_del='.IFilter::act(IReq::get('del'),'int') : 'go.is_del != 1';
			$where = " go.seller_id=".$this->seller['seller_id']." and ".$is_del;			
		}

		$goodHandle->where  = $where;
		$goodsList = $goodHandle->find();

		$strTable ='<table width="500" border="1">';
		$strTable .= '<tr>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="*">Commodity name</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">barcode</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">goods_no</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="160">classification</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">price</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">stock</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">sales volume</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">Release time</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">state</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">Subordinate merchant</td>';
		$strTable .= '</tr>';

		foreach($goodsList as $k=>$val){

			$strTable .= '<tr>';
			$strTable .= '<td style="text-align:center;font-size:12px;">&nbsp;'.$val['name'].'</td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['barcode'].' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['goods_no'].' </td>';

			$strTable .= '<td style="text-align:left;font-size:12px;">'.goods_class::getGoodsCategory($val['id']).' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['sell_price'].' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['store_nums'].' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['sale'].' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['create_time'].' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.goods_class::statusText($val['is_del']).' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['true_name'].'&nbsp;</td>';			
			$strTable .= '</tr>';
		}
		$strTable .='</table>';
		unset($goodsList);
		//echo $strTable;EXIT;
		$reportObj = new report();
		$reportObj->setFileName($table_name);
		$reportObj->toDownload($strTable);
		exit();				

	}
	//商品分类下载
	
	public function excel_goods_list(){
		if($_GET['class_id']){
			//$class_arr='2,aa';
			$class_arr=explode(',',$_GET['class_id']);
			$id = $class_arr[0];
			$join=" join category_extend as c on go.id = c.goods_id";
			$where=" c.category_id = ".$id;	
			$table='goods as go';	

			$where .= " and go.is_del != 1 and go.seller_id=".$this->seller['seller_id'];
			//拼接sql
			$goodsHandle = new IQuery($table);
			$goodsHandle->order    = "go.sort asc,go.id desc";
			$goodsHandle->distinct = "go.id";
			$goodsHandle->fields   = "go.id";
			$goodsHandle->join     = $join;
			$goodsHandle->where    = $where;
			$goodsHandle->limit    = 'all';
			$goodsList = $goodsHandle->find();
			
			if(empty($goodsList)){
				exit("NO goods");
			}
			$total_count=count($goodsList);
			if($total_count==0){
				exit("NO goods");
			}			
			$size_count=500;
			$str='<tr><td>&nbsp;</td><td>Total:&nbsp;'.$total_count.'</td><td>&nbsp;</td></tr>';
			for($i=0;$i<ceil($total_count/$size_count);$i++){
				$num=($i+1)*$size_count;
				$str .='<tr><td>&nbsp;</td>';
				$str .='<td><a href='.'/seller/fill_goods_report/id/'.$id.'/c_name/'.$class_arr[1].' target="_blank">'.$class_arr[1].'-'.($i*$size_count).'->'.$num.'</a><td>';				
				$str .='<td><a href='.'/seller/fill_goods_report/id/'.$id.'/c_name/'.$class_arr[1].' target="_blank">export</a><td></tr>';
			}
			echo $str;		
		}else{
			//$join=" join category_extend as c,goods as d on go.id = c.category_id,c.goods_id=d.id";
			$goodsHandle = new IQuery('category as go,category_extend as c,goods as d');
			$goodsHandle->order    = "go.id desc";
			$goodsHandle->fields   = "distinct(go.id), go.name";
			//$goodsHandle->join     = $join;
			$goodsHandle->where    = "go.id = c.category_id and c.goods_id=d.id and d.seller_id=".$this->seller['seller_id']." and d.is_del!=1";
			$goodsHandle->limit    = 'all';
			$goodsList = $goodsHandle->find();
			$tmp_data=array();
			$tmp_data['classfy']=$goodsList;
			$this->setRenderData($tmp_data);
			$this->redirect("excel_goods_list",false);	
		}

		/**
		$sellergoods = new IModel('user_goods_copyrecord');
		$cols=array('copyfrom_id');
		$where="seller_id=".$this->seller['seller_id']." and copyfrom_id!=0";
		$sellerArray=$sellergoods->query($where,$cols,'','','all');
		$idArray=array();
		if(!empty($sellerArray)){
			foreach ($sellerArray as $key => $value) {
				$idArray[]=$value['copyfrom_id'];
			}
		}
		$tmp_data=array();
		$tmp_data['idArray']=$idArray;
		$this->setRenderData($tmp_data);
		*/
	}

	//商品导出 Excel=>根据分类来
	public function fill_goods_report()
	{
		

		//搜索条件
		$search = IFilter::act(IReq::get('id'),'int');
		//条件筛选处理
		//list($join,$where) = goods_class::getSearchCondition($search);
		$join=" join category_extend as c on go.id = c.goods_id";
		$where=" c.category_id = ".$search." and go.seller_id=".$this->seller['seller_id'];;	
		$table='goods as go';		


		$where .= " and go.is_del != 1";
		//拼接sql
		$goodsHandle = new IQuery($table);
		$goodsHandle->order    = "go.sort asc,go.id desc";
		$goodsHandle->distinct = "go.id";
		$goodsHandle->fields   = "go.id, go.img,go.name,go.barcode,go.goods_no,go.sell_price,go.store_nums,go.sale,go.is_del,go.create_time".$new_fields;
		$goodsHandle->join     = $join;
		$goodsHandle->where    = $where;
		$goodsHandle->limit    = 'all';
		$goodsList = $goodsHandle->find();
		if(empty($goodsList)){
			exit("NO goods");
		}
		$reportObj = new report();
		/**
		//$reportObj->setFileName($this->seller['seller_name'].'\' goods_by_category_'.IReq::get('c_name'));
		$letter = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N');
		//表头数组
		$tableheader = array('image','Commodity name','goods_no',
							'classification','price','stock','sales volume',
							'Release time','state','Subordinate merchant','category');		
		
		$newarray=array();

		foreach($goodsList as $k=>$val){
			$strTable=array();
			$strTable[]= $val['img'];
			$strTable[]= $val['name'];
			$strTable[]= $val['goods_no'];

			$strTable[]= goods_class::getGoodsCategory($val['id']);
			$strTable[]= $val['sell_price'];
			$strTable[]= $val['store_nums'];
			$strTable[]= $val['sale'];
			$strTable[]= $val['create_time'];
			$strTable[]= goods_class::statusText($val['is_del']);
			$strTable[]= $val['true_name'];
		    $strTable[]= $val['cate'];	
		    $newarray[]=$strTable;		

		}
		$reportObj->setFileName($this->seller['seller_name'].'\' goods_by_category_'.IReq::get('c_name'));

		$reportObj->toDownload_new($newarray,$letter,$tableheader);
		exit();
		*/
		
		//构建 Excel table;
		$strTable ='<table width="500" border="1">';
		$strTable .= '<tr>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="*">Commodity name</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">barcode</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">goods_no</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="160">classification</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">price</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">stock</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">sales volume</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">Release time</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">state</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="60">Subordinate merchant</td>';
		$strTable .= $new_fields ? '<td style="text-align:center;font-size:12px;" width="160">category</td>' : '';
		$strTable .= '</tr>';

		foreach($goodsList as $k=>$val){

			$strTable .= '<tr>';
			$strTable .= '<td style="text-align:center;font-size:12px;">&nbsp;'.$val['name'].'</td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['barcode'].' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['goods_no'].' </td>';

			$strTable .= '<td style="text-align:left;font-size:12px;">'.goods_class::getGoodsCategory($val['id']).' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['sell_price'].' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['store_nums'].' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['sale'].' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['create_time'].' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.goods_class::statusText($val['is_del']).' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['true_name'].'&nbsp;</td>';
		    $strTable .= $new_fields ? '<td style="text-align:left;font-size:12px;">'.$val['cate'].'&nbsp;</td>': '';			
			$strTable .= '</tr>';
		}
		$strTable .='</table>';//echo $strTable;exit;
		unset($goodsList);
		//echo $strTable;EXIT;
		$reportObj = new report();
		$reportObj->setFileName($this->seller['seller_name'].'\' goods_by_category_'.IReq::get('c_name'));
		$reportObj->toDownload($strTable);
		exit();
		
	}	
	//商品删除
	public function goods_del()
	{
		//post数据
	    $id = IFilter::act(IReq::get('id'),'int');

	    //生成goods对象
	    $goods = new goods_class();
	    $goods->seller_id = $this->seller['seller_id'];

	    if($id)
		{
			if(is_array($id))
			{
				foreach($id as $key => $val)
				{
					$goods->del($val);
				}
			}
			else
			{
				$goods->del($id);
			}
		}
		$this->redirect("goods_list");
	}


	//商品状态修改
	public function goods_status()
	{
	    $id        = IFilter::act(IReq::get('id'),'int');
		$is_del    = IFilter::act(IReq::get('is_del'),'int');
		$is_del    = $is_del === 0 ? 0 : $is_del; //不能等于0直接上架
		$seller_id = $this->seller['seller_id'];

		$goodsDB = new IModel('goods');
		$goodsDB->setData(array('is_del' => $is_del));

	    if($id)
		{
			if(is_array($id))
			{
				foreach($id as $key => $val)
				{
					$goodsDB->update("id = ".$val." and seller_id = ".$seller_id);
				}
			}
			else
			{
				$goodsDB->update("id = ".$val." and seller_id = ".$seller_id);
			}
		}
		$this->redirect("goods_list");
	}

	//规格删除
	public function spec_del()
	{
		$id = IFilter::act(IReq::get('id'),'int');

		if($id)
		{
			$idString = is_array($id) ? join(',',$id) : $id;
			$specObj  = new IModel('spec');
			$specObj->del("id in ( {$idString} ) and seller_id = ".$this->seller['seller_id']);
			$this->redirect('spec_list');
		}
		else
		{
			$this->redirect('spec_list',false);
			Util::showMessage('Please select the specifications to be deleted.');
		}
	}
	//修改排序
	public function ajax_sort()
	{
		$id   = IFilter::act(IReq::get('id'),'int');
		$sort = IFilter::act(IReq::get('sort'),'int');

		$goodsDB = new IModel('goods');
		$goodsDB->setData(array('sort' => $sort));
		$goodsDB->update("id = {$id} and seller_id = ".$this->seller['seller_id']);
	}
	
	//修改销售价格
	public function ajax_sellprice()
	{
		$id   = IFilter::act(IReq::get('id'),'int');
		$sellprice = IFilter::act(IReq::get('sell_price'));

		$goodsDB = new IModel('goods');
		$goodsDB->setData(array('sell_price' => $sellprice));
		$goodsDB->update("id = {$id} and seller_id = ".$this->seller['seller_id']);
	}

	//修改库存
	public function ajax_storenums()
	{
		$id   = IFilter::act(IReq::get('id'),'int');
		$store_nums = IFilter::act(IReq::get('store_nums'),'int');

		$goodsDB = new IModel('goods');
		$goodsDB->setData(array('store_nums' => $store_nums));
		$goodsDB->update("id = {$id} and seller_id = ".$this->seller['seller_id']);
	}	

	//咨询回复
	public function refer_reply()
	{
		$rid     = IFilter::act(IReq::get('refer_id'),'int');
		$content = IFilter::act(IReq::get('content'),'text');

		if($rid && $content)
		{
			$tb_refer = new IModel('refer');
			$seller_id = $this->seller['seller_id'];//商户id
			$data = array(
				'answer' => $content,
				'reply_time' => date('Y-m-d H:i:s'),
				'seller_id' => $seller_id,
				'status' => 1
			);
			$tb_refer->setData($data);
			$tb_refer->update("id=".$rid);
		}
		$this->redirect('refer_list');
	}
	/**
	 * @brief查看订单
	 */
	public function order_show()
	{
		//获得post传来的值
		$order_id = IFilter::act(IReq::get('id'),'int');
		$data = array();
		if($order_id)
		{
			$order_show = new Order_Class();
			$data = $order_show->getOrderShow($order_id);
			if($data)
			{
				//获得折扣前的价格
			 	$rule = new ProRule($data['real_amount']);
			 	$this->result = $rule->getInfo();

		 		//获取地区
		 		$data['area_addr'] = join('&nbsp;',area::name($data['province'],$data['city'],$data['area']));

			 	$this->setRenderData($data);
				$this->redirect('order_show',false);
			}
		}
		if(!$data)
		{
			$this->redirect('order_list');
		}
	}
	/**
	 * @brief 发货订单页面
	 */
	public function order_deliver()
	{
		$order_id = IFilter::act(IReq::get('id'),'int');
		$data = array();
		if($order_id)
		{
			$order_show = new Order_Class();
			$data = $order_show->getOrderShow($order_id);
		}
		$this->setRenderData($data);
		$this->redirect('order_deliver');
	}
	/**
	 * @brief 发货操作
	 */
	public function order_delivery_doc()
	{
	 	//获得post变量参数
	 	$order_id = IFilter::act(IReq::get('id'),'int');

	 	//发送的商品关联
	 	$sendgoods = IFilter::act(IReq::get('sendgoods'));

	 	if(!$sendgoods)
	 	{
	 		die('Please select the goods to be shipped.');
	 	}

	 	Order_Class::sendDeliveryGoods($order_id,$sendgoods,$this->seller['seller_id'],'seller');
	 	$this->redirect('order_list');
	}
	/**
	 * @brief 完成或作废订单页面
	 **/
	public function order_complete()
	{	
		
		//去掉左侧菜单和上部导航
		$this->layout='';
		$order_id = IFilter::act(IReq::get('id'),'int');
		$type     = IFilter::act(IReq::get('type'),'int');
		$order_no = IFilter::act(IReq::get('order_no'));
		$sent_type = IReq::get('is_send');
		
		//oerder表的对象
		$tb_order = new IModel('order');
		$order_array=array(
			'status'          => $type,
			'completion_time' => ITime::getDateTime(),
		);
		if($sent_type){
			$order_array['takeself']=ISafe::get('seller_id');
		}		
		$tb_order->setData($order_array);

		$tb_order->update('id='.$order_id);

		//生成订单日志
		$tb_order_log = new IModel('order_log');
		$action = 'to void';
		$note   = 'order【'.$order_no.'】Void success';

		if($type=='5')
		{
			$action = 'finished';
			$note   = 'order【'.$order_no.'】Successful completion';

			//完成订单并且进行支付
			Order_Class::updateOrderStatus($order_no);

			$orderInfo=$tb_order->getObj('id='.$order_id,array('user_id','order_amount','pay_type'));


			

			$memberObj = new IModel('member as me,user as us');

			$userInfo=$memberObj->getObj('me.user_id=us.id and us.id='.$orderInfo['user_id'],array('me.user_id','me.balance','us.username','us.telephone','us.email'));

			if($orderInfo['pay_type']==0){
				if($setInfo=Commonfunc::WebSet_allowed(array('key'=>2,'username'=>$userInfo['username']))){

					$now_seller=ISafe::get('seller_id');
					
					$return_amount=$orderInfo['order_amount']*($setInfo['return_percent'][$now_seller]*0.01);

					$new_amount=$userInfo['balance']+$return_amount;
					

		          	$balanceArr=array(
		                'balance'=>$new_amount,
		                'money'=>$return_amount,
		                'type'=>3,
		                'user_id'=>$orderInfo['user_id'],
		                'order_no'=>$order_no,
		            );       
		            Order_Class::balanceUpdate($balanceArr);				
				}				
			}


			if(Commonfunc::WebSet_allowed(array('key'=>1,'username'=>$userInfo['username']))){
				if($userInfo['telephone']){
					//开始发送短信
					$sms_Obj = new Sms(IWeb::$app->config['sms_apiKey']);

					$text=smsTemplate::seller_confirm_order_by_mobile(array('order_no'=>$order_no,
						'amount'=>$return_amount,'username'=>$userInfo['username']));
					
					$sms_data=array(
							'mobile'=>$userInfo['telephone'],
							'text'=>$text
						);

					$sms_Obj->send_mobile($sms_data);	
				} 				
			}

			/**


			*/ 



			//增加用户评论商品机会
			Order_Class::addGoodsCommentChange($order_id);

			$logObj = new log('db');
			$logObj->write('operation',array("seller:".$this->seller['seller_name'],"Order update to complete",'Order No.：'.$order_no));
		}
		else
		{
			Order_class::resetOrderProp($order_id);

			$logObj = new log('db');
			$logObj->write('operation',array("seller:".$this->seller['seller_name'],"Order update to void",'Order No.：'.$order_no));
		}

		$tb_order_log->setData(array(
			'order_id' => $order_id,
			'user'     => $this->seller['seller_name'],//$this->admin['admin_name'],
			'action'   => $action,
			'result'   => 'Successful',
			'note'     => $note,
			'addtime'  => ITime::getDateTime(),
		));
		$tb_order_log->add();
		die('success');
	}
	//订单导出 Excel
	public function order_report()
	{
		$seller_id = $this->seller['seller_id'];
		$condition = Util::search(IFilter::act(IReq::get('search'),'strict'));

		$where  = "go.seller_id = ".$seller_id;
		$where .= $condition ? " and ".$condition : "";

		//拼接sql
		$orderHandle = new IQuery('order_goods as og');
		$orderHandle->order  = "o.id desc";
		$orderHandle->fields = "o.*,p.name as payment_name";
		$orderHandle->join   = "left join goods as go on go.id=og.goods_id left join order as o on o.id=og.order_id left join payment as p on p.id = o.pay_type";
		$orderHandle->where  = $where;
		$orderList = $orderHandle->find();

		//构建 Excel table
		$strTable ='<table width="500" border="1">';
		$strTable .= '<tr>';
		$strTable .= '<td style="text-align:center;font-size:12px;width:120px;">Order number</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="100">date</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="*">consignee</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="*">tel</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="*">Order amount</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="*">Actual payment</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="*">Payment method</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="*">Payment status</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="*">Delivery status</td>';
		$strTable .= '<td style="text-align:center;font-size:12px;" width="*">Commodity information</td>';
		$strTable .= '</tr>';

		foreach($orderList as $k=>$val){
			$strTable .= '<tr>';
			$strTable .= '<td style="text-align:center;font-size:12px;">&nbsp;'.$val['order_no'].'</td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['create_time'].' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['accept_name'].' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">&nbsp;'.$val['telphone'].'&nbsp;'.$val['mobile'].' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['payable_amount'].' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['real_amount'].' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['payment_name'].' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.Order_Class::getOrderPayStatusText($val).' </td>';
			$strTable .= '<td style="text-align:left;font-size:12px;">'.Order_Class::getOrderDistributionStatusText($val).' </td>';

			$orderGoods = Order_class::getOrderGoods($val['id']);

			$strGoods="";
			foreach($orderGoods as $good){
				$strGoods .= "Commodity number：".$good->goodsno." Commodity name：".$good->name;
				if ($good->value!='') $strGoods .= " Specifications：".$good->value;
				$strGoods .= "<br />";
			}
			unset($orderGoods);

			$strTable .= '<td style="text-align:left;font-size:12px;">'.$strGoods.' </td>';
			$strTable .= '</tr>';
		}
		$strTable .='</table>';
		//输出成EXcel格式文件并下载
		$reportObj = new report();
		$reportObj->setFileName('order');
		$reportObj->toDownload($strTable);
		exit();
	}

	//修改商户信息
	public function seller_edit()
	{
		$seller_id = $this->seller['seller_id'];
		$sellerDB        = new IModel('seller');
		$this->sellerRow = $sellerDB->getObj('id = '.$seller_id);
		$this->redirect('seller_edit');
	}

	/**
	 * @brief 商户的增加动作
	 */
	public function seller_add()
	{
		$seller_id   = $this->seller['seller_id'];
		$email       = IFilter::act(IReq::get('email'));
		$password    = IFilter::act(IReq::get('password'));
		$repassword  = IFilter::act(IReq::get('repassword'));
		$phone       = IFilter::act(IReq::get('phone'));
		$mobile      = IFilter::act(IReq::get('mobile'));
		$province    = IFilter::act(IReq::get('province'),'int');
		$city        = IFilter::act(IReq::get('city'),'int');
		$area        = IFilter::act(IReq::get('area'),'int');
		$address     = IFilter::act(IReq::get('address'));
		$account     = IFilter::act(IReq::get('account'));
		$server_num  = IFilter::act(IReq::get('server_num'));
		$home_url    = IFilter::act(IReq::get('home_url'));

		if(!$seller_id && $password == '')
		{
			$errorMsg = 'Please enter a password！';
		}

		if($password != $repassword)
		{
			$errorMsg = 'Two times the password is not consistent！';
		}

		//操作失败表单回填
		if(isset($errorMsg))
		{
			$this->sellerRow = $_POST;
			$this->redirect('seller_edit',false);
			Util::showMessage($errorMsg);
		}

		//待更新的数据
		$sellerRow = array(
			'account'   => $account,
			'phone'     => $phone,
			'mobile'    => $mobile,
			'email'     => $email,
			'address'   => $address,
			'province'  => $province,
			'city'      => $city,
			'area'      => $area,
			'server_num'=> $server_num,
			'home_url'  => $home_url,
		);

		//创建商家操作类
		$sellerDB   = new IModel("seller");

		//修改密码
		if($password)
		{
			$sellerRow['password'] = md5($password);
		}

		$sellerDB->setData($sellerRow);
		$sellerDB->update("id = ".$seller_id);

		$this->redirect('seller_edit');
	}

	//[团购]添加修改[单页]
	function regiment_edit()
	{
		$id = IFilter::act(IReq::get('id'),'int');

		if($id)
		{
			$regimentObj = new IModel('regiment');
			$where       = 'id = '.$id;
			$regimentRow = $regimentObj->getObj($where);
			if(!$regimentRow)
			{
				$this->redirect('regiment_list');
			}

			//促销商品
			$goodsObj = new IModel('goods');
			$goodsRow = $goodsObj->getObj('id = '.$regimentRow['goods_id']);

			$result = array(
				'isError' => false,
				'data'    => $goodsRow,
			);
			$regimentRow['goodsRow'] = JSON::encode($result);
			$this->regimentRow = $regimentRow;
		}
		$this->redirect('regiment_edit');
	}

	//[团购]删除
	function regiment_del()
	{
		$id = IFilter::act(IReq::get('id'),'int');
		if($id)
		{
			$regObj     = new IModel('regiment');

			if(is_array($id))
			{
				$idStr = join(',',$id);
				$where = ' id in ('.$idStr.')';
				$uwhere= ' regiment_id in ('.$idStr.')';
			}
			else
			{
				$where  = 'id = '.$id;
				$uwhere = 'regiment_id = '.$id;
			}
			$regObj->del($where);
			$this->redirect('regiment_list');
		}
		else
		{
			$this->redirect('regiment_list',false);
			Util::showMessage('Please select the ID value to be deleted');
		}
	}

	//[团购]添加修改[动作]
	function regiment_edit_act()
	{
		$id      = IFilter::act(IReq::get('id'),'int');
		$goodsId = IFilter::act(IReq::get('goods_id'),'int');

		$dataArray = array(
			'id'        	=> $id,
			'title'     	=> IFilter::act(IReq::get('title','post')),
			'start_time'	=> IFilter::act(IReq::get('start_time','post')),
			'end_time'  	=> IFilter::act(IReq::get('end_time','post')),
			'is_close'      => 1,
			'intro'     	=> IFilter::act(IReq::get('intro','post')),
			'goods_id'      => $goodsId,
			'store_nums'    => IFilter::act(IReq::get('store_nums','post')),
			'limit_min_count' => IFilter::act(IReq::get('limit_min_count','post'),'int'),
			'limit_max_count' => IFilter::act(IReq::get('limit_max_count','post'),'int'),
			'regiment_price'=> IFilter::act(IReq::get('regiment_price','post')),
		);

		if($goodsId)
		{
			$goodsObj = new IModel('goods');
			$where    = 'id = '.$goodsId.' and seller_id = '.$this->seller['seller_id'];
			$goodsRow = $goodsObj->getObj($where);

			//商品信息不存在
			if(!$goodsRow)
			{
				$this->regimentRow = $dataArray;
				$this->redirect('regiment_edit',false);
				Util::showMessage('Please select the merchant own goods');
			}

			//处理上传图片
			if(isset($_FILES['img']['name']) && $_FILES['img']['name'] != '')
			{
				$uploadObj = new PhotoUpload();
				$photoInfo = $uploadObj->run();
				$dataArray['img'] = $photoInfo['img']['img'];
			}
			else
			{
				$dataArray['img'] = $goodsRow['img'];
			}

			$dataArray['sell_price'] = $goodsRow['sell_price'];
		}
		else
		{
			$this->regimentRow = $dataArray;
			$this->redirect('regiment_edit',false);
			Util::showMessage('Please select the goods to be related.');
		}

		$regimentObj = new IModel('regiment');
		$regimentObj->setData($dataArray);

		if($id)
		{
			$where = 'id = '.$id;
			$regimentObj->update($where);
		}
		else
		{
			$regimentObj->add();
		}
		$this->redirect('regiment_list');
	}

	//结算单修改
	public function bill_edit()
	{
		$id = IFilter::act(IReq::get('id'),'int');
		$billRow = array();

		if($id)
		{
			$billDB  = new IModel('bill');
			$billRow = $billDB->getObj('id = '.$id.' and seller_id = '.$this->seller['seller_id']);
		}

		$this->billRow = $billRow;
		$this->redirect('bill_edit');
	}

	//结算单删除
	public function bill_del()
	{
		$id = IFilter::act(IReq::get('id'),'int');

		if($id)
		{
			$billDB = new IModel('bill');
			$billDB->del('id = '.$id.' and seller_id = '.$this->seller['seller_id'].' and is_pay = 0');
		}

		$this->redirect('bill_list');
	}

	//结算单更新
	public function bill_update()
	{
		$id            = IFilter::act(IReq::get('id'),'int');
		$start_time    = IFilter::act(IReq::get('start_time'));
		$end_time      = IFilter::act(IReq::get('end_time'));
		$apply_content = IFilter::act(IReq::get('apply_content'));

		$billDB = new IModel('bill');

		if($id)
		{
			$billRow = $billDB->getObj('id = '.$id);
			if($billRow['is_pay'] == 0)
			{
				$billDB->setData(array('apply_content' => $apply_content));
				$billDB->update('id = '.$id.' and seller_id = '.$this->seller['seller_id']);
			}
		}
		else
		{
			//判断是否存在未处理的申请
			$isSubmitBill = $billDB->getObj(" seller_id = ".$this->seller['seller_id']." and is_pay = 0");
			if($isSubmitBill)
			{
				$this->redirect('bill_list',false);
				Util::showMessage('Please wait patiently for the administrator to be able to submit the application again');
			}

			$queryObject = CountSum::getSellerGoodsFeeQuery($this->seller['seller_id'],$start_time,$end_time,0);
			$countData   = CountSum::countSellerOrderFee($queryObject->find());

			if($countData['orderAmountPrice'] > 0)
			{
				$replaceData = array(
					'{startTime}'     => $start_time,
					'{endTime}'       => $end_time,
					'{goodsNums}'     => count($countData['order_goods_ids']),
					'{goodsSums}'     => $countData['goodsSum'],
					'{deliveryPrice}' => $countData['deliveryPrice'],
					'{protectedPrice}'=> $countData['insuredPrice'],
					'{taxPrice}'      => $countData['taxPrice'],
					'{totalSum}'      => $countData['orderAmountPrice'],
				);

				$billString = AccountLog::sellerBillTemplate($replaceData);
				$data = array(
					'seller_id'  => $this->seller['seller_id'],
					'apply_time' => date('Y-m-d H:i:s'),
					'apply_content' => IFilter::act(IReq::get('apply_content')),
					'start_time' => $start_time,
					'end_time' => $end_time,
					'log' => $billString,
					'order_goods_ids' => join(",",$countData['order_goods_ids']),
				);
				$billDB->setData($data);
				$billDB->add();
			}
			else
			{
				$this->redirect('bill_list',false);
				Util::showMessage('There is no settlement in the current time period.');
			}
		}
		$this->redirect('bill_list');
	}

	//计算应该结算的货款明细
	public function countGoodsFee()
	{
		$seller_id   = $this->seller['seller_id'];
		$start_time  = IFilter::act(IReq::get('start_time'));
		$end_time    = IFilter::act(IReq::get('end_time'));

		$queryObject = CountSum::getSellerGoodsFeeQuery($seller_id,$start_time,$end_time,0);
		$countData   = CountSum::countSellerOrderFee($queryObject->find());

		if($countData['orderAmountPrice'] > 0)
		{
			$replaceData = array(
				'{startTime}'     => $start_time,
				'{endTime}'       => $end_time,
				'{goodsNums}'     => count($countData['order_goods_ids']),
				'{goodsSums}'     => $countData['goodsSum'],
				'{deliveryPrice}' => $countData['deliveryPrice'],
				'{protectedPrice}'=> $countData['insuredPrice'],
				'{taxPrice}'      => $countData['taxPrice'],
				'{totalSum}'      => $countData['orderAmountPrice'],
			);

			$billString = AccountLog::sellerBillTemplate($replaceData);
			$result     = array('result' => 'success','data' => $billString);
		}
		else
		{
			$result = array('result' => 'fail','data' => 'Currently no money can be settled');
		}

		die(JSON::encode($result));
	}

	/**
	 * @brief 显示评论信息
	 */
	function comment_edit()
	{
		$cid = IFilter::act(IReq::get('cid'),'int');

		if(!$cid)
		{
			$this->comment_list();
			return false;
		}
		$query = new IQuery("comment as c");
		$query->join = "left join goods as goods on c.goods_id = goods.id left join user as u on c.user_id = u.id";
		$query->fields = "c.*,u.username,goods.name,goods.seller_id";
		$query->where = "c.id=".$cid." and goods.seller_id = ".$this->seller['seller_id'];
		$items = $query->find();

		if($items)
		{
			$this->comment = current($items);
			$this->redirect('comment_edit');
		}
		else
		{
			$this->comment_list();
			$msg = 'No relevant records found！';
			Util::showMessage($msg);
		}
	}

	/**
	 * @brief 回复评论
	 */
	function comment_update()
	{
		$id = IFilter::act(IReq::get('id'),'int');
		$recontent = IFilter::act(IReq::get('recontents'));
		if($id)
		{
			$commentDB = new IQuery('comment as c');
			$commentDB->join = 'left join goods as go on go.id = c.goods_id';
			$commentDB->where= 'c.id = '.$id.' and go.seller_id = '.$this->seller['seller_id'];
			$checkList = $commentDB->find();
			if(!$checkList)
			{
				IError::show(403,'The product does not belong to you, you can not comment on its reply');
			}

			$updateData = array(
				'recontents' => $recontent,
				'recomment_time' => ITime::getDateTime(),
			);
			$commentDB = new IModel('comment');
			$commentDB->setData($updateData);
			$commentDB->update('id = '.$id);
		}
		$this->redirect('comment_list');
	}

	//商品退款详情
	function refundment_show()
	{
	 	//获得post传来的退款单id值
	 	$refundment_id = IFilter::act(IReq::get('id'),'int');
	 	$data = array();
	 	if($refundment_id)
	 	{
	 		$tb_refundment = new IQuery('refundment_doc as c');
	 		$tb_refundment->join=' left join order as o on c.order_id=o.id left join user as u on u.id = c.user_id';
	 		$tb_refundment->fields = 'o.order_no,o.create_time,u.username,c.*';
	 		$tb_refundment->where = 'c.id='.$refundment_id.' and seller_id = '.$this->seller['seller_id'];
	 		$refundment_info = $tb_refundment->find();
	 		if($refundment_info)
	 		{
	 			$data = current($refundment_info);
	 			$this->setRenderData($data);
	 			$this->redirect('refundment_show',false);
	 		}
	 	}

	 	if(!$data)
		{
			$this->redirect('refundment_list');
		}
	}

	//商品退款操作
	function refundment_update()
	{
		$id           = IFilter::act(IReq::get('id'),'int');
		$pay_status   = IFilter::act(IReq::get('pay_status'),'int');
		$dispose_idea = IFilter::act(IReq::get('dispose_idea'));

		//商户处理退款
		if($id && Order_Class::isSellerRefund($id,$this->seller['seller_id']) == 2)
		{
			$tb_refundment_doc = new IModel('refundment_doc');
			$updateData = array(
				'dispose_time' => ITime::getDateTime(),
				'dispose_idea' => $dispose_idea,
				'pay_status'   => $pay_status,
			);
			$tb_refundment_doc->setData($updateData);
			$tb_refundment_doc->update('id = '.$id);

			if($pay_status == 2)
			{
				$result = Order_Class::refund($id,$this->seller['seller_id'],'seller');
				if(!$result)
				{
					die('Refund failed');
				}
			}
		}
		$this->redirect('refundment_list');
	}

	function goods_del_by_admin(){
		$sellergoods = new IModel('goods');
		$where = 'seller_id=8';
		$cols=array('id');
		$sellerArray=$sellergoods->query($where,$cols,'','','all');
		$goods_catDB     = new IModel('category_extend');
		$goodsAttrDB = new IModel('goods_attribute');
		$goodsPhotoRelationDB = new IModel('goods_photo_relation');
		$productsDB = new IModel('products');		
		foreach($sellerArray as $k=>$v){
			$sellergoods->del('id='.$v['id']." and seller_id=".$this->seller['seller_id']);
			$goods_catDB->del('goods_id='.$v['id']);
			$goodsAttrDB->del('goods_id='.$v['id']);
			$goodsPhotoRelationDB->del('goods_id='.$v['id']);
			$productsDB->del('goods_id='.$v['id']);
		}

	}

	//商品复制
	function goods_copy()
	{
		$idArray = explode(',',IReq::get('id'));
		$idArray = IFilter::act($idArray,'int');

		$catIds = explode(',',IReq::get('catIds'));

		
		$goodsDB     = new IModel('goods');
		$goods_catDB     = new IModel('category_extend');
		$goodsAttrDB = new IModel('goods_attribute');
		$goodsPhotoRelationDB = new IModel('goods_photo_relation');
		$productsDB = new IModel('products');
		$copyrecordgoods = new IModel('user_goods_copyrecord');

		$goodsData = $goodsDB->query('id in ('.join(',',$idArray).') and is_share = 1 and is_del = 0 and seller_id = 0','*');
		if($goodsData)
		{
			foreach($goodsData as $key => $val)
			{		
				//判断是否重复
				/**
				if( $goodsDB->getObj('seller_id = '.$this->seller['seller_id'].' and name = "'.addslashes($val['name']).'"') )
				{
					die('Goods cannot be duplicated');
				}
				*/
				if($copyrecordgoods->getObj('seller_id = '.$this->seller['seller_id'].' and copyfrom_id ='.$val['id']) )
				{
					die('Goods cannot be duplicated');
				}				
				
				$oldId = $val['id'];

				//商品数据
				unset($val['id'],$val['visit'],$val['favorite'],$val['sort'],$val['comments'],$val['sale'],$val['grade'],$val['is_share']);
				$val['seller_id'] = $this->seller['seller_id'];
				$goods_no_arr=array();
				$goods_barcode_arr=array();
				$goods_no_arr=explode('-',$val['goods_no']);
				$goods_barcode_arr=explode('-',$val['barcode']);
				$goods_spec_count=count($goods_no_arr);				
				$val['goods_no'] = $goods_spec_count <2 ? $val['goods_no'].'-'.$this->seller['seller_id'] : 
								$goods_no_arr[0].'-'.$this->seller['seller_id'].'-'.$goods_no_arr[1];
				$val['barcode'] = $goods_spec_count <2 ? $val['barcode'].'-'.$this->seller['seller_id'] : 
								$goods_barcode_arr[0].'-'.$this->seller['seller_id'].'-'.$goods_barcode_arr[1];				
				/**
				if($val['description']){
					$val['description'] .= addslashes($val['description']);
				}
				
				if($val['content']){
					$val['content'] = addslashes($val['content']);
				}
				*/

				$val['name']=addslashes($val['name']);
				$val['is_del']=2;
				$goodsDB->setData($val);
				$goods_id = $goodsDB->add();

				$copy_recordDB = new IModel('user_goods_copyrecord');

				$copy_data['goods_id']=$goods_id;
				$copy_data['copyfrom_id']=$oldId;
				$copy_data['seller_id']=$this->seller['seller_id'];
				
				$copy_recordDB->setData($copy_data);
				$copy_id = $copy_recordDB->add();

				//商品属性
				$attrData = $goodsAttrDB->query('goods_id = '.$oldId);
				if($attrData)
				{
					foreach($attrData as $k => $v)
					{
						unset($v['id']);
						$v['goods_id'] = $goods_id;
						$goodsAttrDB->setData($v);
						$goodsAttrDB->add();
					}
				}
				
				//复制分类
				foreach ($catIds as $val){
					$catdata = array('goods_id' => $goods_id , 'category_id' => $val ); 
				    $goods_catDB->setData($catdata);
				    $goods_catDB->add();					
				}

				//商品图片
				$photoData = $goodsPhotoRelationDB->query('goods_id = '.$oldId);
				if($photoData)
				{
					foreach($photoData as $k => $v)
					{
						unset($v['id']);
						$v['goods_id'] = $goods_id;
						$goodsPhotoRelationDB->setData($v);
						$goodsPhotoRelationDB->add();
					}
				}

				//货品
				$productsData = $productsDB->query('goods_id = '.$oldId);
				if($productsData)
				{
					foreach($productsData as $k => $v)
					{
						unset($v['id']);
						//$v['products_no'].= '-'.$this->seller['seller_id'];
						$goods_no_arr=array();
						$goods_barcode_arr=array();						
						$goods_no_arr=explode('-',$v['products_no']);
						$goods_barcode_arr=explode('-',$v['products_barcode']);
						$goods_spec_count=count($goods_no_arr);								
						$v['products_no'] = $goods_spec_count <2 ? $v['goods_no'].'-'.$this->seller['seller_id'] : 
										$goods_no_arr[0].'-'.$this->seller['seller_id'].'-'.$goods_no_arr[1];
						$v['products_barcode'] = $goods_spec_count <2 ? $v['barcode'].'-'.$this->seller['seller_id'] : 
										$goods_barcode_arr[0].'-'.$this->seller['seller_id'].'-'.$goods_barcode_arr[1];								
						$v['goods_id']    = $goods_id;
						$productsDB->setData($v);
						$productsDB->add();
					}
				}
			}
			die('success');
		}
		else
		{
			die('Copy of the goods does not exist');
		}
	}
	
	//商品复制
	function goods_copy2()
	{
		$idArray = explode(',',IReq::get('id'));
		$idArray = IFilter::act($idArray,'int');

		
		$goodsDB     = new IModel('goods');
		$goods_catDB     = new IModel('category_extend');
		$goodsAttrDB = new IModel('goods_attribute');
		$goodsPhotoRelationDB = new IModel('goods_photo_relation');
		$productsDB = new IModel('products');
		$copyrecordgoods = new IModel('user_goods_copyrecord');
		$goodsData = $goodsDB->query('id in ('.join(',',$idArray).') and is_share = 1 and is_del = 0 and seller_id = 0','*');
		if($goodsData)
		{
			foreach($goodsData as $key => $val)
			{
				$goods_name='';
				$goods_name=addslashes($val['name']);
				//判断是否重复
				/**
				if( $goodsDB->getObj('seller_id = '.$this->seller['seller_id'].' and name = "'.$goods_name.'"') )
				{
					continue;
				}
				*/
				if($copyrecordgoods->getObj('seller_id = '.$this->seller['seller_id'].' and copyfrom_id ='.$val['id']) )
				{
					die('Goods cannot be duplicated');
				}					
				$oldId = $val['id'];

				//商品数据
				unset($val['id'],$val['visit'],$val['favorite'],$val['sort'],$val['comments'],$val['sale'],$val['grade'],$val['is_share']);
				$val['seller_id'] = $this->seller['seller_id'];
				/**
				$val['goods_no'] .= '-'.$this->seller['seller_id'];
				$val['barcode'] .= '-'.$this->seller['seller_id'];
				*/
				$goods_no_arr=array();
				$goods_barcode_arr=array();				
				$goods_no_arr=explode('-',$val['goods_no']);
				$goods_barcode_arr=explode('-',$val['barcode']);
				$goods_spec_count=count($goods_no_arr);						
				$val['goods_no'] = $goods_spec_count <2 ? $val['goods_no'].'-'.$this->seller['seller_id'] : 
								$goods_no_arr[0].'-'.$this->seller['seller_id'].'-'.$goods_no_arr[1];
				$val['barcode'] = $goods_spec_count <2 ? $val['barcode'].'-'.$this->seller['seller_id'] : 
								$goods_barcode_arr[0].'-'.$this->seller['seller_id'].'-'.$goods_barcode_arr[1];
				/**
				if($val['description']){
					$val['description'] .= addslashes($val['description']);
				}
				*/										
				//$val['content'] = addslashes($val['content']);
				$val['name']=$goods_name;
				$val['is_del']=2;
				$goodsDB->setData($val);
				$goods_id = $goodsDB->add();
				$copy_recordDB= new IModel('user_goods_copyrecord');

				$copy_data['goods_id']=$goods_id;
				$copy_data['copyfrom_id']=$oldId;
				$copy_data['seller_id']=$this->seller['seller_id'];
				$copy_recordDB->setData($copy_data);
				$copy_id = $copy_recordDB->add();
				//商品属性
				$attrData = $goodsAttrDB->query('goods_id = '.$oldId);
				if($attrData)
				{
					foreach($attrData as $k => $v)
					{
						unset($v['id']);
						$v['goods_id'] = $goods_id;
						$goodsAttrDB->setData($v);
						$goodsAttrDB->add();
					}
				}
				
				//复制商品分类
				if($oldId > 0){
					$catarr = $goods_catDB->query("goods_id = $oldId");
					foreach ($catarr as $val){
						$catdata = array('goods_id' => $goods_id , 'category_id' => $val['category_id'] ); 
					    $goods_catDB->setData($catdata);
					    $goods_catDB->add();
					}
				}
				
				
				//商品图片
				$photoData = $goodsPhotoRelationDB->query('goods_id = '.$oldId);
				if($photoData)
				{
					foreach($photoData as $k => $v)
					{
						unset($v['id']);
						$v['goods_id'] = $goods_id;
						$goodsPhotoRelationDB->setData($v);
						$goodsPhotoRelationDB->add();
					}
				}

				//货品
				$productsData = $productsDB->query('goods_id = '.$oldId);
				if($productsData)
				{
					foreach($productsData as $k => $v)
					{
						unset($v['id']);
						$goods_no_arr=array();
						$goods_barcode_arr=array();						
						$goods_no_arr=explode('-',$v['products_no']);
						$goods_barcode_arr=explode('-',$v['products_barcode']);
						$goods_spec_count=count($goods_no_arr);								
						$v['products_no'] = $goods_spec_count <2 ? $v['goods_no'].'-'.$this->seller['seller_id'] : 
										$goods_no_arr[0].'-'.$this->seller['seller_id'].'-'.$goods_no_arr[1];
						$v['products_barcode'] = $goods_spec_count <2 ? $v['barcode'].'-'.$this->seller['seller_id'] : 
										$goods_barcode_arr[0].'-'.$this->seller['seller_id'].'-'.$goods_barcode_arr[1];								
						//$v['products_no'].= '-'.$this->seller['seller_id'];
						$v['goods_id']    = $goods_id;
						$productsDB->setData($v);
						$productsDB->add();
					}
				}
			}
			die('success');
		}
		else
		{
			die('Copy of the goods does not exist');
		}
	}
	public function  goods_search(){
		$search_type = $_REQUEST['search_type'];
		$keyword = $_REQUEST['keyword'];
		$seller_id = $_REQUEST['seller_id'];
		$goodsSearch = new IModel('goods');
		if($search_type == 'name'){
			$goodsList = $goodsSearch->query("name like '%$keyword%' and seller_id= $seller_id","","","","3");
		}else{
			$goodsList = $goodsSearch->query("goods_no like '%$keyword%' and seller_id= $seller_id","","","","3");
		}
		//讲结果转换为json格式
		$result = json_encode($goodsList);
		echo $result;
	}
	//商家后台取消订单
	public function cancleOrder(){
		$op    = 'cancle';		
		$id    = IFilter::act( IReq::get('id'),'int' );
		$model = new IModel('order');		
		$model->setData(array('status' => 3));
		if($model->update("id = ".$id." and distribution_status = 0 and status = 1"))
		{     

            $orderGoodsObj=new IModel("order_goods");
            $goodsResult=$orderGoodsObj->query('order_id='.$id,array('goods_id','product_id','goods_nums as count'));
            Order_Class::updateStore($goodsResult);                                        
            //修改红包状态
			$prop_obj = $model->getObj('id='.$id,'prop');
			$prop_id = isset($prop_obj['prop'])?$prop_obj['prop']:'';
			if($prop_id != '')
			{
				$prop = new IModel('prop');
				$prop->setData(array('is_close'=>0));
				$prop->update('id='.$prop_id);
			}
			echo 'success';
		}		
	}		
	//删除组合产品
	public function zuhe_del(){
		$id = IFilter::act(IReq::get('id'));
		$goods_id = IFilter::act(IReq::get('goods_id'));
		
		$goodsObj = new IModel('goods');
		$goods_result = $goodsObj->getObj("id = $goods_id");
		$combination = $goods_result['combination'];
		$combination_arr  = json_decode($combination,true);
		

		
		if($id != ''){
			unset($combination_arr[$id]);
		}
		$combination_arr = array_values($combination_arr);

		$combination_json = json_encode($combination_arr);

		$goodsObj->setData(array('combination'=>$combination_json));
		$re = $goodsObj->update("id = $goods_id");
	}	
}