<?php
/**
 * @class Brand
 * @brief 品牌模块
 * @note  后台
 */
class Fbook extends IController
{
	//public $checkRight  = 'all';
    public $layout='';

	
	public function face_login(){
		/**
		$face_class = new facesdk(IWeb::$app->config['fb']['id'],IWeb::$app->config['fb']['sec']);
		$face_class->login('http://www.unitop.com.ph/fbook/callback');
		*/	
		if($_POST){
			if(ISafe::get('user_id') != null){
				exit(json_encode(array('status'=>1,'info'=>'')));  			
			}	
	   		$username  = IFilter::act(IReq::get('username','post'));
	    	$user_face_id = IFilter::act(IReq::get('userid','post'),'int');
	    	//$usertoken    = IFilter::act(IReq::get('usertoken','post'));

	    	//ICookie::set('tak',$usertoken,'7200');
    		$userObj = new IModel('user');
    		$where   = 'username = "'.$user_face_id.'" and source=3';
    		$userRow = $userObj->getObj($where);
     		$memberObj = new IModel('member');
    		//1.帐号已经存在的情况下
    		if($userRow){
    			$memberRow = $memberObj->getObj('user_id = '.$userRow['id']);
    			if($memberRow['status']!=1){
    				exit(json_encode(array('status'=>0,'info'=>
    					'Account exception please contact the administrator')));
    			}
    			CheckRights::loginAfter($userRow,$username);
    			exit(json_encode(array('status'=>1,'info'=>
    				'')));  
  						
    		}
    		//下面开始注册帐号
 			$pwd=IWeb::$app->config['api_user_pwd'];
	    		//user表
    		$userArray = array(
    			'username' => $user_face_id,
    			'password' => md5($pwd),
    			'source'    => 3,
    		);
    		$userObj->setData($userArray);
    		$user_id = $userObj->add();

    		if($user_id){
		     	//获取注册配置参数
				$siteConfig = new Config('site_config');
				$reg_option = $siteConfig->reg_option;   			
				//member表
	    		$memberArray = array(
	    			'user_id' => $user_id,
	    			'time'    => ITime::getDateTime()
	    		);

	    		$memberObj = new IModel('member');
	    		$memberObj->setData($memberArray);
	    		$memberObj->add();
	    		//用户私密数据
	    		ISafe::set('nickname',$username);
	    		ISafe::set('username',$user_face_id);
	    		ISafe::set('user_id',$user_id);
	    		ISafe::set('user_pwd',$userArray['password']);
    			exit(json_encode(array('status'=>1,'info'=>
    				''))); 	    		
    		}else{
    			exit(json_encode(array('status'=>0,'info'=>'login false,please try again or register!')));
    		}     		    	    		
		}
	}



	public function callback(){
		echo ':)欢迎回来';
		$face_class = new facesdk(IWeb::$app->config['fb']['id'],IWeb::$app->config['fb']['sec']);
		$face_class->fbback();
	}
}
