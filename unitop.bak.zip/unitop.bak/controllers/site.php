<?php
/**
 * @copyright Copyright(c) 2011 jooyea.cn
 * @file site.php
 * @brief
 * @author webning
 * @date 2011-03-22
 * @version 0.6
 * @note
 */
/**
 * @brief Site
 * @class Site
 * @note
 */
class Site extends IController
{
    public $layout='site';

    public function flushall(){
    	Commonfunc::flushall();
    }

    public function theme(){
		$query = new IQuery('goods');
		$query->where='id>0';
		$query->fields='*';
		$query->limit='10';
		$query->order='sort asc,id desc';			
		$this->result= $query->find();
		$this->redirect('theme');	   	
    }

    /**
     * 注册并绑定微信
     */
    public function bindingwechat(){
    	/**
    	$code	= IReq::get('code');
    	$wechat	= IReq::get('wechat');
    	$this->wechatid = '';
    	if($code){
    		$siteConfig = new Config('site_config');
    		$appid  = $siteConfig->wechat_AppID;
    		$secret = $siteConfig->wechat_AppSecret;
    		if ($appid && $secret){
    			$url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=$appid&secret=$secret&code=$code&grant_type=authorization_code";
    			$jsons = json_decode(file_get_contents($url),true);
    			$this->wechatid = $jsons['openid'];
    		}
    	}
    	if ($this->wechatid){
    		//保存openid为其他wechat应用使用
    		ISafe::set('wechat_openid',$this->wechatid);
    	}
    	*/
    }

    function leave_message(){
    	$this->layout='';
    	$this->redirect('leave_message'); 
    }

    function usermessage(){ 	
    	$user_id=ISafe::get('user_id');
    	if($_POST['message']&&$user_id){
    		$message=trim($_POST['message']);
	    	
			Commonfunc::inject_check($message);

			$dataDB = new IModel('leave_message');

			$data['userid']=ISafe::get('user_id');

			$data['username']=ISafe::get('username');

			//$data['client_ip']=Commonfunc::get_real_ip();

			$data['message']=addslashes($message);

			$data['create_time']=time();

			

			$dataDB->setData($data);

			$dataDB->add();
		
    	}
    }

    function is_login(){
    	$user_id=ISafe::get('user_id');
    	if($user_id){
    		echo '1';
    	}	
    }

    function order_export(){
    	$_seller_id=ISafe::get('seller_id');
    	$_admin_id=ISafe::get('admin_id');
    	
    	if(empty($_seller_id)&&empty($_admin_id)){
    		die;
    	}
    	
    	if(!$_POST){
			$goods_class = new goods_class();
			$seller_obj  =new IModel('seller');
			$this->seller=$seller_obj->query('is_del=0',array('id','true_name'),'id','asc');
 		
    	}else{
    		$where='1';
    		$status=IFilter::act(IReq::get('status'),'int');
			if($_POST['status']){
				$status=$status==6 ? 0 : $status;
				$where.=' and go.status='.$status;
			}else{
				$where .= " and go.status != 3 and go.status!=4";
			}

			if($_POST['branch']){
				$branch=IFilter::act(IReq::get('branch'),'int');
				$where.=' and go.seller_id = '.$branch;
			}

			if($_POST['type']){
				$type=IFilter::act(IReq::get('type'),'int');
				if($type==2)
				$where.=' and go.takeself > 0';
			}
			if($_POST['time']){
				$time=IFilter::act(IReq::get('time'),'int');
				$date_str=date('Y').'-'.$time.'-1';
				$date_where_start=$date_str.' 00:00:00';
				$date_where_end=date('Y-m-t',strtotime($date_str)).' 23:59:59';
				$where.=' and go.create_time between \''.$date_where_start.'\' and \''.$date_where_end.'\'';
			}
			$table='order as go';
			$goodsHandle = new IQuery($table);
			$goodsHandle->order    = "go.id desc";
			//$goodsHandle->distinct = "go.id";
			$goodsHandle->fields   = "go.*";
			//$goodsHandle->join     = $join;
			$goodsHandle->where    = $where;
			$goodsHandle->limit    = 'all';
			$orderList = $goodsHandle->find();
			if(empty($orderList)){
				exit("NO orders");
			}

				//构建 Excel table;
			$strTable ='<table width="600" border="1">';
			$strTable .= '<tr>';
			$strTable .= '<td style="text-align:center;font-size:12px;width:120px;">Order number</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="100">date</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="*">consignee</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="*">tel</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="*">Order amount</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="*">Actual payment</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="*">Payment method</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="*">Payment status</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="*">Delivery status</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="120px;">Commodity information</td>';
			$strTable .= '</tr>';

			foreach($orderList as $k=>$val){
				$strTable .= '<tr>';
				$strTable .= '<td style="text-align:center;font-size:12px;">&nbsp;'.$val['order_no'].'</td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['create_time'].' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['accept_name'].' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">&nbsp;'.$val['telphone'].'&nbsp;'.$val['mobile'].' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['payable_amount'].' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['real_amount'].' </td>';
				$pay_name=$val['pay_type']==0 ? 'Cash on Delivery' : 'Balance payment';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$pay_name.' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.Order_Class::getOrderPayStatusText($val).' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.Order_Class::getOrderDistributionStatusText($val).' </td>';

				$orderGoods = Order_class::getOrderGoods($val['id']);
				$strGoods="";
				foreach($orderGoods as $good){
					$strGoods .= "Commodity number：".$good->goodsno." Commodity name：".$good->name;
					if ($good->value!='') $strGoods .= " Specifications：".$good->value;
					$strGoods .= "<br />";
				}
				unset($orderGoods);

				$strTable .= '<td style="text-align:left;font-size:12px;">'.$strGoods.' </td>';
				$strTable .= '</tr>';
			}
			$strTable .='</table>';//exit($strTable);
			unset($goodsList);
			$reportObj = new report();
			$reportObj->setFileName('order_export_'.$time);
			$reportObj->toDownload($strTable);
			//exit();												
    	}
    	$this->layout='';
    	$this->redirect('order_export');    	

    } 

    function goods_export(){
    	$_seller_id=ISafe::get('seller_id');
    	$_admin_id=ISafe::get('admin_id');
    	
    	if(empty($_seller_id)&&empty($_admin_id)){
    		die;
    	}
    	
    	if(!$_POST){
			$goods_class = new goods_class();
			$tb_category = new IModel('category');
			$seller_obj  =new IModel('seller');
			$this->seller=$seller_obj->query('is_del=0',array('id','true_name'),'id','asc');
			$this->category = $goods_class->sortdata($tb_category->query(false,'*','name','asc'),0,'--');//sort		 		
    	}else{
    		$where='1';
    		$status=IFilter::act(IReq::get('status'),'int');
			if($_POST['status']){
				$status=$status==6 ? 0 : $status;
				$where.=' and go.is_del='.$status;
			}else{
				$where .= " and go.is_del != 1";
			}
			$branch_id=IFilter::act(IReq::get('branch'),'int');
			$brand_id=$branch_id ? $branch_id : 0;
			$where.=' and go.seller_id='.$branch_id;
			if($_POST['category']){
				$category=IFilter::act(IReq::get('category'),'int');
				$where.=' and c.category_id = '.$category;
				$join=" join category_extend as c on go.id = c.goods_id";
			}
			$table='goods as go';
			$goodsHandle = new IQuery($table);
			$goodsHandle->order    = "go.sort asc,go.id desc";
			$goodsHandle->distinct = "go.id";
			$goodsHandle->fields   = "go.id, go.name,go.barcode,go.goods_no,go.sell_price,go.store_nums,go.sale,go.is_del,go.create_time";
			$goodsHandle->join     = $join;
			$goodsHandle->where    = $where;
			$goodsHandle->limit    = 'all';
			$goodsList = $goodsHandle->find();
			if(empty($goodsList)){
				exit("NO goods");
			}

			//构建 Excel table;
			$strTable ='<table width="500" border="1">';
			$strTable .= '<tr>';


			$strTable .= '<td style="text-align:center;font-size:12px;" width="*">Commodity name</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="60">barcode</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="60">goods_no</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="160">classification</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="60">price</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="60">stock</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="60">sales volume</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="60">Release time</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="60">state</td>';
			$strTable .= '<td style="text-align:center;font-size:12px;" width="60">Subordinate merchant</td>';
			$strTable .= $new_fields ? '<td style="text-align:center;font-size:12px;" width="160">category</td>' : '';
			$strTable .= '</tr>';

			foreach($goodsList as $k=>$val){
				$strTable .= '<tr>';
				$strTable .= '<td style="text-align:center;font-size:12px;">&nbsp;'.$val['name'].'</td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['barcode'].' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['goods_no'].' </td>';

				$strTable .= '<td style="text-align:left;font-size:12px;">'.goods_class::getGoodsCategory($val['id']).' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['sell_price'].' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['store_nums'].' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['sale'].' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['create_time'].' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.goods_class::statusText($val['is_del']).' </td>';
				$strTable .= '<td style="text-align:left;font-size:12px;">'.$val['true_name'].'&nbsp;</td>';
			    $strTable .= $new_fields ? '<td style="text-align:left;font-size:12px;">'.$val['cate'].'&nbsp;</td>': '';			
				$strTable .= '</tr>';
			}
			$strTable .='</table>';//echo $strTable;exit;
			unset($goodsList);
			$reportObj = new report();
			$reportObj->setFileName('goods_export');
			$reportObj->toDownload($strTable);
			//exit();												
    	}
    	$this->layout='';
    	$this->redirect('goods_export');    	

    }
    
	function init()
	{
		$this->bindingwechat();
		CheckRights::checkUserRights();
		if($_GET['area_id']){
			$a_id=IFilter::act(IReq::get('area_id'),'int');
		}
		$icookie=ICookie::get("area_id");
    	$this->area_id = $a_id ? $a_id : $icookie;//echo $icookie.'mm';exit;	
    	/**
		if($_GET['area_id']){
			$areaid     = IFilter::act(IReq::get('area_id'),'int');
			ICookie::set("area_id",$areaid,60*60*24*30);	
		}
		$this->area_id = ICookie::get("area_id");	
		*/
	}
	function category_list(){
		$cateDB    = new IModel('category');
		$cate_first  = $cateDB->query("parent_id=0 and visibility=1",'*','sort','asc');
		$result_data=array();
		foreach ($cate_first as $key => $value) {
			$parent_id=$value['id'];
			$cate_second  = $cateDB->query("parent_id=".$parent_id." and visibility=1",'*','sort','asc');
			if(!empty($cate_second)){

				foreach ($cate_second as $k => $v) {
					$three_arr=array();
					$three_parent_id=$v['id'];
					$three_arr= $cateDB->query("parent_id=".$three_parent_id." and visibility=1",'*','sort','asc');
					if(empty($three_arr)){
						$cate_first[$key]['second_no'][]=$v;//放为空的二级
					}else{
						$v['children']=$three_arr;
						$cate_first[$key]['second_yes'][]=$v;					
					}
				}			
			}
   		}
   		
	
	}
	function index()
	{
		$siteConfigObj = new Config("site_config");
		$site_config   = $siteConfigObj->getInfo();
		$index_slide = isset($site_config['index_slide'])? unserialize($site_config['index_slide']) :array();
		$this->index_slide = $index_slide;
		 //获取用户选择的地区
		if($_GET['area_id']){
			$areaid     = IFilter::act(IReq::get('area_id'),'int');
			ICookie::set("area_id",$areaid,60*60*24*30);

		}
		//print_r($_COOKIE);
		//echo ICookie::get("area_id").'===<br>';
		$icookie=ICookie::get("area_id");
		if(empty($icookie)){
			ICookie::set("area_id",659019,60*60*24*30);
		}
		$area_id=ICookie::get("area_id") ? ICookie::get("area_id") : 659019;
		$getsellerObj = new IModel('seller');
		$sellerArr = Commonfunc::seller_list($area_id);				
		if(is_array($sellerArr) && !empty($sellerArr)){
			$this->seller_id = $sellerArr['id'];
		}

		$this->recommend_data=Commonfunc::commend_goods_by_sellerid($this->seller_id);
		
		
		$this->redirect('index',false);
	}

	//[首页]商品搜索
	function search_list()
	{
		$this->word = IFilter::act(IReq::get('word'),'text');
		$cat_id     = IFilter::act(IReq::get('cat'),'int');

		if(preg_match("|^[\w\x7f\s*-\xff*]+$|",$this->word))
		{
			//搜索关键字
			$tb_sear     = new IModel('search');
			$search_info = $tb_sear->getObj('keyword = "'.$this->word.'"','id');

			//如果是第一页，相应关键词的被搜索数量才加1
			if($search_info && intval(IReq::get('page')) < 2 )
			{
				//禁止刷新+1
				$allow_sep = "30";
				$flag = false;
				$time = ICookie::get('step');
				if(isset($time))
				{
					if (time() - $time > $allow_sep)
					{
						ICookie::set('step',time());
						$flag = true;
					}
				}
				else
				{
					ICookie::set('step',time());
					$flag = true;
				}
				if($flag)
				{
					$tb_sear->setData(array('num'=>'num + 1'));
					$tb_sear->update('id='.$search_info['id'],'num');
				}
			}
			elseif( !$search_info )
			{
				//如果数据库中没有这个词的信息，则新添
				$tb_sear->setData(array('keyword'=>$this->word,'num'=>1));
				$tb_sear->add();
			}
		}
		else
		{
			IError::show(403,'Please enter the correct query keywords');
		}
		
		
		$this->filter_result();
		$this->cat_id = $cat_id;
		
		//新增浏览记录推荐开始
		$getsellerObj2 = new IModel('seller');
		$sellerArr = $getsellerObj2->getObj("province = $this->area_id");
		$this->seller_id = $sellerArr['id'] != '' ? $sellerArr['id'] : '';		
		$vt = ICookie::get($visits);
		if(isset($vt)){
			$goods_ids=$vt;
		}else{
			$goods_ids=array();
		}
		$goods_ids[]=$goods_id;
		if(isset($goods_id) && $goods_id != null) ICookie::set($visits,$goods_ids,'7200');
		
		//去除重复 
		$goods_ids=array_unique($goods_ids);		
		//去除数组中的null
		foreach( $goods_ids as $k=>$v){  
		    if( !$v ){
		    	unset( $goods_ids[$k] );
		    }else{
		    	$tb_goods3 = new IModel('goods');
		    	$goods_arr3 = $tb_goods3->getObj("id = $v");
		    	if($goods_arr3['seller_id'] != $this->seller_id){
		    		unset( $goods_ids[$k] );
		    	}
		    }
		          
		}  		
		shuffle($goods_ids);
		$gk=1;
		foreach ($goods_ids as $value){
			if($gk<=5){
				$gv .= ','.$value;
				$gk++;
			}
		}
		$gv = substr($gv, 1);

		$tb_goods2 = new IModel('goods');
		if($gv != ''){
			$goods_arr = $tb_goods2->query("id in ($gv)");
		}
		$this->goods_arr=$goods_arr;
		//新增浏览记录推荐结束

		//获取用户所在的省份
		if($this->user['user_id'] && $this->user['user_id'] != ''){
			$user_id = $this->user['user_id'];
			$memberObj       = new IModel('member');
	    	$where           = 'user_id = '.$user_id;
	    	$this->memberRow = $memberObj->getObj($where);
		}

    	
		$this->redirect('search_list');
	}

	//[site,ucenter头部分]自动完成
	function autoComplete()
	{
		$word = IFilter::act(IReq::get('word'));
		$isError = true;
		$data    = array();

		if($word != '' && $word != '%' && $word != '_')
		{
			$wordObj  = new IModel('keyword');
			$wordList = $wordObj->query('word like "'.$word.'%" and word != "'.$word.'"','word, goods_nums','','',10);

			if(!empty($wordList))
			{
				$isError = false;
				$data = $wordList;
			}
		}

		//json数据
		$result = array(
			'isError' => $isError,
			'data'    => $data,
		);

		echo JSON::encode($result);
	}

	//[首页]邮箱订阅
	function email_registry()
	{
		$email  = IReq::get('email');
		$result = array('isError' => true);

		if(!IValidate::email($email))
		{
			$result['message'] = 'Please fill in the correct email address';
		}
		else
		{
			$emailRegObj = new IModel('email_registry');
			$emailRow    = $emailRegObj->getObj('email = "'.$email.'"');

			if(!empty($emailRow))
			{
				$result['message'] = 'This email has already been subscribed to.';
			}
			else
			{
				$dataArray = array(
					'email' => $email,
				);
				$emailRegObj->setData($dataArray);
				$status = $emailRegObj->add();
				if($status == true)
				{
					$result = array(
						'isError' => false,
						'message' => 'Subscription success',
					);
				}
				else
				{
					$result['message'] = 'Subscription failed';
				}
			}
		}
		echo JSON::encode($result);
	}

	//筛选返回值
	public function filter_result(){
		//手机端调用指定布局
		if (IClient::getDevice() == 'mobile'){
			//$this->layout = 'site_mini';
		}
		$this->order = IFilter::act(IReq::get('order'),'string');//筛选
		if (strpos($this->order, '_') !== false){
			$this->order_by = 'asc';
		}else{
			$this->order_by = 'desc';
		}
	}
	
	//[列表页]商品
	function pro_list()
	{
		$this->catId = IFilter::act(IReq::get('cat'),'int');//分类id

		if($this->catId == 0)
		{
			IError::show(403,'Lack of classification ID');
		}
		//查找分类信息
		$catObj       = new IModel('category');
		$this->catRow = $catObj->getObj('id = '.$this->catId);

		if($this->catRow == null)
		{
			IError::show(403,'This category does not exist');
		}
			
		$this->filter_result();
		//获取子分类
		$this->childId = goods_class::catChild($this->catId);
		
		
		//新增浏览记录推荐开始
		$getsellerObj2 = new IModel('seller');
		$sellerArr = $getsellerObj2->getObj("province = $this->area_id");
		$this->seller_id = $sellerArr['id'] != '' ? $sellerArr['id'] : '';
		$vt = ICookie::get($visits);
		if(isset($vt)){
			$goods_ids=$vt;
		}else{
			$goods_ids=array();
		}
		$goods_ids[]=$goods_id;
		if(isset($goods_id) && $goods_id != null) ICookie::set($visits,$goods_ids,'7200');
		
		//去除重复 
		$goods_ids=array_unique($goods_ids);		
		//去除数组中的null
		foreach( $goods_ids as $k=>$v){  
		    if( !$v ){
		    	unset( $goods_ids[$k] );
		    }else{
		    	$tb_goods3 = new IModel('goods');
		    	$goods_arr3 = $tb_goods3->getObj("id = $v");
		    	if($goods_arr3['seller_id'] != $this->seller_id){
		    		unset( $goods_ids[$k] );
		    	}
		    }
		          
		}  		
		shuffle($goods_ids);
		$gk=1;
		foreach ($goods_ids as $value){
			if($gk<=5){
				$gv .= ','.$value;
				$gk++;
			}
		}
		$gv = substr($gv, 1);

		$tb_goods2 = new IModel('goods');
		if($gv != ''){
			$goods_arr = $tb_goods2->query("id in ($gv)");
		}
		$this->goods_arr=$goods_arr;
		//新增浏览记录推荐结束

		//获取用户所在的省份
		if($this->user['user_id'] && $this->user['user_id'] != ''){
			$user_id = $this->user['user_id'];
			$memberObj       = new IModel('member');
	    	$where           = 'user_id = '.$user_id;
	    	$this->memberRow = $memberObj->getObj($where);
		}
		$this->sellerArr=$sellerArr;
    			
		$this->redirect('pro_list');
	}
	//最新商品列表
	function pro_new_list(){
		$tb_sear     = new IModel('search');
		$search_info = $tb_sear->getObj('','id');
		$this->redirect('pro_new_list');
	}
	//热门精品推荐列表
	function pro_best_list(){
		$this->word = '3';
		$this->redirect('pro_best_list');
	}
	//热门热门分类列表
	function pro_hot_list(){
		$tb_sear     = new IModel('search');
		$search_info = $tb_sear->getObj('','id');
		$this->redirect('pro_hot_list');
	}
	//咨询
	function consult()
	{
		$this->goods_id = IFilter::act(IReq::get('id'),'int');
		$this->callback = IReq::get('callback');

		if($this->goods_id == 0)
		{
			IError::show(403,'Lack of commodity ID parameters');
		}

		$goodsObj   = new IModel('goods');
		$goodsRow   = $goodsObj->getObj('id = '.$this->goods_id);

		if(!$goodsRow)
		{
			IError::show(403,'Commodity data does not exist');
		}

		//获取次商品的评论数和平均分(保留小数点后一位)
		$goodsRow['apoint']   = $goodsRow['comments'] ? round($goodsRow['grade']/$goodsRow['comments'],1) : 0;
		$goodsRow['comments'] = $goodsRow['comments'];

		$this->goodsRow = $goodsRow;
		$this->redirect('consult');
	}

	//咨询动作
	function consult_act()
	{
		$goods_id   = IFilter::act(IReq::get('goods_id','post'),'int');
		$captcha    = IFilter::act(IReq::get('captcha','post'));
		$question   = IFilter::act(IReq::get('question','post'));
		$callback   = IReq::get('callback');
		$message    = '';

    	if($captcha != ISafe::get('captcha'))
    	{
    		$message = 'Verification code input is not correct';
    	}
    	else if(!trim($question))
    	{
    		$message = 'Advisory content can not be empty';
    	}
    	else if($goods_id == 0)
    	{
    		$message = 'Commodity ID cannot be empty';
    	}
    	else
    	{
    		$goodsObj = new IModel('goods');
    		$goodsRow = $goodsObj->getObj('id = '.$goods_id);
    		if(!$goodsRow)
    		{
    			$message = 'This commodity does not exist';
    		}
    	}

		//有错误情况
    	if($message)
    	{
    		$this->callback = $callback;
    		$this->goods_id = $goods_id;
    		$dataArray = array(
    			'question' => $question,
    		);
    		$this->consultRow = $dataArray;

			//渲染goods数据
			$goodsObj   = new IModel('goods');
			$goodsRow   = $goodsObj->getObj('id = '.$this->goods_id);

			//获取次商品的评论数和平均分(保留小数点后一位)
			$goodsRow['apoint']   = $goodsRow['comments'] ? round($goodsRow['grade']/$goodsRow['comments'],1) : 0;
			$goodsRow['comments'] = $goodsRow['comments'];
			$this->goodsRow = $goodsRow;

    		$this->redirect('consult',false);
    		Util::showMessage($message);
    	}
    	else
    	{
			$dataArray = array(
				'question' => $question,
				'goods_id' => $goods_id,
				'user_id'  => isset($this->user['user_id']) ? $this->user['user_id'] : 0,
				'time'     => ITime::getDateTime(),
			);

			$referObj = new IModel('refer');
			$referObj->setData($dataArray);
			$referObj->add();

			$this->redirect('success?callback=/site/products/id/'.$goods_id);
    	}
	}

	//公告详情页面
	function notice_detail()
	{
		$this->notice_id = IFilter::act(IReq::get('id'),'int');
		if($this->notice_id == '')
		{
			IError::show(403,'Missing announcement ID parameter');
		}
		else
		{
			$noObj           = new IModel('announcement');
			$this->noticeRow = $noObj->getObj('id = '.$this->notice_id);
			if(empty($this->noticeRow))
			{
				IError::show(403,'Bulletin information does not exist');
			}
			
			//上一篇
			$this->previous_page = $noObj->getObj("`id` < $this->notice_id order by id desc");
			//下一篇
			$this->next_page = $noObj->getObj("`id` > $this->notice_id");
						
			$this->redirect('notice_detail');
		}
	}

	//咨询详情页面
	function article_detail()
	{
		$this->article_id = IFilter::act(IReq::get('id'),'int');
		if($this->article_id == '')
		{
			IError::show(403,'Lack of consulting ID parameters');
		}
		else
		{
			$articleObj       = new IModel('article');
			$this->articleRow = $articleObj->getObj('id = '.$this->article_id);
			$category_id = $this->articleRow['category_id'];
			$this->category_id = $category_id;
			
			
			if(empty($this->articleRow))
			{
				IError::show(403,'Information article does not exist');
				exit;
			}
			
			//上一篇
			$this->previous_page = $articleObj->getObj("`category_id` = $category_id and `id` < $this->article_id and `visibility` = 1 order by id desc");
			//下一篇
			$this->next_page = $articleObj->getObj("`category_id` = $category_id and `id` > $this->article_id and `visibility` = 1");
			

			//关联商品
			$relationObj = new IQuery('relation as r');
			$relationObj->join   = ' left join goods as go on r.goods_id = go.id ';
			$relationObj->where  = ' r.article_id = '.$this->article_id.' and go.id is not null ';

			$this->relationList  = $relationObj->find();
			$this->redirect('article_detail');
		}
	}
	function goods_show(){
		$goods_id = IFilter::act(IReq::get('id'),'int');

		if(!$goods_id)
		{
			IError::show(403,"The parameter passed is incorrect.");
			exit;
		}

		//使用商品id获得商品信息
		$tb_goods = new IModel('goods');
		$goods_info = $tb_goods->getObj('id='.$goods_id." AND is_del!=1");
		if(!$goods_info)
		{
			IError::show(403,"This product does not exist");
			exit;
		}
		
		
		$this->goods_info = $goods_info;
		
		//品牌名称
		if($goods_info['brand_id'])
		{
			$tb_brand = new IModel('brand');
			$brand_info = $tb_brand->getObj('id='.$goods_info['brand_id']);
			if($brand_info)
			{
				$goods_info['brand'] = $brand_info['name'];
			}
		}

		//获取商品分类
		$categoryObj = new IModel('category_extend as ca,category as c');
		$categoryRow = $categoryObj->getObj('ca.goods_id = '.$goods_id.' and ca.category_id = c.id','c.id,c.name');
		$goods_info['category'] = $categoryRow ? $categoryRow['id'] : 0;

		//商品图片
		$tb_goods_photo = new IQuery('goods_photo_relation as g');
		$tb_goods_photo->fields = 'p.id AS photo_id,p.img ';
		$tb_goods_photo->join = 'left join goods_photo as p on p.id=g.photo_id ';
		$tb_goods_photo->where =' g.goods_id='.$goods_id;
		$goods_info['photo'] = $tb_goods_photo->find();
		foreach($goods_info['photo'] as $key => $val)
		{
			//对默认第一张图片位置进行前置
			if($val['img'] == $goods_info['img'])
			{
				$temp = $goods_info['photo'][0];
				$goods_info['photo'][0] = $val;
				$goods_info['photo'][$key] = $temp;
			}
		}

		//商品是否参加促销活动(团购，抢购)
		$goods_info['promo']     = IReq::get('promo')     ? IReq::get('promo') : '';
		$goods_info['active_id'] = IReq::get('active_id') ? IFilter::act(IReq::get('active_id'),'int') : '';
		if($goods_info['promo'])
		{
			switch($goods_info['promo'])
			{
				//团购
				case 'groupon':
				{
					$goods_info['regiment'] = Api::run("getRegimentRowById",array("#id#",$goods_info['active_id']));
				}
				break;

				//抢购
				case 'time':
				{
					$goods_info['promotion'] = Api::run("getPromotionRowById",array("#id#",$goods_info['active_id']));
				}
				break;

				default:
				{
					IError::show(403,"Activity does not exist or has expired");
					exit;
				}
			}
		}

		//获得扩展属性
		$tb_attribute_goods = new IQuery('goods_attribute as g');
		$tb_attribute_goods->join  = 'left join attribute as a on a.id=g.attribute_id ';
		$tb_attribute_goods->fields=' a.name,g.attribute_value ';
		$tb_attribute_goods->where = "goods_id='".$goods_id."' and attribute_id!=''";
		$tb_attribute_goods->order = "g.id asc";
		$goods_info['attribute'] = $tb_attribute_goods->find();

		//[数据挖掘]最终购买此商品的用户ID列表
		$tb_good = new IQuery('order_goods as og');
		$tb_good->join   = 'left join order as o on og.order_id=o.id ';
		$tb_good->fields = 'DISTINCT o.user_id';
		$tb_good->where  = 'og.goods_id = '.$goods_id;
		$tb_good->limit  = 5;
		$bugGoodInfo = $tb_good->find();
		if($bugGoodInfo)
		{
			$shop_goods_array = array();
			foreach($bugGoodInfo as $key => $val)
			{
				$shop_goods_array[] = $val['user_id'];
			}
			$goods_info['buyer_id'] = join(',',$shop_goods_array);
		}

		//购买记录
		$tb_shop = new IQuery('order_goods as og');
		$tb_shop->join = 'left join order as o on o.id=og.order_id';
		$tb_shop->fields = 'count(*) as totalNum';
		$tb_shop->where = 'og.goods_id='.$goods_id.' and o.status = 5';
		$shop_info = $tb_shop->find();
		$goods_info['buy_num'] = 0;
		if($shop_info)
		{
			$goods_info['buy_num'] = $shop_info[0]['totalNum'];
		}

		//购买前咨询
		$tb_refer    = new IModel('refer');
		$refeer_info = $tb_refer->getObj('goods_id='.$goods_id,'count(*) as totalNum');
		$goods_info['refer'] = 0;
		if($refeer_info)
		{
			$goods_info['refer'] = $refeer_info['totalNum'];
		}

		//网友讨论
		$tb_discussion = new IModel('discussion');
		$discussion_info = $tb_discussion->getObj('goods_id='.$goods_id,'count(*) as totalNum');
		$goods_info['discussion'] = 0;
		if($discussion_info)
		{
			$goods_info['discussion'] = $discussion_info['totalNum'];
		}

		//获得商品的价格区间
		$tb_product = new IModel('products');
		$product_info = $tb_product->getObj('goods_id='.$goods_id,'max(sell_price) as maxSellPrice ,min(sell_price) as minSellPrice,max(market_price) as maxMarketPrice,min(market_price) as minMarketPrice');
		$goods_info['maxSellPrice']   = '';
		$goods_info['minSellPrice']   = '';
		$goods_info['minMarketPrice'] = '';
		$goods_info['maxMarketPrice'] = '';
		if($product_info)
		{
			$goods_info['maxSellPrice']   = $product_info['maxSellPrice'];
			$goods_info['minSellPrice']   = $product_info['minSellPrice'];
			$goods_info['minMarketPrice'] = $product_info['minMarketPrice'];
			$goods_info['maxMarketPrice'] = $product_info['maxMarketPrice'];
		}

		//获得会员价
		$countsumInstance = new countsum();
		$goods_info['group_price'] = $countsumInstance->getGroupPrice($goods_id,'goods');

		//获取商家信息
		if($goods_info['seller_id'])
		{
			$sellerDB = new IModel('seller');
			$goods_info['seller'] = $sellerDB->getObj('id = '.$goods_info['seller_id']);
		}


		
		//获取组合产品
				
		$combinationJson = $goods_info['combination'];
		$combination = json_decode($combinationJson,true);
		
		$this->combination = $combination;

		foreach ($goods_info as $key => $value) {
			if(!in_array($key,array('img','ad_img','photo'))&&!is_array($value))
			$goods_info[$key]=stripcslashes($value);
		}		
		$this->setRenderData($goods_info);
		
		//获取用户所在的省份
		if($this->user['user_id'] && $this->user['user_id'] != ''){
			$user_id = $this->user['user_id'];
			$memberObj       = new IModel('member');
	    	$where           = 'user_id = '.$user_id;
	    	$this->memberRow = $memberObj->getObj($where);
		}
    			
		$this->redirect('goods_show',false);		
	}

	function products()
	{
		$goods_id = IFilter::act(IReq::get('id'),'int');

		if(!$goods_id)
		{
			IError::show(403,"The parameter passed is incorrect.");
			exit;
		}

		//使用商品id获得商品信息
		$tb_goods = new IModel('goods');
		$goods_info = $tb_goods->getObj('id='.$goods_id." AND is_del=0");
		if(!$goods_info)
		{
			IError::show(403,"This product does not exist");
			exit;
		}
		
		
		$this->goods_info = $goods_info;
		
		//品牌名称
		if($goods_info['brand_id'])
		{
			$tb_brand = new IModel('brand');
			$brand_info = $tb_brand->getObj('id='.$goods_info['brand_id']);
			if($brand_info)
			{
				$goods_info['brand'] = $brand_info['name'];
			}
		}

		//获取商品分类
		$categoryObj = new IModel('category_extend as ca,category as c');
		$categoryRow = $categoryObj->getObj('ca.goods_id = '.$goods_id.' and ca.category_id = c.id','c.id,c.name');
		$goods_info['category'] = $categoryRow ? $categoryRow['id'] : 0;

		//商品图片
		$tb_goods_photo = new IQuery('goods_photo_relation as g');
		$tb_goods_photo->fields = 'p.id AS photo_id,p.img ';
		$tb_goods_photo->join = 'left join goods_photo as p on p.id=g.photo_id ';
		$tb_goods_photo->where =' g.goods_id='.$goods_id;
		$goods_info['photo'] = $tb_goods_photo->find();
		foreach($goods_info['photo'] as $key => $val)
		{
			//对默认第一张图片位置进行前置
			if($val['img'] == $goods_info['img'])
			{
				$temp = $goods_info['photo'][0];
				$goods_info['photo'][0] = $val;
				$goods_info['photo'][$key] = $temp;
			}
		}

		//商品是否参加促销活动(团购，抢购)
		$goods_info['promo']     = IReq::get('promo')     ? IReq::get('promo') : '';
		$goods_info['active_id'] = IReq::get('active_id') ? IFilter::act(IReq::get('active_id'),'int') : '';
		if($goods_info['promo'])
		{
			switch($goods_info['promo'])
			{
				//团购
				case 'groupon':
				{
					$goods_info['regiment'] = Api::run("getRegimentRowById",array("#id#",$goods_info['active_id']));
				}
				break;

				//抢购
				case 'time':
				{
					$goods_info['promotion'] = Api::run("getPromotionRowById",array("#id#",$goods_info['active_id']));
				}
				break;

				default:
				{
					IError::show(403,"Activity does not exist or has expired");
					exit;
				}
			}
		}

		$discount_arr=Commonfunc::goods_real_price($goods_id);
		$goods_info['goods_real_price']=$discount_arr[0]['count_price'];

		//获得扩展属性
		$tb_attribute_goods = new IQuery('goods_attribute as g');
		$tb_attribute_goods->join  = 'left join attribute as a on a.id=g.attribute_id ';
		$tb_attribute_goods->fields=' a.name,g.attribute_value ';
		$tb_attribute_goods->where = "goods_id='".$goods_id."' and attribute_id!=''";
		$tb_attribute_goods->order = "g.id asc";
		$goods_info['attribute'] = $tb_attribute_goods->find();

		//[数据挖掘]最终购买此商品的用户ID列表
		$tb_good = new IQuery('order_goods as og');
		$tb_good->join   = 'left join order as o on og.order_id=o.id ';
		$tb_good->fields = 'DISTINCT o.user_id';
		$tb_good->where  = 'og.goods_id = '.$goods_id;
		$tb_good->limit  = 5;
		$bugGoodInfo = $tb_good->find();
		if($bugGoodInfo)
		{
			$shop_goods_array = array();
			foreach($bugGoodInfo as $key => $val)
			{
				$shop_goods_array[] = $val['user_id'];
			}
			$goods_info['buyer_id'] = join(',',$shop_goods_array);
		}

		//购买记录
		$tb_shop = new IQuery('order_goods as og');
		$tb_shop->join = 'left join order as o on o.id=og.order_id';
		$tb_shop->fields = 'count(*) as totalNum';
		$tb_shop->where = 'og.goods_id='.$goods_id.' and o.status = 5';
		$shop_info = $tb_shop->find();
		$goods_info['buy_num'] = 0;
		if($shop_info)
		{
			$goods_info['buy_num'] = $shop_info[0]['totalNum'];
		}

		//购买前咨询
		$tb_refer    = new IModel('refer');
		$refeer_info = $tb_refer->getObj('goods_id='.$goods_id,'count(*) as totalNum');
		$goods_info['refer'] = 0;
		if($refeer_info)
		{
			$goods_info['refer'] = $refeer_info['totalNum'];
		}

		//网友讨论
		$tb_discussion = new IModel('discussion');
		$discussion_info = $tb_discussion->getObj('goods_id='.$goods_id,'count(*) as totalNum');
		$goods_info['discussion'] = 0;
		if($discussion_info)
		{
			$goods_info['discussion'] = $discussion_info['totalNum'];
		}

		//获得商品的价格区间
		$tb_product = new IModel('products');
		$product_info = $tb_product->getObj('goods_id='.$goods_id,'max(sell_price) as maxSellPrice ,min(sell_price) as minSellPrice,max(market_price) as maxMarketPrice,min(market_price) as minMarketPrice');
		$goods_info['maxSellPrice']   = '';
		$goods_info['minSellPrice']   = '';
		$goods_info['minMarketPrice'] = '';
		$goods_info['maxMarketPrice'] = '';
		if($product_info)
		{
			$goods_info['maxSellPrice']   = $product_info['maxSellPrice'];
			$goods_info['minSellPrice']   = $product_info['minSellPrice'];
			$goods_info['minMarketPrice'] = $product_info['minMarketPrice'];
			$goods_info['maxMarketPrice'] = $product_info['maxMarketPrice'];
		}

		//获得会员价
		$countsumInstance = new countsum();
		$goods_info['group_price'] = $countsumInstance->getGroupPrice($goods_id,'goods');

		//获取商家信息
		if($goods_info['seller_id'])
		{
			$sellerDB = new IModel('seller');
			$goods_info['seller'] = $sellerDB->getObj('id = '.$goods_info['seller_id']);
		}

		//增加浏览次数
		$visit    = ISafe::get('visit');
		$checkStr = "#".$goods_id."#";
		if($visit && strpos($visit,$checkStr) !== false)
		{
		}
		else
		{
			$tb_goods->setData(array('visit' => 'visit + 1'));
			$tb_goods->update('id = '.$goods_id,'visit');
			$visit = $visit === null ? $checkStr : $visit.$checkStr;
			ISafe::set('visit',$visit);
		}
/*
		//新增浏览记录推荐开始
		$getsellerObj2 = new IModel('seller');
		$sellerArr = $getsellerObj2->getObj("province = $this->area_id");
		$this->seller_id = $sellerArr['id'] != '' ? $sellerArr['id'] : '';		
		$vt = ICookie::get("visits");
		if(isset($vt)){
			$goods_ids=$vt;
		}else{
			$goods_ids=array();
		}
		$goods_ids[]=$goods_id;
		if(isset($goods_id) && $goods_id != null) ICookie::set("visits",$goods_ids,'7200');
		
		//去除重复 
		$goods_ids=array_unique($goods_ids);		
		//去除数组中的null
		foreach( $goods_ids as $k=>$v){  
		    if( !$v ){
		    	unset( $goods_ids[$k] );
		    }else{
		    	$tb_goods3 = new IModel('goods');
		    	$goods_arr3 = $tb_goods3->getObj("id = $v");
		    	if($goods_arr3['seller_id'] != $this->seller_id){
		    		unset( $goods_ids[$k] );
		    	}
		    }
		          
		}  		
		shuffle($goods_ids);
		$gk=1;
		$gv='';
		foreach ($goods_ids as $value){
			if($gk<=5){
				$gv .= ','.$value;
				$gk++;
			}
		}
		$gv = substr($gv, 1);

		$tb_goods2 = new IModel('goods');
		if($gv != ''){
			$goods_arr = $tb_goods2->query("id in ($gv)");
		}
		$this->goods_arr=$goods_arr;
		//新增浏览记录推荐结束
*/
		
		//获取组合产品
				
		$combinationJson = $goods_info['combination'];
		$combination = json_decode($combinationJson,true);
		
		$this->combination = $combination;
		//print_r($goods_info);exit;
		foreach ($goods_info as $key => $value) {
			if(!in_array($key,array('img','ad_img','photo'))&&!is_array($value))
			$goods_info[$key]=stripcslashes($value);
		}

		//fill+
		$commendObj = new IModel('commend_goods');
		$commendRow = $commendObj->getObj('goods_id = '.$goods_id.' and commend_id= 3','id');

		$goods_info['commend']=$commendRow['id'];

		$this->setRenderData($goods_info);
		
		//获取用户所在的省份
		if($this->user['user_id'] && $this->user['user_id'] != ''){
			$user_id = $this->user['user_id'];
			$memberObj       = new IModel('member');
	    	$where           = 'user_id = '.$user_id;
	    	$this->memberRow = $memberObj->getObj($where);
		}
    			
		$this->redirect('products');
	}
	//商品讨论更新
	function discussUpdate()
	{
		$goods_id = IFilter::act(IReq::get('id'),'int');
		$content  = IFilter::act(IReq::get('content'),'text');
		$captcha  = IReq::get('captcha');
		$return   = array('isError' => true , 'message' => '');

		if(!$this->user['user_id'])
		{
			$return['message'] = 'Please login to the system first';
		}
    	else if($captcha != ISafe::get('captcha'))
    	{
    		$return['message'] = 'Verification code input is not correct';
    	}
    	else if(trim($content) == '')
    	{
    		$return['message'] = 'Content can not be empty';
    	}
    	else
    	{
    		$return['isError'] = false;

			//插入讨论表
			$tb_discussion = new IModel('discussion');
			$dataArray     = array(
				'goods_id' => $goods_id,
				'user_id'  => $this->user['user_id'],
				'time'     => date('Y-m-d H:i:s'),
				'contents' => $content,
			);
			$tb_discussion->setData($dataArray);
			$tb_discussion->add();

			$return['time']     = $dataArray['time'];
			$return['contents'] = $content;
			$return['username'] = $this->user['username'];
    	}
    	echo JSON::encode($return);
	}

	//获取货品数据
	function getProduct()
	{
		$jsonData = JSON::decode(IReq::get('specJSON'));
		if(!$jsonData)
		{
			echo JSON::encode(array('flag' => 'fail','message' => 'The specification value does not conform to the standard'));
			exit;
		}

		$goods_id = IFilter::act(IReq::get('goods_id'),'int');
		$specJSON = IFilter::act(IReq::get('specJSON'));

		//获取货品数据
		$tb_products = new IModel('products');
		$procducts_info = $tb_products->getObj("goods_id = ".$goods_id." and spec_array = '".$specJSON."'");

		//匹配到货品数据
		if(!$procducts_info)
		{
			echo JSON::encode(array('flag' => 'fail','message' => 'Did not find the relevant goods'));
			exit;
		}

		//获得会员价
		$countsumInstance = new countsum();
		$group_price = $countsumInstance->getGroupPrice($procducts_info['id'],'product');

		//会员价格
		if($group_price !== null)
		{
			$procducts_info['group_price'] = $group_price;
		}

		echo JSON::encode(array('flag' => 'success','data' => $procducts_info));
	}

	//顾客评论ajax获取
	function comment_ajax()
	{
		$goods_id = IFilter::act(IReq::get('goods_id'),'int');
		$page     = IFilter::act(IReq::get('page'),'int') ? IReq::get('page') : 1;

		$commentDB = new IQuery('comment as c');
		$commentDB->join   = 'left join goods as go on c.goods_id = go.id AND go.is_del = 0 left join user as u on u.id = c.user_id';
		$commentDB->fields = 'u.head_ico,u.username,c.time,c.comment_time,c.contents,c.point,c.recontents';
		$commentDB->where  = 'c.goods_id = '.$goods_id.' and c.status = 1';
		$commentDB->order  = 'c.id desc';
		$commentDB->page   = $page;
		$data     = $commentDB->find();
		$pageHtml = $commentDB->getPageBar("javascript:void(0);",'onclick="comment_ajax([page])"');

		echo JSON::encode(array('data' => $data,'pageHtml' => $pageHtml));
	}

	//购买记录ajax获取
	function history_ajax()
	{
		$goods_id = IFilter::act(IReq::get('goods_id'),'int');
		$page     = IFilter::act(IReq::get('page'),'int') ? IReq::get('page') : 1;

		$orderGoodsDB = new IQuery('order_goods as og');
		$orderGoodsDB->join   = 'left join order as o on og.order_id = o.id left join user as u on o.user_id = u.id';
		$orderGoodsDB->fields = 'o.user_id,og.goods_price,og.goods_nums,o.create_time as completion_time,u.username';
		$orderGoodsDB->where  = 'og.goods_id = '.$goods_id.' and o.status = 5';
		$orderGoodsDB->order  = 'o.create_time desc';
		$orderGoodsDB->page   = $page;

		$data = $orderGoodsDB->find();
		$pageHtml = $orderGoodsDB->getPageBar("javascript:void(0);",'onclick="history_ajax([page])"');

		echo JSON::encode(array('data' => $data,'pageHtml' => $pageHtml));
	}

	//讨论数据ajax获取
	function discuss_ajax()
	{
		$goods_id = IFilter::act(IReq::get('goods_id'),'int');
		$page     = IFilter::act(IReq::get('page'),'int') ? IReq::get('page') : 1;

		$discussDB = new IQuery('discussion as d');
		$discussDB->join = 'left join user as u on d.user_id = u.id';
		$discussDB->where = 'd.goods_id = '.$goods_id;
		$discussDB->order = 'd.id desc';
		$discussDB->fields = 'u.username,d.time,d.contents';
		$discussDB->page = $page;

		$data = $discussDB->find();
		$pageHtml = $discussDB->getPageBar("javascript:void(0);",'onclick="discuss_ajax([page])"');

		echo JSON::encode(array('data' => $data,'pageHtml' => $pageHtml));
	}

	//买前咨询数据ajax获取
	function refer_ajax()
	{
		$goods_id = IFilter::act(IReq::get('goods_id'),'int');
		$page     = IFilter::act(IReq::get('page'),'int') ? IReq::get('page') : 1;

		$referDB = new IQuery('refer as r');
		$referDB->join = 'left join user as u on r.user_id = u.id';
		$referDB->where = 'r.goods_id = '.$goods_id;
		$referDB->order = 'r.id desc';
		$referDB->fields = 'u.username,u.head_ico,r.time,r.question,r.reply_time,r.answer';
		$referDB->page = $page;

		$data = $referDB->find();
		$pageHtml = $referDB->getPageBar("javascript:void(0);",'onclick="refer_ajax([page])"');

		echo JSON::encode(array('data' => $data,'pageHtml' => $pageHtml));
	}

	//评论列表页
	function comments_list()
	{
		$id   = IFilter::act(IReq::get("id"),'int');
		$type = IFilter::act(IReq::get("type"));

		$type_config = array('bad'=>'1','middle'=>'2,3,4','good'=>'5');

		if(!isset($type_config[$type]))
		{
			$type = null;
		}
		else
		{
			$type=$type_config[$type];
		}

		$data['comment_list']=array();

		$query = new IQuery("comment AS a");
		$query->fields = "a.*,b.username,b.head_ico";
		$query->join = "left join user AS b ON a.user_id=b.id";
		$query->where = " a.goods_id = {$id} ";

		if($type!==null)
			$query->where = " a.goods_id={$id} AND a.status=1  AND a.point IN ($type)";
		else
			$query->where = "a.goods_id={$id} AND a.status=1 ";

		$query->order    = "a.id DESC";
		$query->page     = IReq::get('page') ? intval(IReq::get('page')):1;
		$query->pagesize = 10;

		$data['comment_list']= $query->find();
		$this->comment_query = $query;

		if($data['comment_list'])
		{
			$user_ids = array();
			foreach($data['comment_list'] as $value)
			{
				$user_ids[]=$value['user_id'];
			}
			$user_ids = implode(",", array_unique( $user_ids ) );
			$query = new IQuery("member AS a");
			$query->join = "left join user_group AS b ON a.user_id IN ({$user_ids}) AND a.group_id=b.id";
			$query->fields="a.user_id,b.group_name";
			$user_info = $query->find();
			$user_info = Util::array_rekey($user_info,'user_id');

			foreach($data['comment_list'] as $key=>$value)
			{
				$data['comment_list'][$key]['user_group_name']=isset($user_info[$value['user_id']]['group_name']) ? $user_info[$value['user_id']]['group_name'] : '';
			}
		}

		$data=array_merge($data, Comment_Class::get_comment_info($id) );
		$this->data=$data;
		$this->redirect('comments_list');
	}

	//提交评论页
	function comments()
	{
		$id = IFilter::act(IReq::get('id'),'int');

		if(!$id)
		{
			IError::show(403,"Transfer parameters are not complete");
		}

		if(!isset($this->user['user_id']) || $this->user['user_id']==null )
		{
			IError::show(403,"After logging in to allow comments");
		}

		$can_submit = Comment_Class::can_comment($id,$this->user['user_id']);
		if($can_submit[0]==-1)
		{
			IError::show(403,"Without this data");
		}

		$this->can_submit   = $can_submit[0]==1;//true值
		$this->comment      = $can_submit[1]; //评论数据
		$this->comment_info = Comment_Class::get_comment_info($this->comment['goods_id']);
		$this->redirect("comments");
	}

	/**
	 * @brief 进行商品评论 ajax操作
	 */
	public function comment_add()
	{
		if(!isset($this->user['user_id']) || $this->user['user_id']===null)
		{
			die("Not logged in users can not comment");
		}

		if(IReq::get('id')===null)
		{
			die("Transfer parameters are not complete");
		}

		$id               = IFilter::act(IReq::get('id'),'int');
		$data             = array();
		$data['point']    = IFilter::act(IReq::get('point'),'float');
		$data['contents'] = IFilter::act(IReq::get("contents"),'content');
		$data['status']   = 1;

		if($data['point']==0)
		{
			die("Please select a score");
		}

		$can_submit = Comment_Class::can_comment($id,$this->user['user_id']);
		if($can_submit[0]!=1)
		{
			die("You can't comment on this item");
		}

		$data['comment_time'] = date("Y-m-d",ITime::getNow());

		$tb_comment = new IModel("comment");
		$tb_comment->setData($data);
		$re=$tb_comment->update("id={$id}");

		if($re)
		{
			//同步更新goods表,comments,grade
			$commentRow = $tb_comment->getObj('id = '.$id);

			$goodsDB = new IModel('goods');
			$goodsDB->setData(array(
				'comments' => 'comments + 1',
				'grade'    => 'grade + '.$commentRow['point'],
			));
			$goodsDB->update('id = '.$commentRow['goods_id'],array('grade','comments'));

			echo "success";
		}
		else
		{
			die("Comment failed");
		}
	}

	function pic_show()
	{
		$this->layout="";
		$this->redirect("pic_show");
	}

	function help()
	{
		$id = intval(IReq::get("id"));
		$tb_help = new IModel("help");
		$help_row = $tb_help->query("id={$id}");
		if(!$help_row || !is_array($help_row))
		{
			IError::show(404,"The page you are looking for does not exist.");
		}
		$this->help_row = end( $help_row );

		$tb_help_cat = new IModel("help_category");
		$cat_row = $tb_help_cat->query("id={$this->help_row['cat_id']}");
		$this->cat_row = end($cat_row);
		$this->redirect("help");
	}

	function help_list()
	{
		$id = intval(IReq::get("id"));
		$tb_help_cat = new IModel("help_category");
		$cat_row = $tb_help_cat->query("id={$id}");
		if($cat_row)
		{
			$this->cat_row = end($cat_row);
		}
		else
		{
			$this->cat_row = array('id'=>0,'name'=>'Site help');
		}
		$this->redirect("help_list");
	}

	//团购页面
	function groupon()
	{
		$id = IFilter::act(IReq::get("id"),'int');

		//指定某个团购
		if($id)
		{
			$this->regiment_list = Api::run('getRegimentRowById',array('#id#',$id));
			$this->regiment_list = $this->regiment_list ? array($this->regiment_list) : array();
		}
		else
		{
			$this->regiment_list = Api::run('getRegimentList');
		}

		//往期团购
		$this->ever_list = Api::run('getEverRegimentList');
		$this->redirect("groupon");
	}
	function brand_zone(){
       //新增浏览记录推荐开始
		$getsellerObj2 = new IModel('seller');
		$sellerArr = $getsellerObj2->getObj("province = $this->area_id");
		$this->seller_id = $sellerArr['id'] != '' ? $sellerArr['id'] : '';		
		$vt = ICookie::get($visits);
		if(isset($vt)){
			$goods_ids=$vt;
		}else{
			$goods_ids=array();
		}
		$goods_ids[]=$goods_id;
		if(isset($goods_id) && $goods_id != null) ICookie::set($visits,$goods_ids,'7200');
		
		//去除重复 
		$goods_ids=array_unique($goods_ids);		
		//去除数组中的null
		foreach( $goods_ids as $k=>$v){  
		    if( !$v ){
		    	unset( $goods_ids[$k] );
		    }else{
		    	$tb_goods3 = new IModel('goods');
		    	$goods_arr3 = $tb_goods3->getObj("id = $v");
		    	if($goods_arr3['seller_id'] != $this->seller_id){
		    		unset( $goods_ids[$k] );
		    	}
		    }
		          
		}  		
		shuffle($goods_ids);
		$gk=1;
		foreach ($goods_ids as $value){
			if($gk<=5){
				$gv .= ','.$value;
				$gk++;
			}
		}
		$gv = substr($gv, 1);

		$tb_goods2 = new IModel('goods');
		if($gv != ''){
			$goods_arr = $tb_goods2->query("id in ($gv)");
		}
		$this->goods_arr=$goods_arr;
		//新增浏览记录推荐结束
		$this->redirect("brand_zone");	
	}
}
