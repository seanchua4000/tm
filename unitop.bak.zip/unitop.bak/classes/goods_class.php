<?php
/**
 * @copyright (c) 2011 jooyea.cn
 * @file goods_class.php
 * @brief 商品管理类库
 * @author nswe
 * @date 2014/8/18 11:53:43
 * @version 2.6
 */
class goods_class
{
	//算账类库
	private static $countsumInstance = null;

	//商户ID
	public $seller_id = '';

	//构造函数
	public function __construct($seller_id = '')
	{
		$this->seller_id = $seller_id;
	}

	/**
	 * 获取商品价格
	 * @param int $goods_id 商品ID
	 * @param float $sell_price 商品销售价
	 */
	public static function price($goods_id,$sell_price)
	{
		if(self::$countsumInstance == null)
		{
			self::$countsumInstance = new CountSum();
		}
		$price = self::$countsumInstance->getGroupPrice($goods_id);
		return $price ? $price : $sell_price;
	}

	/**
	 * 生成商品货号
	 * @return string 货号
	 */
	public static function createGoodsNo()
	{
		$config = new Config('site_config');
		return $config->goods_no_pre.time().rand(10,99);
	}
	/*================fill+===============================================*/
	public function updateByGroup_default($id_str,$data){
		if($id_str){
			
			$goodsDB = new IModel('goods');
			$pro_goodsRow = $goodsDB->getObj('id = '.$id_str);
			if(!$pro_goodsRow){
				die('data error');
			}
			if(is_array($data['barcode'])){
				$goods_barcode=explode('-', current($data['barcode']));
				$barcode=$goods_barcode[0].'-'.$goods_barcode[1];
			}else{
				$barcode=$data['barcode'];
			}
			
			if(is_array($data['barcode'])){

				$productDB = new IModel('products');

				foreach($data['barcode'] as $k=>$v){

					$pro_where=" id=".$k." and goods_id=".$id_str;

					$productUpdateData=array();

					$productUpdateData['products_barcode']=$data['barcode'][$k];

					$productDB->setData($productUpdateData);

					if($productDB->update($pro_where) === false){
						die('update error');
					}										
				}
			}
			$goodsUpdateData['barcode']=$barcode;

			$nowDataTime = ITime::getDateTime();		


			$goodsDB->setData($goodsUpdateData);

			$where = "1";

			$where .= " and id in(".$id_str.")";

			if($goodsDB->update($where) === false)
			{
				die("update error");
			}else{

				$id_arr=explode(',', trim($id_str));

				for($j=0;$j<count($id_arr);$j++){
					$record_data['goods_id']=$id_arr[$j];
					$record_data['content']=$this->seller_id."update goods info by group";
					$this->goodsUpdateRecord($record_data);					
				}
			
				return true;
			}
		}				
	}	

	public function updateByGroupPlat($id_str,$data){
		if($id_str){
			
			$goodsDB = new IModel('goods');
			$pro_goodsRow = $goodsDB->getObj('id = '.$id_str.' and seller_id=0');
			if(!$pro_goodsRow){
				die('data error');
			}
			if(is_array($data['barcode'])){
				$goods_barcode=explode('-', current($data['barcode']));
				$barcode=$goods_barcode[0].'-'.$goods_barcode[1];
			}else{
				$barcode=$data['barcode'];
			}
			
			if(is_array($data['sell_price'])){

				$productDB = new IModel('products');
				$goodsUpdateData['store_nums']=0;

				foreach($data['sell_price'] as $k=>$v){

					$pro_where=" id=".$k." and goods_id=".$id_str;

					$productUpdateData=array();

					$productUpdateData['products_barcode']=$data['barcode'][$k];

					$productDB->setData($productUpdateData);

					if($productDB->update($pro_where) === false){
						die('update error');
					}										
				}
			}
			$goodsUpdateData['barcode']=$barcode;

			$nowDataTime = ITime::getDateTime();


			if($this->seller_id)
			{
				$where = "seller_id = 0";
			}else{
				die("update error");
			}			


			$goodsDB->setData($goodsUpdateData);

			$where .= " and id in(".$id_str.")";

			if($goodsDB->update($where) === false)
			{
				die("update error");
			}else{
				$id_arr=explode(',', trim($id_str));
				for($j=0;$j<count($id_arr);$j++){
					$record_data['goods_id']=$id_arr[$j];
					$record_data['content']=$this->seller_id."update goods info by group";
					$this->goodsUpdateRecord($record_data);					
				}
			
				return true;
			}
		}				
	}	
	public function updateByGroup($id_str,$data){//print_r($data);exit;
		if($id_str){
			
			$goodsDB = new IModel('goods');
			$pro_goodsRow = $goodsDB->getObj('id = '.$id_str.' and seller_id='.$this->seller_id);
			if(!$pro_goodsRow){
				die('data error');
			}
			if(is_array($data['barcode'])){
				$goods_barcode=explode('-', current($data['barcode']));
				$barcode=$goods_barcode[0].'-'.$goods_barcode[1];
			}else{
				$barcode=$data['barcode'];
			}

			$goods_commend_price='';
			
			if(is_array($data['sell_price'])){

				$productDB = new IModel('products');
				$goodsUpdateData['store_nums']=0;

				foreach($data['sell_price'] as $k=>$v){

					$pro_where=" id=".$k." and goods_id=".$id_str;

					$goodsUpdateData['store_nums']+=$data['store_nums'][$k];

					$productUpdateData=array();

					$productUpdateData['sell_price']=$data['sell_price'][$k];

					$productUpdateData['market_price']=$data['market_price'][$k];

					$productUpdateData['store_nums']=$data['store_nums'][$k];

					$productUpdateData['products_barcode']=$data['barcode'][$k];

					//$productUpdateData['count_price']=$data['commend_price'][$k];

					$productDB->setData($productUpdateData);

					if($productDB->update($pro_where) === false){
						die('update error');
					}										
				}

			}else{
				

				$goodsUpdateData['sell_price']=$data['sell_price'];

				$goodsUpdateData['market_price']=$data['market_price'];

				$goodsUpdateData['store_nums']=$data['store_nums'];	

				$goods_commend_price=$data['commend_price'];			
			}
			$goodsUpdateData['barcode']=$barcode;


			$goodsUpdateData['is_del']=$data['is_del'];

			$nowDataTime = ITime::getDateTime();

			$goodsUpdateData['is_del'] = $goodsUpdateData['is_del'] == 2 ? 2 : 0;

			if($this->seller_id)
			{
				$where = "seller_id = ".$this->seller_id;
			}else{
				die("update error");
			}

			//这里开始修改折扣价格
			/**
			if($goods_commend_price){
				$commend_goodsDB = new IModel('commend_goods');
				$commend_goods_data['count_price']=$goods_commend_price;
				$commend_goodsDB->setData($commend_goods_data);
				$commend_goodsDB->update('goods_id='.$id_str);
				Commonfunc::commend_goods_by_sellerid($this->seller_id,1);			
			}
			*/			
			//如果商户是VIP则无需审核商品
			if($goodsUpdateData['is_del'] == 3)
			{
				$sellerDB = new IModel('seller');
				$sellerRow= $sellerDB->getObj('id = '.$this->seller_id);
				if($sellerRow['is_vip'] == 1)
				{
					$goodsUpdateData['is_del'] = 0;
				}
			}
			//上架
			if($goodsUpdateData['is_del'] == 0)
			{
				$goodsUpdateData['up_time']   = $nowDataTime;
				$goodsUpdateData['down_time'] = null;
			}
			//下架
			else if($goodsUpdateData['is_del'] == 2)
			{
				$goodsUpdateData['up_time']  = null;
				$goodsUpdateData['down_time']= $nowDataTime;
			}
			//审核或者删除
			else
			{
				$goodsUpdateData['up_time']   = null;
				$goodsUpdateData['down_time'] = null;
			}			

			$goodsDB->setData($goodsUpdateData);

			$where .= " and id in(".$id_str.")";

			if($goodsDB->update($where) === false)
			{
				die("update error");
			}else{
				$id_arr=explode(',', trim($id_str));
				for($j=0;$j<count($id_arr);$j++){
					$record_data['goods_id']=$id_arr[$j];
					$record_data['content']=$this->seller_id."update goods info by group";
					$this->goodsUpdateRecord($record_data);					
				}
			
				return true;
			}
		}				
	}

	public function updateByseller($id,$paramData){

		$postData = array();
		$nowDataTime = ITime::getDateTime();
		$postData=$paramData;

		//商家发布商品默认设置

		$goodsUpdateData['seller_id'] = $this->seller_id;
		$goodsUpdateData['is_del'] = $postData['is_del'] == 2 ? 2 : 0;
		
		//如果商户是VIP则无需审核商品
		if($goodsUpdateData['is_del'] == 3)
		{
			$sellerDB = new IModel('seller');
			$sellerRow= $sellerDB->getObj('id = '.$this->seller_id);
			if($sellerRow['is_vip'] == 1)
			{
				$goodsUpdateData['is_del'] = 0;
			}
		}


		//上架或者下架处理
		if(isset($goodsUpdateData['is_del']))
		{
			//上架
			if($goodsUpdateData['is_del'] == 0)
			{
				$goodsUpdateData['up_time']   = $nowDataTime;
				$goodsUpdateData['down_time'] = null;
			}
			//下架
			else if($goodsUpdateData['is_del'] == 2)
			{
				$goodsUpdateData['up_time']  = null;
				$goodsUpdateData['down_time']= $nowDataTime;
			}
			//审核或者删除
			else
			{
				$goodsUpdateData['up_time']   = null;
				$goodsUpdateData['down_time'] = null;
			}
		}


		$goodsUpdateData['combination']  = isset($postData['combination']) ? $postData['combination'] : '';		

		$goodsUpdateData['store_nums']   = array_sum($postData['_store_nums']);
		$goodsUpdateData['market_price'] = isset($postData['_market_price']) ? current($postData['_market_price']) : 0;
		$goodsUpdateData['sell_price']   = isset($postData['_sell_price'])   ? current($postData['_sell_price'])   : 0;
		$goodsUpdateData['cost_price']   = isset($postData['_cost_price'])   ? current($postData['_cost_price'])   : 0;

		

		//处理商品
		$goodsDB = new IModel('goods');

	

		$goodsDB->setData($goodsUpdateData);

		$where = " id = {$id} ";

		$where .= " and seller_id = ".$this->seller_id;


		if($goodsDB->update($where) === false)
		{
			die("update error");
		}

		$cord_content="update goods.";
				

		$record_data['goods_id']=$id;
		$record_data['content']=$cord_content;
		$this->goodsUpdateRecord($record_data);		


		//是否存在货品
		$productsDB = new IModel('products');
		$productsInfo=$productsDB->getObj('goods_id = '.$id);
		if($productsInfo)
		{

			//创建货品信息
			foreach($postData['_goods_no'] as $key => $rs)
			{
				$productsData = array(
					'store_nums' => $postData['_store_nums'][$key],
					'market_price' => $postData['_market_price'][$key],
					'sell_price' => $postData['_sell_price'][$key],
					'cost_price' => $postData['_cost_price'][$key],
				);
				$productsDB->setData($productsData);
				$productsDB->update('products_no="'.$postData['_goods_no'][$key].'" and goods_id='.$id);
			}
		}		



		return true;
	}		


	/*===================fillend==========================================*/
	/**
	 * @brief 修改商品数据
	 * @param int $id 商品ID
	 * @param array $paramData 商品所需数据
	 */
	public function update($id,$paramData)
	{//print_r($paramData);
		$postData = array();
		$nowDataTime = ITime::getDateTime();
		//print_r($paramData);
		foreach($paramData as $key => $val)
		{
			$postData[$key] = $val;

			//数据过滤分组
			if(strpos($key,'attr_id_') !== false)
			{
				$goodsAttrData[ltrim($key,'attr_id_')] = IFilter::act($val);
			}
			else if($key == 'content')
			{
				$goodsUpdateData['content'] = IFilter::addSlash($val);
			}
			else if($key[0] != '_')
			{
				$goodsUpdateData[$key] = IFilter::act($val,'text');
			}
		}

		//商家发布商品默认设置
		if($this->seller_id)
		{
			$goodsUpdateData['seller_id'] = $this->seller_id;
			$goodsUpdateData['is_del'] = $goodsUpdateData['is_del'] == 2 ? 2 : 0;
			
			//如果商户是VIP则无需审核商品
			if($goodsUpdateData['is_del'] == 3)
			{
				$sellerDB = new IModel('seller');
				$sellerRow= $sellerDB->getObj('id = '.$this->seller_id);
				if($sellerRow['is_vip'] == 1)
				{
					$goodsUpdateData['is_del'] = 0;
				}
			}
		}

		//上架或者下架处理
		if(isset($goodsUpdateData['is_del']))
		{
			//上架
			if($goodsUpdateData['is_del'] == 0)
			{
				$goodsUpdateData['up_time']   = $nowDataTime;
				$goodsUpdateData['down_time'] = null;
			}
			//下架
			else if($goodsUpdateData['is_del'] == 2)
			{
				$goodsUpdateData['up_time']  = null;
				$goodsUpdateData['down_time']= $nowDataTime;
			}
			//审核或者删除
			else
			{
				$goodsUpdateData['up_time']   = null;
				$goodsUpdateData['down_time'] = null;
			}
		}

		//是否存在货品
		$goodsUpdateData['spec_array'] = '';
		if(isset($postData['_spec_array']))
		{
			//生成goods中的spec_array字段数据
			$goods_spec_array = array();
			foreach($postData['_spec_array'] as $key => $val)
			{
				foreach($val as $v)
				{
					$tempSpec = JSON::decode($v);
					if(!isset($goods_spec_array[$tempSpec['id']]))
					{
						$goods_spec_array[$tempSpec['id']] = array('id' => $tempSpec['id'],'name' => $tempSpec['name'],'type' => $tempSpec['type'],'value' => array());
					}
					$goods_spec_array[$tempSpec['id']]['value'][] = $tempSpec['value'];
				}
			}
			foreach($goods_spec_array as $key => $val)
			{
				$val['value'] = array_unique($val['value']);
				$goods_spec_array[$key]['value'] = join(',',$val['value']);
			}
			$goodsUpdateData['spec_array'] = JSON::encode($goods_spec_array);
		}
		$goodsUpdateData['combination']  = isset($postData['combination']) ? $postData['combination'] : '';		
		//$goodsUpdateData['goods_no']     = isset($postData['_goods_no'])     ? current($postData['_goods_no'])     : '';
		$goodsUpdateData['store_nums']   = array_sum($postData['_store_nums']);
		$goodsUpdateData['market_price'] = isset($postData['_market_price']) ? current($postData['_market_price']) : 0;
		$goodsUpdateData['sell_price']   = isset($postData['_sell_price'])   ? current($postData['_sell_price'])   : 0;
		$goodsUpdateData['cost_price']   = isset($postData['_cost_price'])   ? current($postData['_cost_price'])   : 0;
		$goodsUpdateData['weight']       = isset($postData['_weight'])       ? current($postData['_weight'])       : 0;
		
		
			$goods_no_arr=explode('-',$postData['_goods_no'][0]);
			$barcode_no_arr=explode('-',$postData['_barcode_array'][0]);

			if($this->seller_id||$paramData['seller_id']){
				$goodsUpdateData['goods_no']=$goods_no_arr[0].'-'.$goods_no_arr[1];
				$goodsUpdateData['barcode']=$barcode_no_arr[0].'-'.$barcode_no_arr[1];				
			}else{
				$goodsUpdateData['goods_no']=$goods_no_arr[0];
				$goodsUpdateData['barcode']=$barcode_no_arr[0];
			}
		
		//print_r($goodsUpdateData);exit;
		//处理商品
		$goodsDB = new IModel('goods');

		if(empty($goodsUpdateData['goods_no'])){
			die("product code need");
		}
		/**
		$pdcols=array('id');
		$pdwhere="(goods_no='".$goodsUpdateData['goods_no']."')";
		if(!empty($goodsUpdateData['barcode'])){
			$pdwhere .=" OR(barcode!=0 AND barcode='".$goodsUpdateData['barcode']."')";
		}
		if($id){
			$pdwhere ="(".$pdwhere.") and is_del!=1 and id!=".$id;
		}
		$alreadyArray=$goodsDB->query($pdwhere,$pdcols,'','','all');
		if(!empty($alreadyArray)){
			die("goods is already exists,please check product code  or barcode");
		}
		*/		
		if($id)
		{
			$goodsDB->setData($goodsUpdateData);

			$where = " id = {$id} ";
			if($this->seller_id)
			{
				$where .= " and seller_id = ".$this->seller_id;
			}

			if($goodsDB->update($where) === false)
			{
				die("update error");
			}

			$cord_content="update goods.";
				
		}
		else
		{
			
			$goodsUpdateData['create_time'] = $nowDataTime;
			$goodsDB->setData($goodsUpdateData);
			$id = $goodsDB->add();
			$cord_content="add goods";
		}
		$record_data['goods_id']=$id;
		$record_data['content']=$cord_content;
		$this->goodsUpdateRecord($record_data);		
		//处理商品属性
		$goodsAttrDB = new IModel('goods_attribute');
		$goodsAttrDB->del('goods_id = '.$id);
		if(isset($goodsAttrData) && $goodsAttrData)
		{
			foreach($goodsAttrData as $key => $val)
			{
				$attrData = array(
					'goods_id' => $id,
					'model_id' => $goodsUpdateData['model_id'],
					'attribute_id' => $key,
					'attribute_value' => is_array($val) ? join(',',$val) : $val
				);
				$goodsAttrDB->setData($attrData);
				$goodsAttrDB->add();
			}
		}

		//是否存在货品
		$productsDB = new IModel('products');
		$productsDB->del('goods_id = '.$id);
		if(isset($postData['_spec_array']))
		{
			$productIdArray = array();

			//创建货品信息
			foreach($postData['_goods_no'] as $key => $rs)
			{
				$productsData = array(
					'goods_id' => $id,
					'products_barcode' => $postData['_barcode_array'][$key],
					'products_no' => $postData['_goods_no'][$key],
					'store_nums' => $postData['_store_nums'][$key],
					'market_price' => $postData['_market_price'][$key],
					'sell_price' => $postData['_sell_price'][$key],
					'cost_price' => $postData['_cost_price'][$key],
					'weight' => $postData['_weight'][$key],
					'spec_array' => "[".join(',',$postData['_spec_array'][$key])."]"
				);
				$productsDB->setData($productsData);
				$productIdArray[$key] = $productsDB->add();
			}
		}

		//处理商品分类
		$categoryDB = new IModel('category_extend');
		$categoryDB->del('goods_id = '.$id);
		if(isset($postData['_goods_category']) && $postData['_goods_category'])
		{
			foreach($postData['_goods_category'] as $item)
			{
				$categoryDB->setData(array('goods_id' => $id,'category_id' => $item));
				$categoryDB->add();
			}
		}

		//处理商品促销
		$commendDB = new IModel('commend_goods');
		$commendDB->del('goods_id = '.$id);
		if(isset($postData['_goods_commend']) && $postData['_goods_commend'])
		{
			foreach($postData['_goods_commend'] as $item)
			{
				$commend_add_goods=array();

				if($postData['_goods_commend_price'])
					$commend_add_goods=array('goods_id' => $id,'commend_id' => $item,
					'count_price'=>$postData['_goods_commend_price']);
			    else
			    	$commend_add_goods=array('goods_id' => $id,'commend_id' => $item);
				$commendDB->setData($commend_add_goods);
				$commendDB->add();
			}
		}

		//处理商品关键词
		keywords::add($goodsUpdateData['search_words']);

		//处理商品图片
		$photoRelationDB = new IModel('goods_photo_relation');
		$photoRelationDB->del('goods_id = '.$id);
		if(isset($postData['_imgList']) && $postData['_imgList'])
		{
			$postData['_imgList'] = str_replace(',','","',trim($postData['_imgList'],','));
			$photoDB = new IModel('goods_photo');
			$photoData = $photoDB->query('img in ("'.$postData['_imgList'].'")','id');
			if($photoData)
			{
				foreach($photoData as $item)
				{
					$photoRelationDB->setData(array('goods_id' => $id,'photo_id' => $item['id']));
					$photoRelationDB->add();
				}
			}
		}

		//处理会员组的价格
		$groupPriceDB = new IModel('group_price');
		$groupPriceDB->del('goods_id = '.$id);
		if(isset($productIdArray) && $productIdArray)
		{
			foreach($productIdArray as $index => $value)
			{
				if(isset($postData['_groupPrice'][$index]) && $postData['_groupPrice'][$index])
				{
					$temp = JSON::decode($postData['_groupPrice'][$index]);
					foreach($temp as $k => $v)
					{
						$groupPriceDB->setData(array(
							'goods_id' => $id,
							'product_id' => $value,
							'group_id' => $k,
							'price' => $v
						));
						$groupPriceDB->add();
					}
				}
			}
		}
		else
		{
			if(isset($postData['_groupPrice'][0]) && $postData['_groupPrice'][0])
			{
				$temp = JSON::decode($postData['_groupPrice'][0]);
				foreach($temp as $k => $v)
				{
					$groupPriceDB->setData(array(
						'goods_id' => $id,
						'group_id' => $k,
						'price' => $v
					));
					$groupPriceDB->add();
				}
			}
		}
		return true;
	}
	/**
	*添加商品编辑记录
	*/
	public function goodsUpdateRecord($data){
		$recordDB = new IModel('goodsUpdate_record');
		$_data['userid']=ICookie::get('seller_id');
		$_data['goods_id']=$data['goods_id'];
		$_data['content']=$data['content'];
		$_data['create_time']=time();
		$_data['username']=ICookie::get('seller_name');
		$recordDB->setData($_data);
		$recordDB ->add();
	}

	/**
	* @brief 删除与商品相关表中的数据
	*/
	public function del($goods_id)
	{
		$goodsWhere = " id = '{$goods_id}' ";
		if($this->seller_id)
		{
			$goodsWhere .= " and seller_id = ".$this->seller_id;
		}

		//删除商品表
		$tb_goods = new IModel('goods');
		if(!$tb_goods ->del($goodsWhere))
		{
			return;
		}
		if($this->seller_id){
			$sellergoods = new IModel('user_goods_copyrecord');
			$sellerWhere ="goods_id=".$goods_id." and seller_id = ".$this->seller_id;
			$sellergoods ->del($sellerWhere);			
		}

	}
	/**
	 * 获取编辑商品所有数据
	 * @param int $id 商品ID
	 */
	public function edit($id)
	{
		$id = IFilter::act($id,'int');
		$goodsWhere = " id = {$id} ";
		if($this->seller_id)
		{
			$goodsWhere .= " and seller_id = ".$this->seller_id;
		}

		//获取商品
		$obj_goods = new IModel('goods');
		$goods_info = $obj_goods->getObj($goodsWhere);

		if(!$goods_info)
		{
			return null;
		}

		//获取商品的会员价格
		$groupPriceDB = new IModel('group_price');
		$goodsPrice   = $groupPriceDB->query("goods_id = ".$goods_info['id']." and product_id is NULL ");
		$temp = array();
		foreach($goodsPrice as $key => $val)
		{
			$temp[$val['group_id']] = $val['price'];
		}
		$goods_info['groupPrice'] = $temp ? JSON::encode($temp) : '';

		//赋值到FORM用于渲染
		$data = array('form' => $goods_info);

		//获取货品
		$productObj = new IModel('products');
		$product_info = $productObj->query('goods_id = '.$id,'','','asc');
		if($product_info)
		{
			//获取货品会员价格
			foreach($product_info as $k => $rs)
			{
				$temp = array();
				$productPrice = $groupPriceDB->query('product_id = '.$rs['id'],'','','asc');
				foreach($productPrice as $key => $val)
				{
					$temp[$val['group_id']] = $val['price'];
				}
				$product_info[$k]['groupPrice'] = $temp ? JSON::encode($temp) : '';
			}
			$data['product'] = $product_info;
		}

		//加载推荐类型
		$tb_commend_goods = new IModel('commend_goods');
		$commend_goods = $tb_commend_goods->query('goods_id='.$goods_info['id'],'commend_id,count_price');
		
		if($commend_goods)
		{
			foreach($commend_goods as $value)
			{
				$data['goods_commend'][] = $value['commend_id'];
				$data['goods_commend_price'][] = $value['count_price'];
			}
		}

		//相册
		$tb_goods_photo = new IQuery('goods_photo_relation as ghr');
		$tb_goods_photo->join = 'left join goods_photo as gh on ghr.photo_id=gh.id';
		$tb_goods_photo->fields = 'gh.img';
		$tb_goods_photo->where = 'ghr.goods_id='.$goods_info['id'];
		$tb_goods_photo->order = 'ghr.id asc';
		$data['goods_photo'] = $tb_goods_photo->find();

		//扩展基本属性
		$goodsAttr = new IQuery('goods_attribute');
		$goodsAttr->where = "goods_id=".$goods_info['id']." and attribute_id != '' ";
		$attrInfo = $goodsAttr->find();
		if($attrInfo)
		{
			foreach($attrInfo as $item)
			{
				//key：属性名；val：属性值,多个属性值以","分割
				$data['goods_attr'][$item['attribute_id']] = $item['attribute_value'];
			}
		}

		//商品分类
		$categoryExtend = new IQuery('category_extend');
		$categoryExtend->where = 'goods_id = '.$goods_info['id'];
		$tb_goods_photo->fields = 'category_id';
		$cateData = $categoryExtend->find();
		if($cateData)
		{
			foreach($cateData as $item)
			{
				$data['goods_category'][] = $item['category_id'];
			}
		}//print_r($data);
		return $data;
	}
	/**
	 * @param
	 * @return array
	 * @brief 无限极分类递归函数
	 */
	public static function sortdata($catArray, $id = 0 , $prefix = '')
	{
		static $formatCat = array();
		static $floor     = 0;

		foreach($catArray as $key => $val)
		{
			if($val['parent_id'] == $id)
			{
				$str         = self::nstr($prefix,$floor);
				$val['name'] = $str.$val['name'];

				$val['floor'] = $floor;
				$formatCat[]  = $val;

				unset($catArray[$key]);

				$floor++;
				self::sortdata($catArray, $val['id'] ,$prefix);
				$floor--;
			}
		}
		return $formatCat;
	}

	/**
	 * @brief 计算商品的价格区间
	 * @param $goodsId      商品id,逗号间隔
	 * @param $showPriceNum 展示分组最大数量
	 * @return array        价格区间分组
	 */
	public static function getGoodsPrice($goodsId,$showPriceNum = 5)
	{
		$goodsObj     = new IModel('goods');
		$goodsPrice   = $goodsObj->getObj('id in ('.$goodsId.')','MIN(sell_price) as min,MAX(sell_price) as max');
		if($goodsPrice['min'] <= 0)
		{
			return array();
		}

		$minPrice = floor($goodsPrice['min']);

		//商品价格计算
		$result   = array('1-'.$minPrice);
		$perPrice = floor(($goodsPrice['max'] - $minPrice)/($showPriceNum - 1));

		if($perPrice > 0)
		{
			for($addPrice = $minPrice+1; $addPrice < $goodsPrice['max'];)
			{
				$stepPrice = $addPrice + $perPrice;
				$stepPrice = substr(intval($stepPrice),0,1).str_repeat('9',(strlen(intval($stepPrice)) - 1));
				$result[]  = $addPrice.'-'.$stepPrice;
				$addPrice  = $stepPrice + 1;
			}
		}
		return $result;
	}

	//处理商品列表显示缩进
	public static function nstr($str,$num=0)
	{
		$return = '';
		for($i=0;$i<$num;$i++)
		{
			$return .= $str;
		}
		return $return;
	}

	/**
	 * @brief  获取分类数据
	 * @param  int   $catId  分类ID
	 * @return array $result array(id => name)
	 */
	public static function catRecursion($catId)
	{
		$result = array();
		$catDB  = new IModel('category');
		$catRow = $catDB->getObj("id = '{$catId}'");
		while(true)
		{
			if($catRow)
			{
				array_unshift($result,array('id' => $catRow['id'],'name' => $catRow['name']));
				$catRow = $catDB->getObj('id = '.$catRow['parent_id']);
			}
			else
			{
				break;
			}
		}
		return $result;
	}

	/**
	 * @brief 获取树形分类
	 * @param int $catId 分类ID
	 * @return array
	 */
	public static function catTree($catId)
	{
		$result    = array();
		$catDB     = new IModel('category');
		$childList = $catDB->query("parent_id = '{$catId}'");
		if(!$childList)
		{
			$catRow = $catDB->getObj("id = '{$catId}'");
			$childList = $catDB->query('parent_id = '.$catRow['parent_id']);
		}
		return $childList;
	}

	/**
	 * @brief 获取子分类可以无限递归获取子分类
	 * @param int $catId 分类ID
	 * @param int $level 层级数
	 * @return array
	 */
	public static function catChild($catId,$level = 1)
	{
		if($level == 0)
		{
			return $catId;
		}

		$temp   = array();
		$result = array($catId);
		$catDB  = new IModel('category');

		while(true)
		{
			$id = current($result);
			if(!$id)
			{
				break;
			}
			$temp = $catDB->query('parent_id = '.$id);
			foreach($temp as $key => $val)
			{
				$result[] = $val['id'];
			}
			next($result);
		}
		return join(',',$result);
	}

	/**
	 * @brief 返回商品状态
	 * @param int $is_del 商品状态
	 * @return string 状态文字
	 */
	public static function statusText($is_del)
	{
		$date = array('0' => 'The shelves','1' => 'delete','2' => 'off-loading','3' => 'Waiting for Review');
		return isset($date[$is_del]) ? $date[$is_del] : '';
	}

	public static function getGoodsCategory($goods_id){

		$gcQuery         = new IQuery('category_extend as ce');
		$gcQuery->join   = "left join category as c on c.id = ce.category_id";
		$gcQuery->where  = "ce.goods_id = '{$goods_id}'";
		$gcQuery->fields = 'c.name';

		$gcList = $gcQuery->find();
		$strCategoryNames = '';
		foreach($gcList as $val){
			$strCategoryNames .= $val['name'] . ',';
		}
		unset($gcQuery,$gcList);
		return $strCategoryNames;
	}


	public static function getGoodsInfoByField($field,$where,$type=''){
		$gcQuery  = new IQuery('goods');
		$gcQuery->where  = $where;
		$gcQuery->fields = $type ? $field : implode(',', $field);
		$gcList = $gcQuery->find();
		if($type){
			$result='';
			$result=$gcList[0][$field];
		}else{
			$result=array();
			for($i=0;$i<count($field);$i++){
				$result[$field[$i]]= $gcList[0][$field[$i]];
			}				
		}
	
		unset($gcQuery,$gcList);
		return $result;	
	}
	public static function productBygoodsId($id_arr){
		$productObj = new IModel('products');
		$groupPriceDB = new IModel('group_price');

		if(is_array($id)){
			$return_array=array();
			for($i=0;$i<count($id_arr);$i++){
				$id=$id_arr[$i];
				if(!is_numeric($id)){
					break;
				}
				$product_info = $productObj->query('goods_id = '.$id,'','','asc');
				if($product_info)
				{
					//获取货品会员价格
					foreach($product_info as $k => $rs)
					{
						$temp = array();
						$productPrice = $groupPriceDB->query('product_id = '.$rs['id'],'','','asc');
						foreach($productPrice as $key => $val)
						{
							$temp[$val['group_id']] = $val['price'];
						}
						$product_info[$k]['groupPrice'] = $temp ? JSON::encode($temp) : '';
					}
					$data['product'] = $product_info;
				}
				$return_array[$id][]=$data;					
			}
			return $return_array;			
		}else{
			$id=$id_arr;
			if(!is_numeric($id)){
				return;
			}
			$product_info = $productObj->query('goods_id = '.$id,'','','asc');
			if($product_info)
			{
				//获取货品会员价格
				foreach($product_info as $k => $rs)
				{
					$temp = array();
					$productPrice = $groupPriceDB->query('product_id = '.$rs['id'],'','','asc');
					foreach($productPrice as $key => $val)
					{
						$temp[$val['group_id']] = $val['price'];
					}
					$product_info[$k]['groupPrice'] = $temp ? JSON::encode($temp) : '';
				}
				$data['product'] = $product_info;
			}
			return $data;			
		}
	
	}

	public static function findeditGoodsRecordInfoById($id){
		$gcQuery  = new IQuery('goodsUpdate_record');
		$gcQuery->where  = 'goods_id='.$id;
		$gcQuery->fields = 'create_time,username';
		$gcQuery->group = 'create_time desc';
		$gcQuery->limit = '1';
		$gcList = $gcQuery->find();
		return $gcList[0];		
	}
	
	/**
	 * @brief 返回检索条件相关信息
	 * @param int $search 条件数组
	 * @return array 查询条件（$join,$where）数据组
	 */
	public static function getSearchCondition($search)
	{
		$join  = " left join seller as seller on go.seller_id = seller.id ";
		$where = " 1 ";
		//条件筛选处理
		if(isset($search['name']) && isset($search['keywords']) && $search['keywords'])
		{
			$where .= " and ".$search['name']." like '%".$search['keywords']."%' ";
		}
		if(isset($search['barcode'])&& $search['barcode']!=='')
		{
			$where .= " and go.barcode   like '%".addslashes($search['barcode'])."%' ";
		}
		if(isset($search['category_id']) && $search['category_id'])
		{
			$join  .= " left join category_extend as ce on ce.goods_id = go.id ";
			$where .= " and ce.category_id = ".$search['category_id'];
		}

		if(isset($search['is_del']) && $search['is_del'] !== '')
		{
			$where .= " and go.is_del = ".$search['is_del'];
		}
		else
		{
			$where .= " and go.is_del != 1";
		}

		if(isset($search['store_nums']) && $search['store_nums'])
		{
			$search['store_nums'] = htmlspecialchars_decode($search['store_nums']);
			$where .= " and ".$search['store_nums'];
		}

		if(isset($search['commend_id']) && $search['commend_id'])
		{
			$join  .= " left join commend_goods as cg on go.id = cg.goods_id ";
			$where .= " and cg.commend_id = ".$search['commend_id'];
		}

		if(isset($search['seller_id']) && $search['seller_id'])
		{
			$where .= " and go.seller_id ".$search['seller_id'];
		}
		if(isset($search['sell_price_b']) && $search['sell_price_b'])
		{
			$where .= " and go.sell_price >=".$search['sell_price_b'];
		}
		if(isset($search['sell_price_e']) && $search['sell_price_e'])
		{
			$where .= " and go.sell_price <=".$search['sell_price_e'];
		}				
		$results = array($join,$where);
		unset($join,$where);
		return $results;
	}

	/**
	 * @brief 检查商品或者货品的库存是否充足
	 * @param $buy_num 检查数量
	 * @param $goods_id 商品id
	 * @param $product_id 货品id
	 * @result array() true:满足数量; false:不满足数量
	 */
	public static function checkStore($buy_num,$goods_id,$product_id = 0)
	{
		$data = $product_id ? Api::run('getProductInfo',array('#id#',$product_id)) : Api::run('getGoodsInfo',array('#id#',$goods_id));

		//库存判断
		if($buy_num <= 0 || $buy_num > $data['store_nums'])
		{
			return false;
		}
		return true;
	}
}