<?php

	session_start();
	if (!defined('FACE_ROOT')) {
	    define('FACE_ROOT', dirname(__FILE__) . '/');
	    require_once FACE_ROOT . 'facebook-sdk/autoload.php';
	}	
	class Facesdk{

	    private $_ID;

	    private $_KEY;

	    private $fb;

		public function __construct($id,$sec)
		{

			$this->_ID = $id;
			$this->_KEY	= $sec;
			$this->fb = new Facebook\Facebook([
			  'app_id' => $this->_ID,
			  'app_secret' => $this->_KEY,
			  'default_graph_version' => 'v2.2',
			  'cookie'=>true,
			]);
		}

	    public function login($url){

			$helper = $this->fb->getRedirectLoginHelper();
			//$url='http://www.unitop.com.ph/fbook/fbback';
			$permissions = array('email');// optional
			$loginUrl = $helper->getLoginUrl($url, $permissions);

			echo '<a href="' . $loginUrl . '">Log in with Facebook!</a>';  	
	    }

	    public function fbback(){
	    	
			$helper = $this->fb->getRedirectLoginHelper();  

			try {  
			  $accessToken = $helper->getAccessToken();  
			} catch(Facebook\Exceptions\FacebookResponseException $e) {  
			  // When Graph returns an error  
			  echo 'Graph returned an error: ' . $e->getMessage();  
			  exit;  
			} catch(Facebook\Exceptions\FacebookSDKException $e) {  
			  // When validation fails or other local issues  
			  echo 'Facebook SDK returned an error: ' . $e->getMessage();  
			  exit;  
			}  

			if (! isset($accessToken)) {  

			    echo 'aaaaaaaa';exit;
 
			}  

			var_dump($accessToken->getValue);

			$_SESSION['fb_access_token'] = (string) $accessToken;  

			// User is logged in with a long-lived access token.  
			// You can redirect them to a members-only page.  
			echo ":)成功了，亲".$_SESSION['fb_access_token'];
			//header("Location: http://website/project/main.php", true, 302);
							    	
	    }	
	}