<?php
/**
 * check website safe strategy
 * @date 2013/9/8 17:00:46
 * @author nswe
 */
class safeStrategy
{
	private $safeInfo = array();

	/**
	 * constructor
	 */
	public function __construct()
	{
	}

	/**
	 * start check website safe options and return a array
	 * @return array
	 */
	public function check()
	{
		$this->cInstall();
		$this->cAuthorize();
		return $this->safeInfo;
	}

	/**
	 * check authorize info
	 */
	private function cAuthorize()
	{
		$return = Proxy::getAuthorize();
		if($return == false)
		{
			$this->safeInfo[] = array('content' => 'The software you are using does not make a business license, please purchase as soon as possible！<a href="http://www.aircheng.com/buy" target="_blank">Click authorization</a>');
		}
	}

	/**
	 * check the install dir whether exists
	 * @return boolean
	 */
	private function cInstall()
	{
		$appBasePath = IWeb::$app->getBasePath();
		$installPath = $appBasePath . 'install';

		if(file_exists($installPath))
		{
			$this->safeInfo[] = array('content' => 'Your installation directory is not deleted, in order to store security, please delete or rename as soon as possible');
		}
	}
}