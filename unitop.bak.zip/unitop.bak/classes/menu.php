<?php
/**
 * @copyright Copyright(c) 2011 jooyea.cn
 * @file menu.php
 * @brief 后台系统菜单管理
 * @author webning
 * @date 2011-01-12
 * @version 0.6
 * @note
 */
/**
 * @brief Menu
 * @class Menu
 * @note
 */
class Menu
{
	private static $commonMenu = array('/system/default');

	public $current;

    //菜单的配制数据
	private static $menu = array(
		'Goods'=>array(
			'Commodity management'=>array(
				'/goods/goods_list' => 'List of goods',
				'/goods/goods_edit' => 'Commodity add'
			),
			'Commodity classification'=>array(
				'/goods/category_list'	=>	'Classification list',
				'/goods/category_edit'	=>	'Add category'
			),
			'Brand'=>array(
				'/brand/category_list'  =>	'Brand classification',
				'/brand/brand_list'		=>	'Brand list'
			),
			'Model'=>array(
				'/goods/model_list'=>'Model List',
				'/goods/spec_list'=>'Specification list',
				'/goods/spec_photo'=>'Specification Gallery'
			),
			'Search'=>array(
				'/tools/keyword_list' => 'Keywords list',
				'/tools/search_list' => 'Search statistics'
			)
		),

		'Member'=>array(
			'Member'=>array(
	    		'/member/member_list' => 'Member list',
	     		'/member/group_list' => 'Rank list',
			),
			'merchant' => array(
				'/member/seller_list' => 'Business listings',
				'/member/seller_edit' => 'Add merchant',
			),
			'information processing' => array(
				'/comment/suggestion_list'  => 'Proposed management',
				'/comment/refer_list'		=> 'Consulting management',
				'/comment/discussion_list'	=> 'Discussion management',
				'/comment/comment_list'		=> 'Evaluation management',
				'/comment/message_list'		=> 'Station message',
				'/message/notify_list'      => 'Notice of arrival',
				'/message/registry_list'    => 'Mail subscription',
			),
		),

	   'Order'=>array(
        	'Order management'=>array(
                '/order/order_list' => 'Order list',
                '/order/order_edit' => 'Add order'
        	),
        	'Document management'=>array(
             	'/order/order_collection_list'  => 'receipt',
             	'/order/order_refundment_list'  => 'Refund order',
        		'/order/order_delivery_list'    => 'Invoice',
        		'/order/refundment_list'        => 'Refund application list',
        	),
        	'Shipping address'=>array(
        		'/order/ship_info_list'         => 'Shipping address management',
        	),
		),

		'Marketing'=>array(
        	'sales promotion' => array(
        		'/market/pro_rule_list' => 'List of promotional activities'
        	),
        	'Coupon management'=>array(
        		'/market/ticket_list'       => 'Coupon list',
        		'/market/ticket_excel_list' => 'Coupon file list',
        	)
		),

		'Statistics'=>array(
			'Basic data statistics'=>array(
      			'/market/user_reg' 	   => 'User registration statistics',
				'/market/spanding_avg' => 'Per capita consumption statistics',
      			'/market/amount'       => 'Sales statistics'
			),
			'Log operation record'=>array(
				//'/market/account_list'   => '充值操作记录',
				'/market/operation_list' => 'Background operation record',
			)
		),


        'System'=>array(
    		'Back'=>array(
    			'/system/default' => 'Back home',
    		),
        	'Web'=>array(
        		'/system/conf_base' => 'Web site settings',
        		//'/system/conf_ui'   => '主题设置',
        	),
        	'Payment'=>array(
            	'/system/payment_list' => 'Payment method'
        	),
        	'Third party platform'=>array(
            	'/system/oauth_list' => 'oauth Login list',
            	'/system/wechat' => 'WeChat platform',
            	'/system/hsms' => 'Mobile phone short message platform',
        	),
        	'Distribution management'=>array(
            	'/system/delivery'  	=> 'Distribution mode',
        		'/system/freight_list'	=> 'logistics company',
	    		'/system/takeself_list' => 'Since the takeself_list',
	    		'/system/takeself_edit'  => 'add takeself',
        	),
        	'Regional management'=>array(
        		'/system/area_list' => 'Area list',
        	),
        	'Authority management'=>array(
        		'/system/admin_list' => 'administrators',
        		'/system/role_list'  => 'role',
        		'/system/right_list' => 'Rights Resources'
        	),
		),

       'Tools'=>array(
			'Database'=>array(
				'/tools/db_bak' => 'Database backup',
				'/tools/db_res' => 'Database restore',
			),
			'Article'=>array(
				'/tools/article_cat_list'=> 'Classification of articles',
				'/tools/article_list'=> 'Article list'
			),

			'Help'=>array(
   				'/tools/help_cat_list'=> 'Help classification',
   				'/tools/help_list'=> 'Help list'
   			),

   			'Ads'=>array(
   				'/tools/ad_position_list'=> 'List of ad',
   				'/tools/ad_list'=> 'List of ads'
   			),
   			'Link'=>array(
   				'/tools/link_list'=> 'Friendship link',
   			),   			

   			'Announcement'=>array(
   				'/tools/notice_list'=> 'Announcement list',
   				'/tools/notice_edit'=> 'Announcement release'
   			),
     		'Web map'=>array(
            	'/tools/seo_sitemaps' => 'Web search map',
			)
		)
	);

	/**
	 * @brief 对于menu列表未定义的进行映射别名操作 key => 当前URL地址 ， value => 替换的URL地址
	 */
	private static $menu_non_display = array(
		'/system/navigation' => '/system/default',
		'/system/navigation_edit' => '/system/default',
		'/system/navigation_recycle' => '/system/default',
		'/system/delivery_edit' => '/system/delivery',
		'/system/delivery_recycle' => '/system/delivery',

		'/member/recycling' => '/member/member_list',

		'/tools/article_edit_act'=>'/tools/article_list',

		'/market/ticket_edit' => '/market/ticket_list',
		'/market/bill_edit' => '/market/bill_list',

		'/order/collection_show' => '/order/order_collection_list',
		'/order/refundment_show' => '/order/order_refundment_list',
		'/order/delivery_show' => '/order/order_delivery_list',
		'/order/refundment_doc_show' => '/order/refundment_list',
		'/order/print_template' => '/order/order_list',
		'/order/collection_recycle_list' => '/order/order_collection_list',
		'/order/delivery_recycle_list' => '/order/order_delivery_list',
		'/order/recycle_list'	=>	'/order/ship_info_list',
		'/order/expresswaybill_edit' => '/order/order_list',
		'/order/order_show' => '/order/order_list',
	);

    /**
     * @brief 根据用户的权限过滤菜单
     * @return array
     */
    private function filterMenu()
    {
    	$rights = ISession::get('admin_right');

		//如果不是超级管理员则要过滤菜单
		if($rights != 'administrator')
		{
			foreach(self::$menu as $firstKey => $firstVal)
			{
				if(is_array($firstVal))
				{
					foreach($firstVal as $secondKey => $secondVal)
					{
						if(is_array($secondVal))
						{
							foreach($secondVal as $thirdKey => $thirdVal)
							{
								if(!in_array($thirdKey,self::$commonMenu) && (stripos(str_replace('@','/',$rights),','.substr($thirdKey,1).',') === false))
								{
									unset(self::$menu[$firstKey][$secondKey][$thirdKey]);
								}
							}
							if(empty(self::$menu[$firstKey][$secondKey]))
							{
								unset(self::$menu[$firstKey][$secondKey]);
							}
						}
					}
					if(empty(self::$menu[$firstKey]))
					{
						unset(self::$menu[$firstKey]);
					}
				}
			}
		}
    }

    /**
     * @brief 取得当前菜单应该生成的对应JSON数据
     * @param boolean $is_auto 是否智能匹配菜单
     * @return Json
     */
	public function submenu($is_auto = false)
	{
		$result     = array();
		$controller = IWeb::$app->getController()->getId();
		$action     = IWeb::$app->getController()->getAction()->getId();

		//当前菜单无定义时做映射别名
		$this->current = '/'.$controller.'/'.$action;
		if(isset(self::$menu_non_display[$this->current]))
		{
			$this->current = self::$menu_non_display[$this->current];
		}
		else
		{
			$actionArray = explode("_",$action);
			$model = current($actionArray);
		}

		$find_current = false;

		//过滤无操作权限的菜单
		$this->filterMenu();

		foreach(self::$menu as $key => $value)
		{
			$item = array();
			$item['current'] = false;
			$item['title']   = $key;

			foreach($value as $big_cat_name => $big_cat)
			{
				foreach($big_cat as $link => $title)
				{
					//把菜单的第一连接项分给顶级菜单
					if(!isset($item['link']))
					{
						$item['link'] = $link;
					}

					if($find_current)
					{
						break;
					}

					//遍历菜单项找到与当前连接相同的项目
					if( $link == $this->current || ($is_auto == true && isset($model) && preg_match("!^/[^/]+/{$model}_!",$link) ) )
					{
						$item['current'] = $find_current = true;
						foreach($value as $k => $v)
						{
							foreach($v as $subMenuKey => $subMenuName)
							{
								$tmpUrl = IUrl::creatUrl($subMenuKey);
								unset($value[$k][$subMenuKey]);
								$value[$k][$tmpUrl]['name'] = $subMenuName;
								$value[$k][$tmpUrl]['urlPathinfo'] = $subMenuKey;
							}
						}
						$item['list'] = $value;
					}
				}

				if($find_current)
				{
					break;
				}
			}
			$item['link'] = IUrl::creatUrl($item['link']);
			$result[] = $item;
		}

		if($find_current == false && $is_auto == false)
		{
			return $this->submenu(true);
		}

		return JSON::encode($result);
	}
}