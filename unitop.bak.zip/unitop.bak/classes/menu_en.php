<?php
/**
 * @copyright Copyright(c) 2011 jooyea.cn
 * @file menu.php
 * @brief 后台系统菜单管理
 * @author webning
 * @date 2011-01-12
 * @version 0.6
 * @note
 */
/**
 * @brief Menu
 * @class Menu
 * @note
 */
class Menu_en
{
	private static $commonMenu = array('/system/default');

	public $current;

    //菜单的配制数据
	private static $menu = array(
		'Product'=>array(
			'Product Management'=>array(
				'/goods/goods_list' => 'Product List',
				'/goods/goods_edit' => 'Items to Add'
			),
			'Categories'=>array(
				'/goods/category_list'	=>	'Categories List',
				'/goods/category_edit'	=>	'Add Category'
			),
			'Brand Name'=>array(
				'/brand/category_list'  =>	'Brand Category',
				'/brand/brand_list'		=>	'Brand List'
			),
			'Model'=>array(
				'/goods/model_list'=>'Model List',
				'/goods/spec_list'=>'Specification List',
				'/goods/spec_photo'=>'Specs Gallery'
			),
			'Search'=>array(
				'/tools/keyword_list' => 'Keyword List',
				'/tools/search_list' => 'View Data'
			)
		),

		'Member'=>array(
			'Member Management'=>array(
	    		'/member/member_list' => 'Member List',
	     		'/member/group_list' => 'Level List',
	     		'/member/amount_change' => 'Amount List',
	     		'/member/member_suggestions' => 'Member Suggestions',
			),
			'Branch Management' => array(
				'/member/seller_list' => 'Branch List',
				'/member/seller_edit' => 'Add Branch',
			),
			'Information Management' => array(
				'/comment/suggestion_list'  => 'Recommendation Management',
				'/comment/refer_list'		=> 'Question Management',
				'/comment/discussion_list'	=> 'Discussion Management ',
				'/comment/comment_list'		=> 'Evaluation Management',
				'/comment/message_list'		=> 'System Message',
				'/message/notify_list'      => 'Stock Arrival Notification',
				'/message/registry_list'    => 'Email Subscriptions',
			),
		),

	   'Orders'=>array(
        	'Order Management'=>array(
                '/order/order_list' => 'Order List',
                '/order/order_edit' => 'Add an Order'
        	),
        	'Receipt Management'=>array(
             	'/order/order_collection_list'  => 'Receipt',
             	'/order/order_refundment_list'  => 'Refund Receipt',
        		'/order/order_delivery_list'    => 'Delivery Receipt',
        		'/order/refundment_list'        => 'Refund Request List',
        	),
        	'Delivery Address'=>array(
        		'/order/ship_info_list'         => 'Delivery Address Management',
        	),
		),

		'Marketing'=>array(
        	'Promotions' => array(
        		'/market/pro_rule_list' => 'Promotion List'
        	),
        	'Coupon Management'=>array(
        		'/market/ticket_list'       => 'Coupon List',
        		'/market/ticket_excel_list' => 'Coupons File List',
        	)
		),

		'Reports'=>array(
			'Basic Reports'=>array(
      			'/market/user_reg' 	   => 'User Registration Reports',
				'/market/spanding_avg' => 'Per Person Consumption Reports',
      			'/market/amount'       => 'Sales Report'
			),
			'Log operation record'=>array(
				'/market/operation_list' => 'Background operation record',
			)
		),


        'System'=>array(
    		'Backstage Home'=>array(
    			'/system/default' => 'Backstage Home',
    		),
        	'Site Management'=>array(
        		'/system/conf_base' => 'Site Settings',
        		//'/system/conf_ui'   => '主题设置',
        	),
        	'Payment Management'=>array(
            	'/system/payment_list' => 'Payment Method'
        	),
        	'Delivery Management'=>array(
            	'/system/delivery'  	=> 'Delivery Method',
        		'/system/freight_list'	=> 'Courier Companies',
	    		'/system/takeself_list' => 'Pick-Up Address List',
	    		'/system/takeself_edit'  => 'Add Pick-Up Address',
        	),
        	'Region Management'=>array(
        		'/system/area_list' => 'Regions',
        	),
        	'Authority Management'=>array(
        		'/system/admin_list' => 'Management',
        		'/system/role_list'  => 'Role',
        		'/system/right_list' => 'Resource Authoritys'
        	),
		),

       'Tools'=>array(
			'Database Management'=>array(
				'/tools/db_bak' => 'Back-Up Database ',
				'/tools/db_res' => 'Restore Database ',
			),
			'Article management'=>array(
				'/tools/article_cat_list'=> 'Classification of articles',
				'/tools/article_list'=> 'Article list'
			),

			'Help manage'=>array(
   				'/tools/help_cat_list'=> 'Help classification',
   				'/tools/help_list'=> 'Help list'
   			),

   			'Advertising management'=>array(
   				'/tools/ad_position_list'=> 'List of ad_position_list',
   				'/tools/ad_list'=> 'List of ads'
   			),
   			'Link management'=>array(
   				'/tools/link_list'=> 'Friendship link',
   			),   			

   			'Announcement management'=>array(
   				'/tools/notice_list'=> 'Announcement list',
   				'/tools/notice_edit'=> 'Announcement release'
   			),
     		'Site map'=>array(
            	'/tools/seo_sitemaps' => 'Web search map',
			)
		)
	);

	/**
	 * @brief 对于menu列表未定义的进行映射别名操作 key => 当前URL地址 ， value => 替换的URL地址
	 */
	private static $menu_non_display = array(
		'/system/navigation' => '/system/default',
		'/system/navigation_edit' => '/system/default',
		'/system/navigation_recycle' => '/system/default',
		'/system/delivery_edit' => '/system/delivery',
		'/system/delivery_recycle' => '/system/delivery',

		'/member/recycling' => '/member/member_list',

		'/tools/article_edit_act'=>'/tools/article_list',

		'/market/ticket_edit' => '/market/ticket_list',
		'/market/bill_edit' => '/market/bill_list',

		'/order/collection_show' => '/order/order_collection_list',
		'/order/refundment_show' => '/order/order_refundment_list',
		'/order/delivery_show' => '/order/order_delivery_list',
		'/order/refundment_doc_show' => '/order/refundment_list',
		'/order/print_template' => '/order/order_list',
		'/order/collection_recycle_list' => '/order/order_collection_list',
		'/order/delivery_recycle_list' => '/order/order_delivery_list',
		'/order/recycle_list'	=>	'/order/ship_info_list',
		'/order/expresswaybill_edit' => '/order/order_list',
		'/order/order_show' => '/order/order_list',
	);

    /**
     * @brief 根据用户的权限过滤菜单
     * @return array
     */
    private function filterMenu()
    {
    	$rights = ISession::get('admin_right');

    	$role=ISafe::get('role_id');

		//如果不是超级管理员则要过滤菜单
		//if($rights != 'administrator')
		if($role != 0)
		{
			foreach(self::$menu as $firstKey => $firstVal)
			{
				if(is_array($firstVal))
				{
					foreach($firstVal as $secondKey => $secondVal)
					{
						if(is_array($secondVal))
						{
							foreach($secondVal as $thirdKey => $thirdVal)
							{
								if(!in_array($thirdKey,self::$commonMenu) && (stripos(str_replace('@','/',$rights),','.substr($thirdKey,1).',') === false))
								{
									unset(self::$menu[$firstKey][$secondKey][$thirdKey]);
								}
							}
							if(empty(self::$menu[$firstKey][$secondKey]))
							{
								unset(self::$menu[$firstKey][$secondKey]);
							}
						}
					}
					if(empty(self::$menu[$firstKey]))
					{
						unset(self::$menu[$firstKey]);
					}
				}
			}
		}
    }

    /**
     * @brief 取得当前菜单应该生成的对应JSON数据
     * @param boolean $is_auto 是否智能匹配菜单
     * @return Json
     */
	public function submenu($is_auto = false)
	{
		$result     = array();
		$controller = IWeb::$app->getController()->getId();
		$action     = IWeb::$app->getController()->getAction()->getId();

		//当前菜单无定义时做映射别名
		$this->current = '/'.$controller.'/'.$action;
		if(isset(self::$menu_non_display[$this->current]))
		{
			$this->current = self::$menu_non_display[$this->current];
		}
		else
		{
			$actionArray = explode("_",$action);
			$model = current($actionArray);
		}

		$find_current = false;

		//过滤无操作权限的菜单
		$this->filterMenu();

		foreach(self::$menu as $key => $value)
		{
			$item = array();
			$item['current'] = false;
			$item['title']   = $key;

			foreach($value as $big_cat_name => $big_cat)
			{
				foreach($big_cat as $link => $title)
				{
					//把菜单的第一连接项分给顶级菜单
					if(!isset($item['link']))
					{
						$item['link'] = $link;
					}

					if($find_current)
					{
						break;
					}

					//遍历菜单项找到与当前连接相同的项目
					if( $link == $this->current || ($is_auto == true && isset($model) && preg_match("!^/[^/]+/{$model}_!",$link) ) )
					{
						$item['current'] = $find_current = true;
						foreach($value as $k => $v)
						{
							foreach($v as $subMenuKey => $subMenuName)
							{
								$tmpUrl = IUrl::creatUrl($subMenuKey);
								unset($value[$k][$subMenuKey]);
								$value[$k][$tmpUrl]['name'] = $subMenuName;
								$value[$k][$tmpUrl]['urlPathinfo'] = $subMenuKey;
							}
						}
						$item['list'] = $value;
					}
				}

				if($find_current)
				{
					break;
				}
			}
			$item['link'] = IUrl::creatUrl($item['link']);
			$result[] = $item;
		}

		if($find_current == false && $is_auto == false)
		{
			return $this->submenu(true);
		}

		return JSON::encode($result);
	}
}