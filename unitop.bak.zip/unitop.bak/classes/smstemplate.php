<?php
/**
 * @copyright (c) 2011 aircheng.com
 * @file smstemplate.php
 * @brief 短信发送模板
 * @author chendeshan
 * @date 2014/8/11 9:51:51
 * @version 2.9
 */

 /**
 * @class smsTemplate
 * @brief 短信发送模板
 */
class smsTemplate 
{
	public $sms_header='【youlida】';



	public static function seller_confirm_order_by_mobile($data){

		$templateString = "【youlida】unitop.com.ph:dear".$data['username'].",your order:".$data['order_no']." has returned to the present ".$data['amount'].'PHP';

		return $templateString;		
	}
	public static function recharge_by_mobile($data){

		$templateString = "【youlida】unitop.com.ph:dear".$data['username'].",Administrator recharge ".$data['amount'].' PHP for your account ';

		return $templateString;		
	}
	public static function order_by_mobile($data){

		$templateString = "【youlida】unitop.com.ph:dear".$data['username'].",You consumed  ".$data['amount'].' PHP ,order No.:'.$data['order_no'];

		return $templateString;		
	}
	public static function refund_by_mobile($data){

		$templateString = "【youlida】unitop.com.ph:dear".$data['username'].",You got a  ".$data['amount'].' PHP refund,order No.:'.$data['order_no'];

		return $templateString;		
	}		
	/**
	 * @brief 订单发货的信息模板
	 * @param array $data 替换的数据
	 */
	public static function sendGoods($data = null)
	{
		$templateString = "hello{user_name},order No.:{order_no},diliver by {sendor},logistics company:{delivery_company},Number of logistics:{delivery_no}";
		return strtr($templateString,$data);
	}

	/**
	 * @brief 手机找回密码模板
	 * @param array $data 替换的数据
	 */
	public static function findPassword($data = null)
	{
		$templateString = "Your verification code is:{mobile_code},Please pay attention to the custody!";
		return strtr($templateString,$data);
	}

	/**
	 * @brief 手机短信校验码
	 * @param array $data 替换的数据
	 */
	public static function checkCode($data = null)
	{
		$templateString = "Your verification code is:{mobile_code},Please pay attention to the custody!";
		return strtr($templateString,$data);
	}

	/**
	 * @brief 自提点确认短信
	 * @param array $data 替换的数据
	 */
	public static function takeself($data = null)
	{
		$templateString = "Your order number:{orderNo},{name}Self address:{address},Receive verification code:{mobile_code},Please receive as soon as possible";
		return strtr($templateString,$data);
	}

	/**
	 * @brief 商户注册提示管理员
	 * @param array $data 替换的数据
	 */
	public static function sellerReg($data = null)
	{
		$templateString = "{true_name},Application to join the platform, please log in the background as soon as possible to deal with";
		return strtr($templateString,$data);
	}

	/**
	 * @brief 商户处理结果
	 * @param array $data 替换的数据
	 */
	public static function sellerCheck($data = null)
	{
		$templateString = "Your franchisee status has been modified to:{result},Please log in to view the details of your business background";
		return strtr($templateString,$data);
	}

	/**
	 * @brief 订单付款通知管理员
	 */
	public static function payFinishToAdmin($data = null)
	{
		$templateString = "Order:{orderNo},Has been paid, please log in the background as soon as possible to deal with";
		return strtr($templateString,$data);
	}

	/**
	 * @brief 订单付款通知管理员
	 */
	public static function payFinishToUser($data = null)
	{
		$templateString = "Order:{orderNo},The payment has been made, we will serve you as soon as possible.";
		return strtr($templateString,$data);
	}
}