<?php

  header("content-type:text/html;charset=utf-8");
  ini_set("magic_quotes_runtime",0);

  if (!defined('PHPMAIL')) {
      define('PHPMAIL', dirname(__FILE__) . '/');
      require(PHPMAIL . 'phpmail/class.phpmailer.php');
  }
  class phpmail{

      private $host;
      private $username;
      private $pwd;
      private $from;
      private $fromName;
      private $header='UNITOP Online Shopping Mall';

      public function __construct($host,$username,$pwd,$from,$fromName){
          $this->host=$host;
          $this->username=$username;
          $this->pwd=$pwd;
          $this->from=$from;
          $this->fromName=$fromName;
        
      }
      public function sendStr($info,$type='1'){
        $result=array();
        switch ($type) {
          case '1'://注册成功
            $title='Welcome to '.$this->header;
            $content="Hello ".$info.",thanks for joining our UNITOP Online Shopping Mall membership! Now you get to shop at http://www.unitop.com.ph, and enjoy our exclusive members-only offers.";          
            break;
           case '2'://订单消费
            $title='Balance change:'.$this->header;
            $content="dear ".$info['name'].",You consumed ".$info['money']." PHP,you can visit our website http://www.unitop.com.ph to learn more";
            break;
           case '3'://充值扣费
            $title='Balance change:'.$this->header;
            $content="dear ".$info['name'].",unitop recharge ".$info['money']." PHP for you,you can visit our website http://www.unitop.com.ph to learn more";
            break;
           case '4'://订单退款
            $title='Balance change:'.$this->header;
            $content="dear ".$info['name'].",uYou got a ".$info['money']." PHP refund,you can visit our website http://www.unitop.com.ph to learn more";
            break;                                     
          default:
            $title='welcome to '.$this->header;
            $content="dear ".$info.",thanks for you register unitop,you can visit our website http://www.unitop.com.ph";
            break;
        }
        $result['title']=$title;
        $result['content']=$content;
        return $result;
      }
      public function send($title,$to,$content){
        
          
          try {
            $mail = new PHPMailer(true); 
            $mail->IsSMTP();
            $mail->CharSet='UTF-8'; //设置邮件的字符编码，这很重要，不然中文乱码
            $mail->SMTPAuth   = true;                  //开启认证
            $mail->Port       = 25;                    
            
            $mail->Host       = $this->host;//"smtp.qiye.163.com"; 
            $mail->Username   = $this->username;//"admin@wagsc.com";    
            $mail->Password   = $this->pwd;//"Liu222222";            
            //$mail->IsSendmail(); //如果没有sendmail组件就注释掉，否则出现“Could  not execute: /var/qmail/bin/sendmail ”的错误提示
            $mail->AddReplyTo($this->from,"mckee");//回复地址
            $mail->From       = $this->from;//"admin@wagsc.com";



            $mail->FromName   = $this->fromName;//"帅的被人砍2";
            //$to = "3427652472@qq.com";
            //$to="leonard.sean47@gmail.com";
            $to=$to;
            $mail->AddAddress($to);
            $mail->Subject  = $title;//"phpmailer测试标题";
            $mail->Body = $content;
            //"<h1>phpmail演示</h1>这是php点点通（<font color=red>www.phpddt.com</font>）对phpmailer的测试内容";
            $mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; //当邮件不支持html时备用显示，可以省略
            $mail->WordWrap   = 80; // 设置每行字符串的长度
            //$mail->AddAttachment("f:/test.png");  //可以添加附件
            $mail->IsHTML(true); 
            $mail->Send();
            //echo '邮件已发送';
            return true;
          } catch (phpmailerException $e) {
            return false;//$e->errorMessage();
            //echo "邮件发送失败：".$e->errorMessage();
          }
               
      }   
  }