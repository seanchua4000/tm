<?php
/**
 * @copyright (c) 2014 aircheng
 * @file report.php
 * @brief 导出excel类库
 * @author dabao
 * @date 2014/11/28 22:09:43
 * @version 1.0.0
 */

class report
{
	//文件名
	private $fileName = 'user';
	
	public function setFileName($fileName)
	{
		$this->fileName = $fileName;
	}
	//开始下载
	
	public function toDownload ($strTable)
	{	
		header("Content-type: application/vnd.ms-excel");
		header("Content-Type: application/force-download");
		header("Content-Disposition: attachment; filename=".$this->fileName."_".date('Y-m-d').".xls");
		header('Expires:0');
		header('Pragma:public');
		$header='<html xmlns:o="urn:schemas-microsoft-com:office:office" 
					 xmlns:x="urn:schemas-microsoft-com:office:excel" 
					 xmlns="http://www.w3.org/TR/REC-html40"> 
					 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
					 <html> 
				     <head> 
				        <meta http-equiv="Content-type" content="text/html;charset=UTF-8" /> 
				         <style id="Classeur1_16681_Styles"></style> 
				     </head> 
					     <body> 
					    <div id="Classeur1_16681" align=center x:publishsource="Excel"> ';
		$foot='</div> 
			     </body> 
			 </html>';			    
		echo $header.$strTable.$foot;
	}
	
	public function toDownload_new($data,$letter,$tableheader){
		/**
		$excel = new PHPExcel();

		//填充表头信息
		for($i = 0;$i < count($tableheader);$i++) {
			$excel->getActiveSheet()->setCellValue("$letter[$i]1","$tableheader[$i]");
		}
		//填充表格信息
		for ($i = 2;$i <= count($data) + 1;$i++) {
			$j = 0;
			foreach ($data[$i - 2] as $key=>$value) {
				$excel->getActiveSheet()->setCellValue("$letter[$j]$i","$value");
				$j++;
			}
		}

		*/
		$excel = new PHPExcel();



		/**
		//填充表格信息
		for ($i = 2;$i <= count($data) + 1;$i++) {
			$j = 0;
			foreach ($data as $key=>$value) {
				$excel->getActiveSheet()->setCellValue($letter[$j]$i,$value);
				$j++;
			}
		}
		*/
		for($i=0;$i<count($tableheader);$i++){
			$str=$letter[$i];
			$str.='1';
			$excel->getActiveSheet()->setCellValue($str,$tableheader[$i]);
		}
		for($l=0;$l<count($data);$l++){
			//$k=$l+1;
			$excel->getActiveSheet()->getRowDimension($l)->setRowHeight(40);
			//$excel->getActiveSheet()->getRowDimension($k)->setRowWidth(120);						
			$k=$l+2;
			for($i=0;$i<count($tableheader);$i++){
				$nstr=$str=$letter[$i];
				$str.=$k;
				if($i==0){//图片
					//$excel->getActiveSheet()->getColumnDimension($nstr)->setWidth(40);

					$objDrawing = new PHPExcel_Worksheet_Drawing();
					/*设置图片路径 切记：只能是本地图片*/
					$objDrawing->setPath($data[$l][$i]);
					/*设置图片高度*/
					$objDrawing->setHeight(20);
					$objDrawing->setWidth(20);
					/*设置图片要插入的单元格*/
					$objDrawing->setCoordinates($str);
					/*设置图片所在单元格的格式*/
					//$objDrawing->setOffsetX(80);
					//$objDrawing->setRotation(20);
					//$objDrawing->getShadow()->setVisible(true);
					//$objDrawing->getShadow()->setDirection(50);
					$objDrawing->setWorksheet($excel->getActiveSheet());

				}else{
					$excel->getActiveSheet()->setCellValue($str,$data[$l][$i]);					
				}
				

			}				
		}

								
		$write = new PHPExcel_Writer_Excel5($excel);
		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control:must-revalidate, post-check=0, pre-check=0");
		header("Content-Type:application/force-download");
		header("Content-Type:application/vnd.ms-execl");
		header("Content-Type:application/octet-stream");
		header("Content-Type:application/download");;
		header('Content-Disposition:attachment;filename="'.$this->fileName."_".date('Y-m-d').".xls".'"');
		header("Content-Transfer-Encoding:binary");
		$write->save('php://output');						
	}

	public function excel_read($filePath){
		$excel = new PHPExcel();
		//$write = new PHPExcel_Reader_Excel5($excel);
		$PHPReader = new PHPExcel_Reader_Excel2007(); 
		if(!$PHPReader->canRead($filePath)){ 
			$PHPReader = new PHPExcel_Reader_Excel5(); 
			if(!$PHPReader->canRead($filePath)){ 
				echo 'no Excel'; 
				return ; 
			} 
		} 
		$PHPExcel = $PHPReader->load($filePath); 
		/**读取excel文件中的第一个工作表*/ 
		$currentSheet = $PHPExcel->getSheet(0); 
		/**取得最大的列号*/ 
		$allColumn = $currentSheet->getHighestColumn(); 
		/**取得一共有多少行*/ 
		$allRow = $currentSheet->getHighestRow(); 
		/**从第二行开始输出，因为excel表中第一行为列名*/ 
		/**从第二行开始输出，因为excel表中第一行为列名*/
		$goods_data=array(); 
		for($currentRow = 2;$currentRow <= $allRow;$currentRow++){ 
			$goods_no=array();
			/**从第A列开始输出*/ 
			for($currentColumn= 'A';$currentColumn<= $allColumn; $currentColumn++){ 
				
				$val = $currentSheet->getCellByColumnAndRow(ord($currentColumn) - 65,$currentRow)->getValue();/**ord()将字符转为十进制数*/ 
				if($currentColumn == 'A') 
				{ 
					$goods_no['name']=iconv('utf-8','gb2312', $val); 
				}else if($currentColumn == 'B'){ 
					//echo $val; 
					/**如果输出汉字有乱码，则需将输出内容用iconv函数进行编码转换，如下将gb2312编码转为utf-8编码输出*/ 
					$goods_no['goods_no']=iconv('utf-8','gb2312', $val); 
				} 
			} 
			if($goods_no){
				$goods_data[$goods_no['goods_no']]=$goods_no;
			}
		}
		return $goods_data;				
	}
}
?>