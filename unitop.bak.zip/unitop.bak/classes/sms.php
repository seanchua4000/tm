<?php
/**
 * @copyright (c) 2011 jooyea
 * @file seo.php
 * @brief seo处理
 * @author wula
 * @date 2011-6-15 14:58:39
 * @version 0.6
 */
class Sms
{
	
	private $alikey='';

	function __construct($alikey)
	{
		$this->alikey=$alikey;
	}

	function send_mobile($data){
		$mobile=$data['mobile'];
		$text=$data['text'];
		if ($mobile && (strlen($mobile) >10 || strlen($mobile)==10)){
			$code = $this->new_entinfo_send('+63'.$mobile,$text);
			//$code = $this->new_entinfo_send($mobile,$text);
			if ($code==0){
				$message['error'] 	= 0;
				$message['message'] = 'Send success';
			}elseif ($code == '-1'){
				$message['error'] 	= 1;
				$message['message'] = 'fail in send';
			}else{
				$message['error'] 	= 1;
				$message['message'] = 'Send exception';
			}
		}else{
			$message['error'] 	= 1;
			$message['message'] = 'Cell phone number format error';
		}
		return json_encode($message);
	}    
	//最新发送短信接口
	public function new_entinfo_send($mobile,$text){
		try {
			if ($mobile){
				$code	 = '';
					
				$apikey = $this->alikey;
				//$text="【youlida】Your verification code is".$code;
				$ch = curl_init();				

				curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept:text/plain;charset=utf-8', 'Content-Type:application/x-www-form-urlencoded','charset=utf-8'));
				/* 设置返回结果为流 */
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				/* 设置超时时间*/
				curl_setopt($ch, CURLOPT_TIMEOUT, 10);
				/* 设置通信方式 */
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				// 取得用户信息
				$json_data = $this->get_user($ch,$apikey);
				$array = json_decode($json_data,true);
				// 发送短信
				$data=array('text'=>$text,'apikey'=>$apikey,'mobile'=>$mobile);
				$json_data = $this->send($ch,$data);

				$array = json_decode($json_data,true);
				
				curl_close($ch);
				//发送短信结束
				$smsid = $array['msg'] ? $array['msg'] : $array['detail'];

				return 0;

				/**
				
				if ($smsid){
					$addtime = time();
					if ($smsid=='OK'){
						$vmmobileDB  = new IModel("vmmobile");
						$vmmobileDB->setData(array("mobile" => $mobile,"code"=>$code,'message'=>$text,'status'=>1,'type'=>$type,'smsid'=>$smsid,'addtime'=>$addtime));
						$vmmobileDB->add();
						return 0;
					}else{
						$vmmobileDB  = new IModel("vmmobile");
						$vmmobileDB->setData(array("mobile" => $mobile,"code"=>$code,'message'=>$text,'status'=>4,'type'=>$type,'smsid'=>$smsid,'addtime'=>$addtime));
						$vmmobileDB->add();
						return '-1';
					}
				}else{
					return '-1';exit();
				}
				*/
				
			}else{
				return 'error';//exit();
			}
		}catch (Examine $e){
			return $e->getMessage();//exit();
		}
	}	
	
	/***************************************************************************************/
	//获得账户
	function get_user($ch,$apikey){
	    curl_setopt ($ch, CURLOPT_URL, 'https://sms.yunpian.com/v1/user/get.json');
	    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(array('apikey' => $apikey)));
	    return curl_exec($ch);
	}
	function send($ch,$data){
	    curl_setopt ($ch, CURLOPT_URL, 'https://sms.yunpian.com/v1/sms/send.json');
	    curl_setopt($ch, CURLOPT_POSTFIELDS, str_replace('&amp;','&',http_build_query($data)));
	    return curl_exec($ch);
	}	
	
}