<?php
/**
 * @copyright (c) 2011 jooyea.cn
 * @file notice.php
 * @brief 用户中心api方法
 * @author chendeshan
 * @date 2014/10/12 13:59:44
 * @version 2.7
 */
class APIUcenter
{

	///用户中心-账户余额
	public function getUcenterAccoutLog($userid)
	{
		$page = IReq::get('page') ? IFilter::act(IReq::get('page'),'int') : 1;
		$query = new IQuery('account_log');
		$query->where="user_id = ".$userid;
		$query->order = 'id desc';
		$query->page  = $page;
		return $query;
	}
	//用户中心-我的建议
	public function getUcenterSuggestion($userid)
	{
		$page = IReq::get('page') ? IFilter::act(IReq::get('page'),'int') : 1;
		$query = new IQuery('suggestion');
		$query->where="user_id = ".$userid;
		$query->page  = $page;
		$query->order = 'id desc';
		return $query;
	}
	//用户中心-商品讨论
	public function getUcenterConsult($userid)
	{
		$page = IReq::get('page') ? IFilter::act(IReq::get('page'),'int') : 1;
		$query = new IQuery('refer as r');
		$query->join   = "join goods as go on r.goods_id = go.id ";
		$query->where  = "r.user_id =". $userid;
		$query->fields = "time,name,question,status,answer,admin_id,go.id as gid";
		$query->page   = $page;
		$query->order = 'r.id desc';
		return $query;
	}
	//用户中心-商品评价
	public function getUcenterEvaluation($userid,$status = '')
	{
		$page = IReq::get('page') ? IFilter::act(IReq::get('page'),'int') : 1;
		$query = new IQuery('comment as c');
		$query->join   = "left join goods as go on c.goods_id = go.id ";
		$query->where  = ($status === '') ? "c.user_id = ".$userid : "c.user_id = ".$userid." and c.status = ".$status;
		$query->fields = "order_no,go.sell_price,go.img,go.name,c.time,c.id,c.goods_id,c.contents,c.status";
		$query->page   = $page;
		$query->order = 'c.id desc';
		return $query;
	}

	//用户中心-用户信息
	public function getMemberInfo($userid){
		$tb_member = new IModel('member');
		$info = $tb_member->getObj("user_id=".$userid);
		return $info;
	}
	//用户中心-个人主页统计
	public function getMemberTongJi($userid){
		$query = new IQuery('order');
		$query->fields = "sum(order_amount) as amount,count(id) as num";
		$query->where  = "user_id = ".$userid." and pay_status = 1 and if_del = 0";
		$info = $query->find();
		return $info[0];
	}
	//用户中心-个人主页统计
	public function getPropTongJi($propIds){
		$query = new IQuery('prop');
		$query->fields = "count(id) as prop_num";
		$query->where  = "id in (".$propIds.") and type = 0";
		$info = $query->find();
		return $info[0];
	}
	//用户中心-积分列表
	public function getUcenterPointLog($userid,$c_datetime)
	{
		$page = IReq::get('page') ? IFilter::act(IReq::get('page'),'int') : 1;
		$query = new IQuery('point_log');
		$query->where  = "user_id = ".$userid." and ".$c_datetime;
		$query->page   = $page;
		$query->order= "id desc";
		return $query;
	}
	//用户中心-网币列表
	public function getUcenterNetcoinLog($userid)
	{
		$page = IReq::get('page') ? IFilter::act(IReq::get('page'),'int') : 1;
		$query = new IQuery('netcoin_log');
		$query->where  = "user_id = ".$userid;
		$query->page   = $page;
		$query->pagesize = 10;
		$query->order= "id desc";
		return $query;
	}	
	//用户中心-信息列表
	public function getUcenterMessageList($msgIds){
		$page = IReq::get('page') ? IFilter::act(IReq::get('page'),'int') : 1;
		$query = new IQuery('message');
		$query->where= "id in(".$msgIds.")";
		$query->order= "id desc";
		$query->page = $page;
		return $query;
	}
	//用户中心-订单列表
	public function getOrderList($userid){
		$page = IReq::get('page') ? IFilter::act(IReq::get('page'),'int') : 1;
		$query = new IQuery('order');
		$query->where = "user_id =".$userid." and if_del= 0";
		$query->order = "id desc";
		$query->page  = $page;
		return $query;
	}
	//用户中心-订单列表(已付款/申请售后用)
	public function getOrderList2($userid){
		$page = IReq::get('page') ? IFilter::act(IReq::get('page'),'int') : 1;
		$query = new IQuery('order');
		$query->where = "user_id =".$userid." and if_del= 0 and pay_status =1 and status <> 6";
		$query->order = "id desc";
		$query->page  = $page;
		return $query;
	}	
	//用户中心-订单列表(退款处理中/已处理)//2015/12/7
	public function getOrderList3($userid){
		$page = IReq::get('page') ? IFilter::act(IReq::get('page'),'int') : 1;
		$query = new IQuery('order_goods as a left join iwebshop_refundment_doc as b on a.goods_id = b.goods_id');
		$query->where = ("user_id =".$userid." and b.if_del= 0 and a.goods_id = b.goods_id and a.order_id = b.order_id");
		$query->order = "b.time desc";
		$query->pagesize = 10;
		$query->page  = $page;
		return $query;
	}		
	//用户中心-我的优惠券
	public function getPropList($ids,$status){
		$page = IReq::get('page') ? IFilter::act(IReq::get('page'),'int') : 1;
		$status = IFilter::act($status,'int');
		
		$query = new IQuery('prop');
		//未使用
		if($status === 0)
		{
			$query->where  = "id in(".$ids.") and is_send = 1 and is_userd = 0";
		//已使用	
		}elseif($status === 1){
			
			$query->where  = "id in(".$ids.") and is_send = 1 and is_userd = 1";
		//已过期
		}elseif($status === 2){
			
			$query->where  = "id in(".$ids.") and is_send = 1 and NOW() not between start_time and end_time";
			
		}
		else{
			$query->where  = "id in(".$ids.") and is_send = 1";
		}
		
		$query->page   = $page;
		return $query;
	}
	
	//用户中心-优惠劵数量
	public function getPropListNum($ids,$status){
		$page = IReq::get('page') ? IFilter::act(IReq::get('page'),'int') : 1;
		$getPropListNumobj = new IModel('prop');

		//未使用
		if($status === 0){
			$result = $getPropListNumobj->query("id in(".$ids.") and is_send = 1 and is_userd = 0");
			$count = count($result);
		}
		
		//已使用
		if($status === 1){
			$result = $getPropListNumobj->query("id in(".$ids.") and is_send = 1 and is_userd = 1");
			$count = count($result);
		}	
		
		//已过期
		if($status === 2){
			$result = $getPropListNumobj->query("id in(".$ids.") and is_send = 1 and NOW() not between start_time and end_time");
			$count = count($result);
		}	
		
		return $count;
	}	
	//用户中心-退款记录
	public function getRefundmentDocList($userid){
		$page = IReq::get('page') ? IFilter::act(IReq::get('page'),'int') : 1;
		$query = new IQuery('refundment_doc');
		$query->where = "user_id = ".$userid;
		$query->order = "id desc";
		$query->page  = $page;
		return $query;
	}
	//用户中心-提现记录
	public function getWithdrawList($userid){
		$page = IReq::get('page') ? IFilter::act(IReq::get('page'),'int') : 1;
		$query = new IQuery('withdraw');
		$query->where = "user_id = ".$userid." and is_del = 0";
		$query->order = "id desc";
		$query->page  = $page;
		return $query;
	}
	//根据单号获取该商品详细信息
	public function getOrderdetail($order_no){
		$obj = new IModel('order as a left join iwebshop_order_goods as b on a.id = b.id');
		$arr = $obj->getObj("order_no = $order_no");
		$goods_id = $arr['goods_id'];
		
		$goodsObj = new IModel('goods');
		$goodsArr = $goodsObj->getObj("id = $goods_id");
		
		return $goodsArr;
	}
	//用户中心-根据订单id获取该订单下的所有商品//2015/12/7
	public function getGoodslistByOrderid($order_id){
		$obj = new IModel('order as a left join iwebshop_order_goods as b on a.id = b.order_id');
		$arr = $obj->query("order_id = $order_id");
		return $arr;
	}



}