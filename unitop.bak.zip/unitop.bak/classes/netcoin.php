<?php
/**
 * @copyright (c) 2011 [group]
 * @file pointlog.php
 * @brief 积分日志记录处理类
 * @author chendeshan
 * @date 2011-6-15 14:58:39
 * @version 0.6
 */
class Netcoin
{
	//错误信息
	private $error  = '';

	/**
	 * @brief 网币操作的构造函数
	 * @param array $config => array('user_id' => 用户ID , 'netcoin' => 积分增减(正，负区分) , 'log' => 日志记录内容)
	 */
	public function update($config)
	{
		if(!isset($config['user_id']) || intval($config['user_id']) <= 0)
		{
			$this->error = 'User ID cannot be empty';
		}
		else if(!isset($config['netcoin']) || intval($config['netcoin']) == 0)
		{
			$this->error = 'Net currency format is not correct';
		}
		else if(!isset($config['log']))
		{
			$this->error = 'Net currency log is not correct';
		}
		else
		{
			$is_success = $this->editNetcoin($config['user_id'],$config['netcoin']);
			if($is_success)
			{
				if(!$this->writeLog($config))
				{
					$this->error = 'Log log failed';
				}
			}
			else
			{
				$this->error = 'Net currency update failed';
			}
		}

		return $this->error == '' ? true:false;
	}

	//返回错误信息
	public function getError()
	{
		return $this->error;
	}

	/**
	 * @brief 日志记录
	 * @param array $config => array('user_id' => 用户ID , 'point' => 网币增减(正，负区分) , 'log' => 日志记录内容)
	 */
	private function writeLog($config)
	{
		//修改pointLog表
		$poinLogObj    = new IModel('netcoin_log');
		$pointLogArray = array(
			'user_id' => $config['user_id'],
			'datetime'=> ITime::getDateTime(),
			'value'   => $config['netcoin'],
			'intro'   => $config['log'],
			'order_no'   => $config['order_no'],
		);
		$poinLogObj->setData($pointLogArray);
		return $poinLogObj->add();
	}

	/**
	 * @brief 网币更新
	 * @param int $user_id 用户ID
	 * @param int $point   积分数(正，负)
	 */
	private function editNetcoin($user_id,$netcoin)
	{
		$memberObj   = new IModel('member');
		$memberArray = array('netcoin' => 'netcoin + '.$netcoin);
		$memberObj->setData($memberArray);
		return $memberObj->update('user_id = '.$user_id,'netcoin');
	}

}