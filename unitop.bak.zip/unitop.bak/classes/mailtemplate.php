<?php
/**
 * @copyright (c) 2014 aircheng.com
 * @file sendmail.php
 * @brief 邮件数据模板
 * @author chendeshan
 * @date 2014/11/28 23:20:51
 * @version 2.9
 */
class mailTemplate
{
	/**
	 * @brief 找回密码模板
	 * @param array $param 模版参数
	 * @return string
	 */
	public static function findPassword($param)
	{
		$siteConfig = new Config("site_config");
		$templateString = "Hello, you are in{$siteConfig->name}To retrieve the password for the operation, click on the link below to reset the password：<a href='{url}'>{url}</a>。<br />If you can't click, please copy it to the address bar to open。";
		return strtr($templateString,$param);
	}

	/**
	 * @brief 验证邮件模板
	 * @param array $param 模版参数
	 * @return string
	 */
	public static function checkMail($param)
	{
		$siteConfig = new Config("site_config");
		$templateString = "Thank you for registering{$siteConfig->name}Service, click the link below to verify and activate your account.：<a href='{url}'>{url}</a>。<br />If you can't click, please copy it to the address bar to open。";
		return strtr($templateString,$param);
	}

	/**
	 * @brief 验证邮件模板
	 * @param array $param 模版参数
	 * @return string
	 */
	public static function notify($param)
	{
		$templateString = "Dear users, you need to buy<{goodsName}> It is now fully available to buy! <a href='{url}' target='_blank'>Buy</a>";
		return strtr($templateString,$param);
	}
}
