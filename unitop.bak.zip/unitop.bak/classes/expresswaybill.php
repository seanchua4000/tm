<?php
/**
 * @copyright (c) 2011 [group]
 * @file expresswaybill.php
 * @brief 快递单处理类
 * @author chendeshan
 * @date 2011-6-15 14:58:39
 * @version 0.6
 */
class Expresswaybill
{
	public static $itemData = array(
		'ship_name'=>'Consignee name',
		'ship_area_0'=>'Consignee - area 1',
		'ship_area_1'=>'Consignee - area 2',
		'ship_area_2'=>'Consignee - area 3',
		'ship_addr'=>'Consignee address',
		'ship_tel'=>'Consignee - Telephone',
		'ship_mobile'=>'Consignee - mobile phone',
		'ship_zip'=>'Zip - consignee',
		'ship_detail_addr'=>'Consignee - area + address in detail',
		'dly_name'=>'Shipper name',
		'dly_area_0'=>'Shipper - area 1',
		'dly_area_1'=>'Shipper - area 2',
		'dly_area_2'=>'Shipper - area 3',
		'dly_address'=>'Shipper address',
		'dly_tel'=>'Shipper - Telephone',
		'dly_mobile'=>'Shipper - Mobile',
		'dly_zip'=>'Shipper - zip',
		'date_y'=>'Current date - year',
		'date_m'=>'Current date - month',
		'date_d'=>'Current date - day',
		'order_id'=>'Order - Order No.',
		'order_price'=>'Total order amount',
		'order_weight'=>'Total weight of order goods',
		'order_count'=>'Order quantity',
		'order_memo'=>'Order - Notes',
		'ship_time'=>'Order delivery time',
		'shop_name'=>'Shop name',
		'tick'=>'√ - Right',
	);

	//数据转换
	public function conver($expressConfig,$order_id)
	{
		$resultArray = array(); //函数返回数据
		$wholeData   = array(); //实际的数据

		//获取订单信息
		$id       = intval($order_id);
		$orderObj = new IModel('order');
		$orderRow = $orderObj->getObj('id = '.$id);

		if(empty($orderRow))
		{
			return null;
		}

		//获取发货地址信息
		$shipInfoObj = new IModel('merch_ship_info');
		$shipList    = $shipInfoObj->query('is_del = 1','*','is_default','desc','1');
		if(empty($shipList))
		{
			$shipRow = array('ship_user_name'=>'','address'=>'','telphone'=>'','mobile'=>'','postcode'=>'','province' => '','city'=>'','area'=>'');
		}
		else
		{
			$shipRow = $shipList[0];
		}

		//获取订单总重量和总数量
		$orderGoodsObj = new IModel('order_goods');
		$orderTotal    = $orderGoodsObj->getObj('order_id = '.$id,'SUM(goods_nums) as num_total,SUM(goods_weight * goods_nums) as weight_total');


		/*拼接实际数据 $wholeData*/

		//查询area地域数据
		$areaData  = area::name($orderRow['province'],$orderRow['city'],$orderRow['area'],$shipRow['province'],$shipRow['city'],$shipRow['area']);

		//获取site_config配置信息
		$site_config = new Config('site_config');
		$site_config = $site_config->getInfo();

		$wholeData['ship_name']   = $orderRow['accept_name'];
		$wholeData['ship_area_0'] = isset($areaData[$orderRow['province']]) ? $areaData[$orderRow['province']] : '';
		$wholeData['ship_area_1'] = isset($areaData[$orderRow['city']])     ? $areaData[$orderRow['city']]     : '';
		$wholeData['ship_area_2'] = isset($areaData[$orderRow['area']])     ? $areaData[$orderRow['area']]     : '';
		$wholeData['ship_addr']   = $orderRow['address'];
		$wholeData['ship_tel']    = $orderRow['telphone'];
		$wholeData['ship_mobile'] = $orderRow['mobile'];
		$wholeData['ship_zip']    = $orderRow['postcode'];
		$wholeData['ship_detail_addr'] = $wholeData['ship_area_0'].$wholeData['ship_area_1'].$wholeData['ship_area_2'].$orderRow['address'];

		$wholeData['dly_name']    = $shipRow['ship_user_name'];
		$wholeData['dly_area_0']  = isset($areaData[$shipRow['province']]) ? $areaData[$shipRow['province']] : '';
		$wholeData['dly_area_1']  = isset($areaData[$shipRow['city']])     ? $areaData[$shipRow['city']] : '';
		$wholeData['dly_area_2']  = isset($areaData[$shipRow['area']])     ? $areaData[$shipRow['area']] : '';
		$wholeData['dly_address'] = $shipRow['address'];
		$wholeData['dly_tel']     = $shipRow['telphone'];
		$wholeData['dly_mobile']  = $shipRow['mobile'];
		$wholeData['dly_zip']     = $shipRow['postcode'];

		$wholeData['date_y']      = date('Y');
		$wholeData['date_m']      = date('m');
		$wholeData['date_d']      = date('d');

		$wholeData['order_id']    = $orderRow['order_no'];
		$wholeData['order_price'] = $orderRow['order_amount'];
		$wholeData['order_weight'] = isset($orderTotal['weight_total']) ? $orderTotal['weight_total'] : '';
		$wholeData['order_count']  = isset($orderTotal['num_total'])    ? $orderTotal['num_total'] : '';
		$wholeData['order_memo']   = $orderRow['note'];
		$wholeData['ship_time']    = $orderRow['accept_time'];
		$wholeData['shop_name']    = isset($site_config['name']) ? $site_config['name'] : '';
		$wholeData['tick']         = '√';

		//进行数据替换
		foreach($expressConfig as $key => $val)
		{
			$item_tmp             = JSON::decode($val);
			$item_tmp['typeText'] = isset($wholeData[$item_tmp['typeId']]) ? $wholeData[$item_tmp['typeId']] : '';
			$resultArray[]        = JSON::encode($item_tmp);
		}

		return $resultArray;
	}
}
?>