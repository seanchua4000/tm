<?php
/**
 * @copyright Copyright(c) 2011 jooyea.cn
 * @file util.php
 * @brief 公共函数类
 * @author kane
 * @date 2011-01-13
 * @version 0.6
 * @note
 */

 /**
 * @class Util
 * @brief 公共函数类 and iwebshop_ad_manage.order=0
 */
class Commonfunc
{

	
	/*******************site+index************************/
	public static function commend_goods_by_sellerid($seller_id,$type=''){
		$key_name='commend_goods_'.$seller_id;

		$hand=new RedisDemo();
		if($type){
			if($hand->exists($key_name)){
				$hand->destroy($key_name);
			}	
			
			return;
		}

		if($hand->exists($key_name)){
			$result=$hand->get($key_name);
			$result=json_decode($result);
		}else{
			$query = new IQuery('commend_goods as co');
			$query->where='co.commend_id = 3 and go.is_del = 0 AND go.id is not null and go.seller_id='.$seller_id;
			$query->fields='go.img,go.sell_price,go.name,go.id,go.market_price,go.seller_id,co.count_price';
			$query->join='left join goods as go on co.goods_id = go.id';
			$query->limit='10';
			$query->order='sort asc,id desc';			
			$result= $query->find();		
			if($result){
				$hand->set($key_name,json_encode($result));
			}					
		}
		return $result;		
	}
	public static function seller_list($area_id=''){
	
		$key_name='seller_list';

		$hand=new RedisDemo();
		//$hand->destroy($key_name);
		if($hand->exists($key_name)){
			$result=$hand->get($key_name);
			$result=json_decode($result);
		}else{
			$query = new IQuery('seller');
			$query->where="is_del=0 and is_lock=0";
			$query->order='id asc';
			$result= $query->find();		
			if($result){
				$hand->set($key_name,json_encode($result));
			}					
		}
		if($area_id){
			$new_result=array();
			foreach ($result as $key => $value) {
				if($area_id==$value["province"]){
					$new_result=$value;
					break;
				}
			}
			$result=$new_result;
		}
		return $result;		
	
	}
	public static function getCategoryExtendListBycateId($cid,$seller_id,$limit=10){
		$key_name='ad_manage_'.$cid.'_'.$seller_id;

		$hand=new RedisDemo();
		//$hand->destroy($key_name);
		if($hand->exists($key_name)){
			$result=$hand->get($key_name);
			$result=json_decode($result);
		}else{
			$query = new IQuery('category_extend as ca');
			$query->where="ca.category_id =".$cid." and go.is_del = 0 and go.seller_id = ".$seller_id;
			$query->order='go.sort asc,go.id asc';
			$query->join='left join goods as go on go.id = ca.goods_id';
			$query->limit=$limit;
			$result= $query->find();		

			if($result){
				$hand->set($key_name,json_encode($result));
			}					
		}
		return $result;		
	}
	public static function ad_manage($id=0){
		$key_name='ad_manage';

		$hand=new RedisDemo();
		//$hand->destroy($key_name);
		if($hand->exists($key_name)){
			$result=$hand->get($key_name);
			$result=json_decode($result);
		}else{
			$query = new IQuery('ad_manage');
			$query->where="position_id=18";
			$result= $query->find();;		

			if($result){
				$hand->set($key_name,json_encode($result));
			}					
		}
		if($result){
			
				$new_result=array();
				foreach ($result as $key => $value) {
					if((int)$id==$value['order']){
						$new_result[$key]=$value;
					}
				}
				$result=$new_result;

			return $result;
		}		
	}
	public static function getarticleList($limit=10){
		$key_name='articleList';
		$hand=new RedisDemo();
		//$hand->destroy($key_name);
		if($hand->exists($key_name)){
			$result=$hand->get($key_name);
			return json_decode($result);
		}else{
			$query = new IQuery('article');
			$query->where="visibility = 1 and top = 1";
			$query->fields = "title,id,style,color";
			$query->limit  =$limit;
			$query->order  ='sort ASC,id DESC';
			$result= $query->find();			

			if($result){
				$hand->set($key_name,json_encode($result));
				return $result;
			}
					
		}			
	}	
	public static function getAnnouncementList($limit=10){
		$key_name='AnnouncementList';
		$hand=new RedisDemo();
		//$hand->destroy($key_name);
		if($hand->exists($key_name)){
			$result=$hand->get($key_name);
			return json_decode($result);
		}else{
			$query = new IQuery('announcement');
			$query->fields = "*";
			$query->limit  =$limit;
			$query->order  ='id desc';
			$result= $query->find();			

			if($result){
				$hand->set($key_name,json_encode($result));
				return $result;
			}
					
		}			
	}
	public static function getHelpListByCatid($cate_id){
		$key_name='HelpListByCatid_'.$cate_id;
		$hand=new RedisDemo();
		if($hand->exists($key_name)){
			$result=$hand->get($key_name);
			return json_decode($result);
		}else{
			$query = new IQuery('help');
			$query->fields = "*";
			$query->where  = "cat_id = ".$cate_id;
			$query->limit  =5;
			$query->order  ='sort ASC,id desc';
			$result= $query->find();			

			if($result){
				$hand->set($key_name,json_encode($result));
				return $result;
			}
					
		}			
	}
	public static function getHelpCategoryFoot(){
		$key_name='HelpCategoryFoot';
		$hand=new RedisDemo();
		if($hand->exists($key_name)){
			$result=$hand->get($key_name);
			return json_decode($result);
		}else{
			$query = new IQuery('help_category');
			$query->fields = "*";
			$query->where  = "position_foot = 1";
			$query->limit  =5;
			$query->order  ='sort ASC,id desc';
			$result= $query->find();			

			if($result){
				$hand->set($key_name,json_encode($result));
				return $result;
			}
					
		}		
	}
	public static function guidList(){
		
		$key_name='guidList';
		$hand=new RedisDemo();
		if($hand->exists($key_name)){
			$result=$hand->get($key_name);
			return json_decode($result);
		}else{

			
			$obj    = new IModel('guide as g');
			$result = $obj->query('','','g.order','asc',6);
			if($result){
				$hand->set($key_name,json_encode($result));
				return $result;
			}
					
		}
			
	}
	public static function  areaList($area_id=''){
		$key_name=$area_id ? 'area_list_'.$area_id : 'area_list';
		$hand=new RedisDemo();
		//$hand->destroy($key_name);
		if($hand->exists($key_name)){
			$result=$hand->get($key_name);
			return json_decode($result);
		}else{
			$sql=$area_id ? "area_id=".$area_id." and parent_id=0" : "parent_id=0";
			$field=$area_id ? 'area_id' : '*';
			$areaDB    = new IModel('areas');
			$a_id = $areaDB->query($sql,$field,'sort','asc');
			if($a_id){
				$hand->set($key_name,json_encode($a_id));
				return $a_id;
			} 			
		}
	}

	public static function cateList(){
		$key_name='cate_list';
		$hand=new RedisDemo();
		if($hand->exists($key_name)){
			$result=$hand->get($key_name);
			return json_decode($result);
		}else{
			$cateDB    = new IModel('category');
			$cate_first  = $cateDB->query("parent_id=0 and visibility=1",'*','sort','asc');

			foreach ($cate_first as $key => $value) {
				$parent_id=$value['id'];
				$cate_second  = $cateDB->query("parent_id=".$parent_id." and visibility=1",'*','sort','asc');
				if(!empty($cate_second)){

				  foreach ($cate_second as $k => $v) {
				    $three_arr=array();
				    $three_parent_id=$v['id'];
				    $three_arr= $cateDB->query("parent_id=".$three_parent_id." and visibility=1",'*','sort','asc');
				    if(empty($three_arr)){
				      $cate_first[$key]['second_no'][]=$v;//放为空的二级
				    }else{
				      $v['children']=$three_arr;
				      $cate_first[$key]['second_yes'][]=$v;         
				    }
				  }     
				}
			}	
			if($cate_first){
				$hand->set($key_name,json_encode($cate_first));
				return $cate_first;
			} 			
		}		
	
	}
	/**********************公共函数*****************************/
	public  static function  goods_list_by_seller($seller,$where='',$page=1,$category='',$type_s=''){
		$query = new IQuery('goods as go');
		$query->fields = "distinct go.id, go.*";
		$query->where  = "go.seller_id = ".$seller." and go.is_del != 1 ".$where;
		if($category){
			$join .= "left join category_extend as co on co.goods_id = go.id ";
		}
		if($type_s){
			$join .=" left join commend_goods as toe on  toe.goods_id = go.id";
		}
		if($join)
			$query->join=$join;  

		$query->order  ="go.id desc";
		$query->page  =$page;
		$result= $query->find();
		$data['info']=$result;
		$data['page']=$query->getPageBar();
		return $data;			
	}

	public static function goods_real_price($goods_id){
		$query = new IQuery('commend_goods as co');
		$query->where='co.goods_id='.$goods_id;
		$query->fields='co.id,co.count_price';		
		$result= $query->find();
		return $result;			
	} 


	public static function inject_check($Sql_Str) {//自动过滤Sql的注入语句。
	    $check=preg_match('/select|insert|update|delete|\'|\\*|\*|\.\.\/|\.\/
	    	|union|into|load_file|outfile/i',$Sql_Str);
	    if ($check){
	        exit();
	    }else{
	        return $Sql_Str;
	    }
	}
	public static function get_real_ip(){  
		$ip=FALSE;  
		if(!empty($_SERVER["HTTP_CLIENT_IP"])){  
			$ip = $_SERVER["HTTP_CLIENT_IP"];  
		}  
		if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
			$ips = explode (", ", $_SERVER['HTTP_X_FORWARDED_FOR']);  
			if ($ip) { array_unshift($ips, $ip); $ip = FALSE; }  
				for ($i = 0; $i < count($ips); $i++) {  
					if (!preg_match("^(10|172\.16|192\.168)\.", $ips[$i])) {
					$ip = $ips[$i];  
					break;  
				}  
				}  
		}  
		return $_SERVER["HTTP_CLIENT_IP"];
	}
	public static function goods_num_by_cate($cate_id,$seller_id){
		$key_name='goods_category_'.$cate_id.'_'.$seller_id;

		$hand=new RedisDemo();
		$hand->destroy($key_name);
		if($hand->exists($key_name)){
			$result=$hand->get($key_name);
			$result=$result;
		}else{
			$query = new IQuery('category_extend as ca');
			$query->where="ca.category_id =".$cate_id." and go.is_del = 0 and go.seller_id = ".$seller_id." and go.store_nums>0";
			$query->fields='go.id';
			$query->join='left join goods as go on go.id = ca.goods_id';
			$query->limit='all';
			$result= $query->find();		
			$result=count($result);
			if($result){
				$hand->set($key_name,count($result),60*60*3);
			}					
		}
		return $result;		
	}

	public static function flushall(){
		$hand=new RedisDemo();
		$hand->flushall();
	}	  
	/*******************webset***************************/ 
	public static function WebSet($data='',$type=1){
		$configFile = IWeb::$app->getBasePath().'config_set/setList.txt';
		
		if($type==1){
			$fileObj   = new IFile($configFile);
			$getInfo   =$fileObj->read();
			$getInfo   =$getInfo ? unserialize($getInfo) : $getInfo;	
		}else{
			$fileObj   = new IFile($configFile,'w+');
			$getInfo   =$fileObj->write(serialize($data));
		}
		return $getInfo;				
	}
	public static function WebSet_allowed($data){
		$conf_name='';
		$key=$data['key'];
		$webInfo=self::WebSet();//exit($data['username']);
		//var_dump($webInfo['white_conf']['userList']);exit;
		//exit($data['username'].'=='.implode(',', $webInfo['white_conf']['userList']));

		if($webInfo['white_conf']['switch']==1&&$webInfo['func_conf'][$key]['switch']==2){
			if(!empty($webInfo['white_conf']['userList'])&&in_array($data['username'],
				$webInfo['white_conf']['userList'])){
				return $webInfo['func_conf'][$key];
			}
		}else if($webInfo['func_conf'][$key]['switch']==1){
			return $webInfo['func_conf'][$key];
		}else{
			return false;
		}
	}


}