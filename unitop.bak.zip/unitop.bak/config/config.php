<?php return array (
  'logs' => 
  array (
    'path' => 'logs/log',
    'type' => 'file',
  ),
  'DB' => 
  array (
    'type' => 'mysqli',
    'tablePre' => 'iwebshop_',
    'read' => 
    array (
      0 => 
      array (
        'host' => 'localhost:3308',
        'user' => 'root',
        'passwd' => '',
        'name' => 'unitop_new',
      ),
    ),
    'write' => 
    array (
      'host' => 'localhost:3308',
      'user' => 'root',
      'passwd' => '',
      'name' => 'unitop_new',
    ),
  ),
  'interceptor' => 
  array (
    0 => 'themeroute@onCreateController',
    1 => 'layoutroute@onCreateView',
  ),
  'langPath' => 'language',
  'viewPath' => 'views',
  'skinPath' => 'skin',
  'classes' => 'classes.*',
  'rewriteRule' => 'pathinfo',
  'theme' => 
  array (
    'pc' => 'youlida',
    'mobile' => 'youlida',
  ),
  'skin' => 
  array (
    'pc' => 'default',
    'mobile' => 'default',
  ),
  'timezone' => 'Etc/GMT-8',
  'upload' => 'upload',
  'dbbackup' => 'backup/database',
  'safe' => 'cookie',
  'safeLevel' => 'none',
  'lang' => 'zh_sc',
  'debug' => false,
  'configExt' => 
  array (
    'site_config' => 'config/site_config.php',
  ),
  'encryptKey' => '',
  'fb'=>array(
  'id' =>'',
  'sec'=>'',
  ),
  'default_area'=>659019,
  'face_per'=>'unitop_',
  'api_user_pwd'=>'111111',
  'sms_apiKey'=>"",
  'order_rate'=>0.1,
  'mail_info'=>array(
   'host'=>"",
   'username'=>"",
   'pwd'=>"",
   'from'=>"",
   'from_name'=>"",
  ),
)?>
